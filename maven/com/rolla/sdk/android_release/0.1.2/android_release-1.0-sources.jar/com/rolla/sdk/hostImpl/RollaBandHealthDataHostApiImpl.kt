package com.rolla.sdk.hostImpl

import android.annotation.SuppressLint
import app.rolla.bluetoothSdk.BleManager
import app.rolla.bluetoothSdk.characteristics.data.HrvData
import app.rolla.bluetoothSdk.characteristics.data.SleepData
import app.rolla.bluetoothSdk.characteristics.data.StepsData
import app.rolla.bluetoothSdk.characteristics.data.TotalHeartRateData
import app.rolla.bluetoothSdk.commands.data.SleepPhase
import com.rolla.sdk.extensions.collectNextPageFlowWithCallback
import com.rolla.sdk.extensions.executeCommandOperation
import com.rolla.sdk.generated.RollaBandHRV
import com.rolla.sdk.generated.RollaBandHRVSyncResponse
import com.rolla.sdk.generated.RollaBandHealthDataHostApi
import com.rolla.sdk.generated.RollaBandHeartRate
import com.rolla.sdk.generated.RollaBandHeartRateSyncResponse
import com.rolla.sdk.generated.RollaBandMotionSyncResponse
import com.rolla.sdk.generated.RollaBandSleepStage
import com.rolla.sdk.generated.RollaBandSleepStageValue
import com.rolla.sdk.generated.RollaBandSleepSyncResponse
import com.rolla.sdk.generated.RollaBandStep
import com.rolla.sdk.generated.RollaBandStepsSyncResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

@SuppressLint("MissingPermission")
class RollaBandHealthDataHostApiImpl(
    private val bleManager: BleManager,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
) : RollaBandHealthDataHostApi {

    companion object {
        private const val TAG = "RollaBandHealthDataHostApiImpl"
    }

    private val stepsCallbacks: MutableMap<String, (Result<RollaBandStepsSyncResponse>) -> Unit> = ConcurrentHashMap()
    private val hrvCallbacks: MutableMap<String, (Result<RollaBandHRVSyncResponse>) -> Unit> = ConcurrentHashMap()
    private val heartRateCallbacks: MutableMap<String, (Result<RollaBandHeartRateSyncResponse>) -> Unit> = ConcurrentHashMap()
    private val sleepCallbacks: MutableMap<String, (Result<RollaBandSleepSyncResponse>) -> Unit> = ConcurrentHashMap()

    init {
        collectStepsFlow()
        collectHrvFlow()
        collectHeartRateFlow()
        collectSleepFlow()
    }

    override fun getStepsData(
        uuid: String,
        lastSyncedBlockTimestamp: Long,
        lastSyncedEntryTimestamp: Long,
        callback: (Result<RollaBandStepsSyncResponse>) -> Unit
    ) {
        executeCommandOperation(
            scope = scope,
            uuid = uuid,
            callbacks = stepsCallbacks,
            callback = callback,
            operationName = "getStepsData",
            operation = {
                bleManager.readBandSteps(uuid, lastSyncedBlockTimestamp, lastSyncedEntryTimestamp)
            },
            tag = TAG
        )
    }

    override fun getHeartRateData(
        uuid: String,
        activityLastSyncedBlockTimestamp: Long,
        activityLastSyncedEntryTimestamp: Long,
        passiveLastSyncedTimestamp: Long,
        callback: (Result<RollaBandHeartRateSyncResponse>) -> Unit
    ) {
        executeCommandOperation(
            scope = scope,
            uuid = uuid,
            callbacks = heartRateCallbacks,
            callback = callback,
            operationName = "getHeartRateData",
            operation = {
                bleManager.readBandHeartRate(
                    uuid,
                    activityLastSyncedBlockTimestamp,
                    activityLastSyncedEntryTimestamp,
                    passiveLastSyncedTimestamp
                )
            },
            tag = TAG
        )
    }

    override fun getHRVData(
        uuid: String,
        lastSyncedBlockTimestamp: Long,
        callback: (Result<RollaBandHRVSyncResponse>) -> Unit
    ) {
        executeCommandOperation(
            scope = scope,
            uuid = uuid,
            callbacks = hrvCallbacks,
            callback = callback,
            operationName = "getHRVData",
            operation = {
                bleManager.readBandHrv(uuid, lastSyncedBlockTimestamp)
            },
            tag = TAG
        )
    }

    override fun getSleepData(
        uuid: String,
        lastSyncedBlockTimestamp: Long,
        lastSyncedEntryTimestamp: Long,
        callback: (Result<RollaBandSleepSyncResponse>) -> Unit
    ) {
        executeCommandOperation(
            scope = scope,
            uuid = uuid,
            callbacks = sleepCallbacks,
            callback = callback,
            operationName = "getSleepData",
            operation = {
                bleManager.readBandSleep(uuid, lastSyncedBlockTimestamp, lastSyncedEntryTimestamp)
            },
            tag = TAG
        )
    }

    override fun getRawDataLogs(uuid: String, callback: (Result<String>) -> Unit) {
        scope.launch {
            try {
                bleManager.enableRawDataCapture()

                val userProfileString = fetchUserProfileForRawLogs(uuid)
                
                // Collect all health data with raw capture enabled
                var stepsCompleted = false
                var sleepCompleted = false
                var heartRateCompleted = false
                var hrvCompleted = false

                getStepsData(uuid, 0, 0) { _ ->
                    stepsCompleted = true
                    getSleepData(uuid, 0, 0) { _ ->
                        sleepCompleted = true
                        getHeartRateData(uuid, 0, 0, 0) { _ ->
                            heartRateCompleted = true
                            getHRVData(uuid, 0) { _ ->
                                hrvCompleted = true
                            }
                        }
                    }
                }

                // Wait for data collection to complete
                kotlinx.coroutines.delay(5000)

                bleManager.disableRawDataCapture()
                val rawData = userProfileString + bleManager.getRawDataString()
                
                kotlinx.coroutines.withContext(Dispatchers.Main) {
                    callback(Result.success(rawData))
                }
            } catch (e: Exception) {
                bleManager.disableRawDataCapture()
                kotlinx.coroutines.withContext(Dispatchers.Main) {
                    callback(Result.failure(e))
                }
            }
        }
    }

    private fun fetchUserProfileForRawLogs(uuid: String): String {
        var completed = false
        var job: Job? = null
        var profileString = "=== USER PROFILE ===\nFailed to fetch user profile\n\n"

        job = scope.launch {
            try {
                val userData = bleManager.getRollaBandUserDataFlow().first { it.uuid == uuid }
                if (!completed) {
                    completed = true
                    val userInfo = userData.userInfo
                    profileString = buildString {
                        append("=== USER PROFILE ===\n")
                        append("Gender: ${if (userInfo.gender == 1) "Male" else "Female"}\n")
                        append("Age: ${userInfo.age}\n")
                        append("Height: ${userInfo.height} cm\n")
                        append("Weight: ${userInfo.weight} kg\n")
                        append("Stride: ${userInfo.stride} cm\n")
                        append("\n")
                    }
                }
            } catch (e: Exception) {
                if (!completed) {
                    completed = true
                    profileString = "=== USER PROFILE ===\nFailed to fetch user profile: ${e.message}\n\n"
                }
            }
        }

        scope.launch {
            kotlinx.coroutines.delay(3000)
            if (!completed) {
                completed = true
                job?.cancel()
                profileString = "=== USER PROFILE ===\nFailed to fetch user profile (timeout)\n\n"
            }
        }

        bleManager.readBandUserData(uuid)

        // Wait for user profile fetch
        Thread.sleep(3500)
        return profileString
    }

    private fun collectStepsFlow() {
        collectNextPageFlowWithCallback(
            scope = scope,
            flow = bleManager.getRollaBandStepsFlow(),
            callbacks = stepsCallbacks,
            tag = TAG,
            dataName = "Steps data",
            getUuid = { it.uuid },
            isDataEnd = { !it.hasMoreData && it.isEndOfData },
            getSuccessValue = { convertToPigeonStepsData(it) }
        )
    }

    private fun collectHrvFlow() {
        collectNextPageFlowWithCallback(
            scope = scope,
            flow = bleManager.getRollaBandHrvFlow(),
            callbacks = hrvCallbacks,
            tag = TAG,
            dataName = "HRV data",
            getUuid = { it.uuid },
            isDataEnd = { !it.hasMoreData && it.isEndOfData },
            getSuccessValue = { convertToPigeonHrvData(it) }
        )
    }

    private fun collectHeartRateFlow() {
        collectNextPageFlowWithCallback(
            scope = scope,
            flow = bleManager.getRollaBandHeartRateFlow(),
            callbacks = heartRateCallbacks,
            tag = TAG,
            dataName = "Heart rate data",
            getUuid = { it.uuid },
            isDataEnd = { true },
            getSuccessValue = { convertToPigeonHeartRateData(it) }
        )
    }

    private fun collectSleepFlow() {
        collectNextPageFlowWithCallback(
            scope = scope,
            flow = bleManager.getRollaBandSleepFlow(),
            callbacks = sleepCallbacks,
            tag = TAG,
            dataName = "Sleep data",
            getUuid = { it.uuid },
            isDataEnd = { !it.hasMoreData && it.isEndOfData },
            getSuccessValue = { convertToPigeonSleepData(it) }
        )
    }

    private fun convertToPigeonStepsData(stepsData: StepsData): RollaBandStepsSyncResponse {
        return RollaBandStepsSyncResponse(
            steps = stepsData.steps.map {
                RollaBandStep(it.timestamp, it.steps.toLong(), it.calories)
            },
            lastSyncedBlockTimestamp = stepsData.lastBlockTimestamp,
            lastSyncedEntryTimestamp = stepsData.lastEntryTimestamp
        )
    }

    private fun convertToPigeonHrvData(hrvData: HrvData): RollaBandHRVSyncResponse {
        return RollaBandHRVSyncResponse(
            hrvs = hrvData.hrvList.map {
                RollaBandHRV(it.timestamp, it.hrv.toLong())
            },
            lastSyncedBlockTimestamp = hrvData.lastBlockTimestamp
        )
    }

    private fun convertToPigeonHeartRateData(heartRateData: TotalHeartRateData): RollaBandHeartRateSyncResponse {
        return RollaBandHeartRateSyncResponse(
            heartRates = heartRateData.heartRates.map {
                RollaBandHeartRate(it.timestamp, it.heartRate.toLong())
            },
            activityLastSyncedBlockTimestamp = heartRateData.activityLastBlockTimestamp,
            activityLastSyncedEntryTimestamp = heartRateData.activityLastEntryTimestamp,
            passiveLastSyncedTimestamp = heartRateData.passiveLastBlockTimestamp
        )
    }

    private fun convertToPigeonSleepData(sleepData: SleepData): RollaBandSleepSyncResponse {
        return RollaBandSleepSyncResponse(
            sleepStages = sleepData.sleeps.map {
                RollaBandSleepStage(it.startTime, it.endTime, it.phase.toPigeonValue())
            },
            lastSyncedBlockTimestamp = sleepData.lastBlockTimestamp,
            lastSyncedEntryTimestamp = sleepData.lastEntryTimestamp
        )
    }

    private fun SleepPhase.toPigeonValue(): RollaBandSleepStageValue {
        return when (this) {
            SleepPhase.DEEP -> RollaBandSleepStageValue.DEEP
            SleepPhase.LIGHT -> RollaBandSleepStageValue.LIGHT
            SleepPhase.REM -> RollaBandSleepStageValue.REM
            SleepPhase.AWAKE -> RollaBandSleepStageValue.AWAKE
        }
    }

    fun cleanup() {
        stepsCallbacks.clear()
        hrvCallbacks.clear()
        heartRateCallbacks.clear()
        sleepCallbacks.clear()
        scope.cancel()
    }

}