package com.rolla.sdk.hostImpl

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.PowerManager
import com.rolla.sdk.generated.DevicePowerModeFlutterApi
import com.rolla.sdk.generated.DevicePowerModeHostApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DevicePowerModeHandler(
    private val context: Context,
    private val flutterApi: DevicePowerModeFlutterApi,
    private val scope: CoroutineScope
) : DevicePowerModeHostApi {

    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager

    init {
        observePowerMode()
    }

    override fun isLowPowerModeEnabled(): Boolean {
        return powerManager.isPowerSaveMode
    }

    private fun observePowerMode() {
        scope.launch {
            powerModeFlow()
                .distinctUntilChanged()
                .collect { isEnabled ->
                    withContext(Dispatchers.Main) {
                        flutterApi.onLowPowerModeChanged(isEnabled) { }
                    }
                }
        }
    }

    private fun powerModeFlow(): Flow<Boolean> = callbackFlow {
        trySend(powerManager.isPowerSaveMode)

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                trySend(powerManager.isPowerSaveMode)
            }
        }

        context.registerReceiver(
            receiver,
            IntentFilter(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
        )

        awaitClose {
            context.unregisterReceiver(receiver)
        }
    }
}

