package com.rolla.sdk.location

import app.rolla.bluetoothSdk.result.error.Error

class LocationTrackingStopFailed(throwable: Throwable? = null) : Error (
    code = LocationErrors.LOCATION_TRACKING_STOP_FAILED,
    message = "Location tracking stop failed",
    exception = throwable
)