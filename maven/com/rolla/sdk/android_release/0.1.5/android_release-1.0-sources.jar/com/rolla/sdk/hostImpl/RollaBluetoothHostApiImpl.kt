package com.rolla.sdk.hostImpl

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import app.rolla.bluetoothSdk.BleManager
import app.rolla.bluetoothSdk.device.DeviceConnectionState
import app.rolla.bluetoothSdk.utils.log
import com.rolla.sdk.extensions.collectFlowWithCallback
import com.rolla.sdk.extensions.executeCommandOperation
import com.rolla.sdk.extensions.executeOperation
import com.rolla.sdk.extensions.executeOperationSuspend
import com.rolla.sdk.extensions.toFlutterError
import com.rolla.sdk.generated.BluetoothState
import com.rolla.sdk.generated.ConnectionState
import com.rolla.sdk.generated.DeviceType
import com.rolla.sdk.generated.RollaBluetoothHostApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@SuppressLint("MissingPermission")
class RollaBluetoothHostApiImpl(
    private val bleManager: BleManager,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
) : RollaBluetoothHostApi {

    companion object {
        private const val TAG = "RollaBluetoothHostApiImpl"
    }
    private val factoryResetCallback: MutableMap<String, (Result<Unit>) -> Unit> = mutableMapOf()

    init {
        collectFlowWithCallback(
            scope = scope,
            flow = bleManager.getRollaBandFactoryResetFlow(),
            callbacks = factoryResetCallback,
            tag = TAG,
            dataName = "Factory reset",
            getUuid = { it.uuid },
            getError = { it.error },
            getSuccessValue = { }
        )
    }

    override fun scanForDevices(
        deviceTypes: List<DeviceType>,
        scanDuration: Long,
        callback: (Result<Unit>) -> Unit
    ) {
        executeOperationSuspend(
            scope = scope,
            callback = callback,
            tag = TAG,
            operationName = "Scanning for device types: ${deviceTypes.joinToString()}",
            operation = {
                val sdkDeviceTypes = deviceTypes.map { convertToSdkDeviceType(it) }.toSet()
                bleManager.setScanDuration(scanDuration)
                bleManager.startScan(deviceTypes = sdkDeviceTypes)
            },
            onSuccess = { }
        )
    }

    override fun stopScanning(callback: (Result<Unit>) -> Unit) {
        executeOperationSuspend(
            scope = scope,
            callback = callback,
            tag = TAG,
            operationName = "Stopping scan",
            operation = { bleManager.stopScan() },
            onSuccess = { }
        )
    }

    override fun connectToDevice(uuid: String, callback: (Result<Boolean>) -> Unit) {
        executeOperation(
            scope = scope,
            callback = callback,
            tag = TAG,
            operationName = "Connecting to device: $uuid",
            operation = { bleManager.connectToBleDevice(uuid) },
            onSuccess = {
                log("RollaBluetoothHostApiImpl", "Connected to device: $uuid")
                true
            },
            onError = { log("RollaBluetoothHostApiImpl", "Error connecting to device: $uuid") }
        )
    }

    override fun disconnectFromDevice(uuid: String, callback: (Result<Boolean>) -> Unit) {
        executeOperation(
            scope = scope,
            callback = callback,
            tag = TAG,
            operationName = "Disconnecting from device: $uuid",
            operation = { bleManager.disconnectFromDevice(uuid) },
            onSuccess = { true }
        )
    }

    override fun disconnectAndRemoveBond(uuid: String, callback: (Result<Boolean>) -> Unit) {
        scope.launch {
            try {
                log(TAG, "Disconnecting and removing bond for: $uuid")

                bleManager.disconnectFromDevice(uuid)

                val result = bleManager.removeBond(uuid)

                withContext(Dispatchers.Main) {
                    if (result.successful) {
                        log(TAG, "Successfully removed bond for: $uuid")
                        callback(Result.success(true))
                    } else {
                        val errorMessage = result.error?.message ?: "Unknown error removing bond"
                        log(TAG, "Failed to remove bond for $uuid: $errorMessage")
                        callback(Result.failure(Throwable(errorMessage)))
                    }
                }
            } catch (e: Exception) {
                log(TAG, "Exception while disconnecting and removing bond for $uuid: ${e.message}")
                withContext(Dispatchers.Main) {
                    callback(Result.failure(e))
                }
            }
        }
    }

    override fun factoryReset(uuid: String, callback: (Result<Unit>) -> Unit) {
        executeCommandOperation(
            scope = scope,
            uuid = uuid,
            callbacks = factoryResetCallback,
            callback = callback,
            operationName = "factoryReset",
            operation = {
                bleManager.factoryReset(uuid)
            },
            tag = TAG
        )
    }

    override fun checkConnectionState(
        uuid: String,
        callback: (Result<ConnectionState>) -> Unit
    ) {
        log("RollaBluetoothHostApiImpl", "Checking connection state for $uuid")
        bleManager.getConnectionState(uuid, onSuccess = { state ->
            callback(Result.success(convertToPigeonConnectionState(state)))
        }, onError = { error ->
            callback(Result.failure(toFlutterError(error)))
        })
    }

    override fun checkBluetoothState(callback: (Result<BluetoothState>) -> Unit) {
        log("RollaBluetoothHostApiImpl", "Checking Bluetooth state")
        bleManager.getBluetoothState(onSuccess = { state ->
            callback(Result.success(convertToPigeonBluetoothState(state)))
        }, onError = { error ->
            callback(Result.failure(toFlutterError(error)))
        })
    }

    private fun convertToPigeonConnectionState(state: DeviceConnectionState): ConnectionState {
        return when (state) {
            DeviceConnectionState.CONNECTED -> ConnectionState.CONNECTED
            DeviceConnectionState.CONNECTING -> ConnectionState.CONNECTING
            DeviceConnectionState.DISCONNECTED -> ConnectionState.DISCONNECTED
            DeviceConnectionState.DISCONNECTING -> ConnectionState.DISCONNECTED
        }
    }

    private fun convertToPigeonBluetoothState(state: Int): BluetoothState {
        return when (state) {
            BluetoothAdapter.STATE_ON -> BluetoothState.POWERED_ON
            BluetoothAdapter.STATE_OFF -> BluetoothState.POWERED_OFF
            BluetoothAdapter.STATE_TURNING_ON -> BluetoothState.TURNING_ON
            BluetoothAdapter.STATE_TURNING_OFF -> BluetoothState.TURNING_OFF
            else -> BluetoothState.UNKNOWN
        }
    }

    private fun convertToSdkDeviceType(pigeonType: DeviceType): app.rolla.bluetoothSdk.device.DeviceType {
        return when (pigeonType) {
            DeviceType.ROLLA_BAND -> app.rolla.bluetoothSdk.device.DeviceType.ROLLA_BAND
            DeviceType.OTHER -> app.rolla.bluetoothSdk.device.DeviceType.HEART_RATE
        }
    }

    fun cleanup() {
        factoryResetCallback.clear()
        scope.cancel()
    }
}
