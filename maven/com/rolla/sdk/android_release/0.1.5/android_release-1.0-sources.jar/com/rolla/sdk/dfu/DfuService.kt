package com.rolla.sdk.dfu

import android.app.Activity
import no.nordicsemi.android.dfu.DfuBaseService

class DfuService : DfuBaseService() {

    override fun getNotificationTarget(): Class<out Activity> {
        /*
         * Note: This is a library module, so we return a generic Activity class.
         * Host apps can extend this service and override this method to return
         * their own target activity if needed.
         */
        return Activity::class.java
    }

}