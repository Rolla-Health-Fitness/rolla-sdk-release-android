package com.rolla.sdk.location

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import app.rolla.bluetoothSdk.utils.log

class LocationService : Service() {

    companion object {
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "location_tracking"
        const val ACTION_START_TRACKING = "START_TRACKING"
        const val ACTION_STOP_TRACKING = "STOP_TRACKING"

        var isStarted = false
            private set
    }
    
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        isStarted = false
        createNotificationChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_TRACKING -> {
                log("LocationService", "[LOCATION] ACTION_START_TRACKING received")
                startTracking()
            }
            ACTION_STOP_TRACKING -> {
                log("LocationService", "[LOCATION] ACTION_STOP_TRACKING received")
                stopTracking()
            }
            else -> {
                log("LocationService", "[LOCATION] No action specified, starting tracking by default")
                startTracking() // Default behavior
            }
        }
        return START_STICKY
    }

    private fun startTracking() {
        if (!isStarted) {
            showNotification()
            isStarted = true
        }
    }

    private fun stopTracking() {
        log("LocationService", "[LOCATION] stopTracking called, isStarted=$isStarted")
        if (isStarted) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        } else {
            log("LocationService", "[LOCATION] Service not started, nothing to stop")
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID, 
                "Location Tracking", 
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Tracking your location for workout"
                enableLights(false)
                enableVibration(false)
                setBypassDnd(false)
                setSound(null, null)
            }
            manager.createNotificationChannel(channel)
        }
    }

    private fun showNotification() {
        try {
            val notification = createNotification()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION or ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            log("LocationService", "Notification shown, service is foreground")
        } catch (e: Exception) {
            log("LocationService", "Failed to start foreground: ${e.message}")
            e.printStackTrace()
        }
    }

    private fun createNotification(): Notification {
        // Note: No content intent since this is a library module
        // Host apps can customize the notification if needed

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Location Tracking")
                .setContentText("Location tracking is running in the background...")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setOngoing(true)
                .setPriority(Notification.PRIORITY_LOW)
                .setShowWhen(false)
                .build()
        } else {
            NotificationCompat.Builder(this)
                .setContentTitle("Location Tracking")
                .setContentText("Location tracking is running in the background...")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setShowWhen(false)
                .build()
        }
    }

    private fun acquireWakeLock() {
        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "rolla:LocationService"
        )
        wakeLock?.acquire(12 * 60 * 60 * 1000L)
    }

    override fun onDestroy() {
        super.onDestroy()
        wakeLock?.release()
        isStarted = false
    }

    override fun onBind(intent: Intent?): IBinder? = null
}