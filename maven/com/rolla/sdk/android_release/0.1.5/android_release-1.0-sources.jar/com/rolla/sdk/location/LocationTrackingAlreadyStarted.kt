package com.rolla.sdk.location

import app.rolla.bluetoothSdk.result.error.Error

class LocationTrackingAlreadyStarted : Error (
    code = LocationErrors.LOCATION_TRACKING_ALREADY_STARTED,
    message = "Location tracking already started"
)