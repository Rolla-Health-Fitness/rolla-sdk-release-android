package com.rolla.sdk.wrapper

interface RollaListener {
    fun onRollaClosed(rolla: Rolla, reason: RollaCloseReason) {}
    fun onRollaError(rolla: Rolla, error: RollaError) {}
}
