/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.rolla.sdk;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.rolla.sdk";
  public static final String BUILD_TYPE = "release";
  // Field from build type: release
  public static final boolean ENABLE_LOGS = true;
}
