package com.rolla.sdk.location

import app.rolla.bluetoothSdk.result.error.Error

class LocationTrackingNotStarted : Error (
    code = LocationErrors.LOCATION_TRACKING_NOT_STARTED,
    message = "Location tracking is not started"
)