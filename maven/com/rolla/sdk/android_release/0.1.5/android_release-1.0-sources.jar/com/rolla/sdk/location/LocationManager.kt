package com.rolla.sdk.location

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.location.Location
import android.os.Build
import android.os.Looper
import app.rolla.bluetoothSdk.result.MethodResult
import android.location.LocationManager as AndroidLocationManager
import app.rolla.bluetoothSdk.utils.log
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class LocationManager(private val context: Context) {
    
    // Add coroutine scope
    private val locationScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    companion object {
        private const val MAX_ATTEMPTS = 6
        private const val MIN_VALID_POINTS = 4
        private const val MIN_VALID_DISTANCE = 5
        private const val MIN_TIME_INTERVAL = 970L
        private const val MIN_DISTANCE = 0f
        private const val HORIZONTAL_ACCURACY = 15f
        private const val SPEED_THRESHOLD_KPH = 12f
        private const val FIRST_LOCATIONS_COUNT = 9
        private const val LOCATION_BATCH_SIZE = 3

        private const val USE_FUSED_LOCATION = true
        private const val TAG = "LocationManager"
    }

    private val androidLocationManager =
        context.getSystemService(Context.LOCATION_SERVICE) as AndroidLocationManager
    private val fusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)

    // State
    private var calibrationState = CalibrationState()
    private var locationBuffer = LocationBuffer()
    private var trackingStartTimeMs: Long = 0L
    private val _locationFlow = MutableSharedFlow<Location>(replay = 0)
    val locationFlow: SharedFlow<Location> = _locationFlow.asSharedFlow()

    private var isLocationTrackingStarted = false

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            result.lastLocation?.let {
                processLocation(it)
            } 
        }
    }

    @SuppressLint("MissingPermission")
    fun startLocationUpdates(): MethodResult {

        val hasFineLocation = context.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        val hasCoarseLocation = context.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED

        if (!hasFineLocation && !hasCoarseLocation) {
            return MethodResult(false, app.rolla.bluetoothSdk.result.error.UnknownError(Exception("Location permissions not granted")))
        }

        // Always reset per-activity state on start to avoid stale points/buffers
        // carrying over between workouts (e.g. if previous stop didn't run cleanly).
        resetForNewActivity()

        if (isLocationTrackingStarted) {
            // Tracking already running: keep native location subscription as-is,
            // but ensure the foreground notification/service is active for background reliability.
            startLocationService()
            return MethodResult(true)
        }

        return try {
            val result = if (USE_FUSED_LOCATION) {
                startFusedLocationUpdates()
            } else {
                startGpsLocationUpdates()
            }

            if (result.successful) {
                startLocationService()
                isLocationTrackingStarted = true
            }
            result
        } catch (e: Exception) {
            e.printStackTrace()
            MethodResult(false, LocationTrackingStartFailed(e))
        }
    }

    fun stopLocationUpdates(): MethodResult {
        if (!isLocationTrackingStarted) {
            return MethodResult(false, LocationTrackingNotStarted())
        }
        return try {
            if (USE_FUSED_LOCATION) {
                fusedLocationProviderClient.removeLocationUpdates(locationCallback)
            } else {
                androidLocationManager.removeUpdates(this::onLocationChanged)
            }

            stopLocationService()
            isLocationTrackingStarted = false
            MethodResult(true)
        } catch (e: Exception) {
            e.printStackTrace()
            MethodResult(false, LocationTrackingStopFailed(e))
        }
    }

    fun reset() {
        calibrationState = CalibrationState()
        locationBuffer = LocationBuffer()
        trackingStartTimeMs = 0L
        stopLocationUpdates()
        isLocationTrackingStarted = false
        // Do NOT cancel the singleton scope here; this LocationManager instance is a singleton.
        // Cancelling would permanently prevent future emissions via locationFlow.
    }
    private fun resetForNewActivity() {
        calibrationState = CalibrationState()
        locationBuffer = LocationBuffer()
        trackingStartTimeMs = System.currentTimeMillis()
        log(TAG, "[LOCATION] Reset for new activity - trackingStartTimeMs: $trackingStartTimeMs")
    }

    @SuppressLint("MissingPermission")
    private fun startFusedLocationUpdates(): MethodResult {
        val locationRequest = LocationRequest.Builder(MIN_TIME_INTERVAL)
            .setMaxUpdates(Integer.MAX_VALUE)
            .setMinUpdateIntervalMillis(MIN_TIME_INTERVAL)
            .setWaitForAccurateLocation(false)
            .setIntervalMillis(MIN_TIME_INTERVAL)
            .setMinUpdateDistanceMeters(MIN_DISTANCE)
            .setDurationMillis(Long.MAX_VALUE)
            .setPriority(Priority.PRIORITY_HIGH_ACCURACY)
            .build()

        val task = fusedLocationProviderClient.requestLocationUpdates(
            locationRequest,
            locationCallback,
            Looper.getMainLooper()
        )

        task.addOnSuccessListener {
            log(TAG, "[LOCATION] Location updates request succeeded!")
        }
        task.addOnFailureListener { e ->
            log(TAG, "[LOCATION] ❌ Location updates request FAILED: ${e.message}")
            e.printStackTrace()
        }

        return MethodResult(true)
    }

    @SuppressLint("MissingPermission")
    private fun startGpsLocationUpdates(): MethodResult {
        androidLocationManager.requestLocationUpdates(
            AndroidLocationManager.GPS_PROVIDER,
            MIN_TIME_INTERVAL,
            MIN_DISTANCE,
            this::onLocationChanged,
            Looper.getMainLooper()
        )
        return MethodResult(true)
    }

    private fun onLocationChanged(location: Location) {
        processLocation(location)
    }

    private fun processLocation(location: Location) {
        log(
            TAG,
            "Location: ${location.latitude}, ${location.longitude}, accuracy: ${location.accuracy}"
        )

        if (!location.isAccurate()) return
        log(TAG, "Location accurate")
        locationBuffer.addLocation(location)
        calibrationState.processLocation(location)
        log(TAG, "Location is batch ready: ${locationBuffer.isBatchReady()}")
        if (locationBuffer.isBatchReady()) {
            val bestLocation = locationBuffer.getBestLocation()
            log(TAG, "Best location: ${bestLocation?.latitude}, ${bestLocation?.longitude}")
            bestLocation?.let { handleCalibratedLocation(it) }
            locationBuffer.clear()
        }
    }

    private fun handleCalibratedLocation(location: Location) {
       if (trackingStartTimeMs > 0 && location.time < trackingStartTimeMs) {
            log(TAG, "[LOCATION] Discarding stale location - location.time: ${location.time}, trackingStartTimeMs: $trackingStartTimeMs")
            return
        }

        if (calibrationState.isCalibrated) {
            log(TAG, "Emitting calibrated location to flow")
            locationScope.launch {
                _locationFlow.emit(location)
                log(TAG, "Location emitted successfully via coroutine")
            }
        } else {
            calibrationState.attemptCalibration(location) { calibratedLocation ->
                log(TAG, "Calibration successful - emitting location")
                locationScope.launch {
                    _locationFlow.emit(calibratedLocation)
                    log(TAG, "Calibrated location emitted successfully via coroutine")
                }
            }
        }
    }

    private fun Location.isAccurate(): Boolean = hasAccuracy() && accuracy < HORIZONTAL_ACCURACY

    // Data classes for better organization
    private data class CalibrationState(
        var isCalibrated: Boolean = false,
        var activityStateDetected: Boolean = false,
        var calibratedGpsPointCount: Int = 0,
        var calibrationAttempts: Int = 0,
        var lastLocation: Location? = null,
        val firstLocations: MutableList<Location> = mutableListOf()
    ) {

        fun processLocation(location: Location) {
            if (!activityStateDetected && firstLocations.size < FIRST_LOCATIONS_COUNT) {
                firstLocations.add(location)
                if (firstLocations.size == FIRST_LOCATIONS_COUNT) {
                    detectActivityState()
                }
            }
        }

        private fun detectActivityState() {
            val distance = firstLocations.first().distanceTo(firstLocations.last())
            val timeMs = firstLocations.last().time - firstLocations.first().time
            val speedKph = (distance * 1000 / timeMs) * 3.6f

            isCalibrated = speedKph > SPEED_THRESHOLD_KPH
            activityStateDetected = true

            log(TAG, "Activity detected - Speed: $speedKph kph, Moving: $isCalibrated")
        }

        fun attemptCalibration(location: Location, onCalibrated: (Location) -> Unit) {
            val previous = lastLocation
            lastLocation = location

            if (previous == null) return

            calibrationAttempts++
            val distance = location.distanceTo(previous)

            if (distance < MIN_VALID_DISTANCE) {
                calibratedGpsPointCount++
                if (calibratedGpsPointCount >= MIN_VALID_POINTS) {
                    isCalibrated = true
                    onCalibrated(location)
                }
            }

            if (!isCalibrated && calibrationAttempts >= MAX_ATTEMPTS) {
                isCalibrated = true
                onCalibrated(location)
            }
        }
    }

    private data class LocationBuffer(
        private val locations: MutableList<Location> = mutableListOf()
    ) {

        fun addLocation(location: Location) {
            locations.add(location)
        }

        fun isBatchReady(): Boolean = locations.size >= LOCATION_BATCH_SIZE

        fun getBestLocation(): Location? = locations.minByOrNull { it.accuracy }

        fun clear() {
            locations.clear()
        }
    }

    private fun startLocationService() {
        val intent = Intent(context, LocationService::class.java).apply {
            action = LocationService.ACTION_START_TRACKING
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    private fun stopLocationService() {
        val intent = Intent(context, LocationService::class.java).apply {
            action = LocationService.ACTION_STOP_TRACKING
        }
        context.startService(intent)
    }
}
