package app.rolla.bluetoothSdk.device.state

import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.device.DeviceConnectionState
import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

@Singleton
class DeviceStateManager @Inject constructor(
    private val storageManager: DeviceStorageManager,
    coroutineContext: CoroutineContext
) {
    private val stateScope = CoroutineScope(coroutineContext)

    private val _devicesFlow = MutableStateFlow<List<BleDevice>>(emptyList())
    val devicesFlow: StateFlow<List<BleDevice>> = _devicesFlow.asStateFlow()

    private val _connectionStateChanges = MutableSharedFlow<Pair<String, DeviceConnectionState>>(replay = 1)
    val connectionStateChanges: SharedFlow<Pair<String, DeviceConnectionState>> = _connectionStateChanges.asSharedFlow()

    fun updateDevice(address: String, updater: (BleDevice) -> BleDevice): BleDevice? {
        val updated = storageManager.updateDevice(address) { device ->
            val oldConnectionState = device.connectionState
            val updatedDevice = updater(device)

            // Emit connection state change if it actually changed
            if (oldConnectionState != updatedDevice.connectionState) {
                stateScope.launch {
                    _connectionStateChanges.emit(address to updatedDevice.connectionState)
                }
            }

            updatedDevice
        }

        if (updated != null) {
            refreshDevicesList()
        }
        return updated
    }

    fun refreshDevicesList() {
        val deviceList = storageManager.getAllDevices().sortedWith(
            compareBy<BleDevice> {
                when (it.connectionState) {
                    DeviceConnectionState.CONNECTED -> 0
                    DeviceConnectionState.CONNECTING -> 1
                    DeviceConnectionState.DISCONNECTING -> 2
                    DeviceConnectionState.DISCONNECTED -> 3
                }
            }.thenByDescending { it.rssi }
        )
        _devicesFlow.value = deviceList
    }

    fun clear() {
        storageManager.clear()
        _devicesFlow.value = emptyList()
    }
}