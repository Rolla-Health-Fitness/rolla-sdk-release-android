package app.rolla.bluetoothSdk.scan.manager;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ScanThrottleManager_Factory implements Factory<ScanThrottleManager> {
  @Override
  public ScanThrottleManager get() {
    return newInstance();
  }

  public static ScanThrottleManager_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static ScanThrottleManager newInstance() {
    return new ScanThrottleManager();
  }

  private static final class InstanceHolder {
    static final ScanThrottleManager_Factory INSTANCE = new ScanThrottleManager_Factory();
  }
}
