package app.rolla.bluetoothSdk.connect

import android.content.Context
import android.annotation.SuppressLint
import app.rolla.bluetoothSdk.characteristics.Characteristic
import app.rolla.bluetoothSdk.result.MethodResult
import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.device.DeviceManager
import app.rolla.bluetoothSdk.device.DeviceType
import app.rolla.bluetoothSdk.di.BleScopeContext
import app.rolla.bluetoothSdk.result.error.BluetoothConnectPermissionMissing
import app.rolla.bluetoothSdk.result.error.DeviceNotConnected
import app.rolla.bluetoothSdk.result.error.DeviceNotFound
import app.rolla.bluetoothSdk.result.error.DeviceTypeConflicts
import app.rolla.bluetoothSdk.result.error.DeviceTypeEmpty
import app.rolla.bluetoothSdk.result.error.Error
import app.rolla.bluetoothSdk.result.error.GattNull
import app.rolla.bluetoothSdk.result.error.MaxConnectionsReached
import app.rolla.bluetoothSdk.result.error.ReadFailed
import app.rolla.bluetoothSdk.result.error.UnsupportedDeviceTypes
import app.rolla.bluetoothSdk.result.error.WriteFailed
import app.rolla.bluetoothSdk.commands.Command
import app.rolla.bluetoothSdk.result.error.CharacteristicNotFound
import app.rolla.bluetoothSdk.utils.hasBluetoothConnectPermission
import app.rolla.bluetoothSdk.utils.log
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

/**
 * Simplified connection manager - acts as facade
 */
@SuppressLint("MissingPermission")
@Singleton
class BleConnector @Inject constructor(
    @param: ApplicationContext private val context: Context,
    private val deviceManager: DeviceManager,
    private val operationQueue: OperationQueue,
    @BleScopeContext bleScopeContext: CoroutineContext,
    private val connectionManager: ConnectionManager
) {

    private val managerScope = CoroutineScope(bleScopeContext)

    companion object {
        private const val TAG = "BleConnector"
    }

    // Public API - delegates to operations
    @SuppressLint("MissingPermission")
    fun connectToDevice(bleDevice: BleDevice, requestedDeviceTypes: Set<DeviceType>): MethodResult {
        if (requestedDeviceTypes.isEmpty()) {
            return MethodResult(false, DeviceTypeEmpty())
        }
        val address = bleDevice.getMacAddress()

        log(TAG, "Connecting to $address with REQUESTED types: ${requestedDeviceTypes.joinToString { it.name }}")
        log(TAG, "Device SUPPORTS types: ${bleDevice.scannedDeviceTypes.joinToString { it.name }}")

        val unsupportedTypes = requestedDeviceTypes.filter { type -> !bleDevice.scannedDeviceTypes.contains(type) }
        if (unsupportedTypes.isNotEmpty()) {
            return MethodResult(false, UnsupportedDeviceTypes(Throwable("Unsupported types: ${unsupportedTypes.toTypedArray().contentToString()}")))
        }

        val conflictingTypes = deviceManager.getConflictTypes(requestedDeviceTypes, address)
        if (conflictingTypes.isNotEmpty()) {
            log(TAG, "Device type conflict for connection: $conflictingTypes")
            return MethodResult(false,
                DeviceTypeConflicts(
                    Throwable(
                        "Conflicting types: ${
                            conflictingTypes.toTypedArray().contentToString()
                        }"
                    )
                )
            )
        }

        if (!deviceManager.canCreateNewConnection(address)) {
            log(TAG, "Maximum concurrent connections reached")
            return MethodResult(false, MaxConnectionsReached())
        }

        if (!context.hasBluetoothConnectPermission()) {
            return MethodResult(false, BluetoothConnectPermissionMissing())
        }

        log(TAG, "Handling device connection")
        return connectionManager.handleDeviceConnection(bleDevice, requestedDeviceTypes)
    }

    fun disconnectFromDevice(bleDevice: BleDevice): MethodResult {
        val address = bleDevice.getMacAddress()
        val device = deviceManager.getDevice(address)
        if (device == null) {
            return MethodResult(false, DeviceNotFound())
        }
        if (!device.isConnected()) {
            return MethodResult(false, DeviceNotConnected())
        }
        val subscribedTypes = device.getSubscribedTypes()
        return if (subscribedTypes.isNotEmpty()) {
            disconnectFromDevice(device, subscribedTypes.toSet())
        } else {
            // Force complete disconnection if no subscribed types
            connectionManager.performCompleteDisconnection(address)
            return MethodResult(true)
        }
    }

    fun disconnectFromDeviceCompletely(bleDevice: BleDevice) {
        return connectionManager.handleDisconnectState(bleDevice.getMacAddress(), bleDevice.gatt, bleDevice)
    }

    fun disconnectFromDevice(bleDevice: BleDevice, deviceTypes: Set<DeviceType>): MethodResult {
        if (deviceTypes.isEmpty()) {
            return MethodResult(false, DeviceTypeEmpty())
        }
        val unsupportedTypes = deviceTypes.filter { type -> !bleDevice.scannedDeviceTypes.contains(type) }

        if (unsupportedTypes.isNotEmpty()) {
            return MethodResult(false, UnsupportedDeviceTypes(Throwable("Unsupported types: ${unsupportedTypes.toTypedArray().contentToString()}")))
        }

        val device = deviceManager.getDevice(bleDevice.getMacAddress())
        if (device == null) {
            return MethodResult(false, DeviceNotFound())
        }

        if (!device.isConnected()) {
            return MethodResult(false, DeviceNotConnected())
        }

        if (device.gatt == null) {
            log(TAG, "No GATT connection for ${device.getMacAddress()}")
            return MethodResult(false, GattNull())
        }

        if (!context.hasBluetoothConnectPermission()) {
            return MethodResult(false, BluetoothConnectPermissionMissing())
        }

        connectionManager.handleDeviceDisconnection(device.getMacAddress(), deviceTypes)
        return MethodResult(true)
    }

    fun readCharacteristic(uuid: String, characteristic: Characteristic, command: Command<*>? = null): MethodResult {
        val bleDevice = deviceManager.getDevice(uuid) ?: return MethodResult(
            false,
            DeviceNotFound()
        )
        if (!bleDevice.isConnected()) {
            return MethodResult(false, DeviceNotConnected())
        }
        val gatt = bleDevice.gatt
        if (gatt == null) {
            return MethodResult(false, GattNull())
        }

        val char = bleDevice.getCharacteristicByUuid(characteristic.uuid)
        if (char == null) {
            return MethodResult(false, CharacteristicNotFound())
        }
        if (!context.hasBluetoothConnectPermission()) {
            return MethodResult(false, BluetoothConnectPermissionMissing())
        }

        val operation = if (command != null) {
            BleOperation.WriteCharacteristic(
                deviceAddress = uuid,
                name = "WriteCommand - ${command.javaClass.simpleName}",
                gatt = gatt,
                characteristic = char,
                data = command.bytesToWrite(),
                onComplete = { success, status ->
                    if (!success) {
                        characteristic.onError(uuid, ReadFailed(status), command.bytesToWrite())
                    }
                }
            )
        } else {
            BleOperation.ReadCharacteristic(
                deviceAddress = uuid,
                name = "ReadCharacteristic - ${characteristic.uuid}",
                gatt = gatt,
                characteristic = char,
                onComplete = { success, status ->
                    if (!success) {
                        characteristic.onError(uuid, ReadFailed(status))
                    }
                }
            )
        }

        operationQueue.queueOperation(operation)
        return MethodResult(true)
    }

    fun writeCharacteristic(
        uuid: String,
        characteristic: Characteristic,
        data: ByteArray,
        onAsyncError: (Error) -> Unit
    ): MethodResult {
        val bleDevice = deviceManager.getDevice(uuid) ?: return MethodResult(
            false,
            DeviceNotFound()
        )
        if (!bleDevice.isConnected()) {
            return MethodResult(false, DeviceNotConnected())
        }
        val gatt = bleDevice.gatt
        if (gatt == null) {
            return MethodResult(false, GattNull())
        }

        val char = bleDevice.getCharacteristicByUuid(characteristic.uuid)
        if (char == null) {
            return MethodResult(false, CharacteristicNotFound())
        }
        if (!context.hasBluetoothConnectPermission()) {
            return MethodResult(false, BluetoothConnectPermissionMissing())
        }

        val operation = BleOperation.WriteCharacteristic(
            deviceAddress = uuid,
            name = "WriteCharacteristic - ${characteristic.uuid}",
            gatt = gatt,
            characteristic = char,
            data = data,
            onComplete = { success, status ->
                if (!success) {
                    onAsyncError(WriteFailed(status))
                }
            }
        )

        operationQueue.queueOperation(operation)
        return MethodResult(true)
    }

    fun disableAutoReconnect(deviceAddress: String) {
        connectionManager.disableAutoReconnect(deviceAddress)
    }

    fun enableAutoReconnect(deviceAddress: String) {
        connectionManager.enableAutoReconnect(deviceAddress)
    }

    @SuppressLint("MissingPermission")
    fun disconnectAll() {
        deviceManager.getConnectedDevices().forEach { device ->
            managerScope.launch {
                disconnectFromDeviceCompletely(device)
            }
        }
    }

    fun destroy() {
        disconnectAll()
        connectionManager.clearAllCallbacks()
    }

}
