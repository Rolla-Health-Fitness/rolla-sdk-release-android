package app.rolla.bluetoothSdk.di;

import app.rolla.bluetoothSdk.characteristics.FirmwareRevisionCharacteristic;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("app.rolla.bluetoothSdk.di.BleScopeContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CharacteristicModule_ProvideFirmwareRevisionCharacteristicFactory implements Factory<FirmwareRevisionCharacteristic> {
  private final Provider<CoroutineContext> bleScopeContextProvider;

  private CharacteristicModule_ProvideFirmwareRevisionCharacteristicFactory(
      Provider<CoroutineContext> bleScopeContextProvider) {
    this.bleScopeContextProvider = bleScopeContextProvider;
  }

  @Override
  public FirmwareRevisionCharacteristic get() {
    return provideFirmwareRevisionCharacteristic(bleScopeContextProvider.get());
  }

  public static CharacteristicModule_ProvideFirmwareRevisionCharacteristicFactory create(
      Provider<CoroutineContext> bleScopeContextProvider) {
    return new CharacteristicModule_ProvideFirmwareRevisionCharacteristicFactory(bleScopeContextProvider);
  }

  public static FirmwareRevisionCharacteristic provideFirmwareRevisionCharacteristic(
      CoroutineContext bleScopeContext) {
    return Preconditions.checkNotNullFromProvides(CharacteristicModule.INSTANCE.provideFirmwareRevisionCharacteristic(bleScopeContext));
  }
}
