package app.rolla.bluetoothSdk.di;

import app.rolla.bluetoothSdk.characteristics.HeartRateCharacteristic;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("app.rolla.bluetoothSdk.di.BleScopeContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CharacteristicModule_ProvideHeartRateCharacteristicFactory implements Factory<HeartRateCharacteristic> {
  private final Provider<CoroutineContext> bleScopeContextProvider;

  private CharacteristicModule_ProvideHeartRateCharacteristicFactory(
      Provider<CoroutineContext> bleScopeContextProvider) {
    this.bleScopeContextProvider = bleScopeContextProvider;
  }

  @Override
  public HeartRateCharacteristic get() {
    return provideHeartRateCharacteristic(bleScopeContextProvider.get());
  }

  public static CharacteristicModule_ProvideHeartRateCharacteristicFactory create(
      Provider<CoroutineContext> bleScopeContextProvider) {
    return new CharacteristicModule_ProvideHeartRateCharacteristicFactory(bleScopeContextProvider);
  }

  public static HeartRateCharacteristic provideHeartRateCharacteristic(
      CoroutineContext bleScopeContext) {
    return Preconditions.checkNotNullFromProvides(CharacteristicModule.INSTANCE.provideHeartRateCharacteristic(bleScopeContext));
  }
}
