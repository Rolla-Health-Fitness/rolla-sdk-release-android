package app.rolla.bluetoothSdk.commands.data

enum class ActivityStatus {
    STARTING,
    STARTED,
    FINISHING,
    FINISHED
}