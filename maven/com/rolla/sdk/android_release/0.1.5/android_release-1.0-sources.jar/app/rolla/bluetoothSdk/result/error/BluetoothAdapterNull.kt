package app.rolla.bluetoothSdk.result.error

/**
 * Error class for when Bluetooth adapter is null
 */
class BluetoothAdapterNull : Error(ErrorCodes.BLUETOOTH_ADAPTER_NULL, "Bluetooth adapter is null")