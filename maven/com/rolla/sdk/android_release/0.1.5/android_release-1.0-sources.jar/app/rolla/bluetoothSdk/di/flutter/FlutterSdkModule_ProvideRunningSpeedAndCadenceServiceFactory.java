package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.characteristics.RunningSpeedCadenceCharacteristic;
import app.rolla.bluetoothSdk.services.RunningSpeedAndCadenceService;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideRunningSpeedAndCadenceServiceFactory implements Factory<RunningSpeedAndCadenceService> {
  private final Provider<RunningSpeedCadenceCharacteristic> runningSpeedCadenceCharacteristicProvider;

  private FlutterSdkModule_ProvideRunningSpeedAndCadenceServiceFactory(
      Provider<RunningSpeedCadenceCharacteristic> runningSpeedCadenceCharacteristicProvider) {
    this.runningSpeedCadenceCharacteristicProvider = runningSpeedCadenceCharacteristicProvider;
  }

  @Override
  public RunningSpeedAndCadenceService get() {
    return provideRunningSpeedAndCadenceService(runningSpeedCadenceCharacteristicProvider.get());
  }

  public static FlutterSdkModule_ProvideRunningSpeedAndCadenceServiceFactory create(
      Provider<RunningSpeedCadenceCharacteristic> runningSpeedCadenceCharacteristicProvider) {
    return new FlutterSdkModule_ProvideRunningSpeedAndCadenceServiceFactory(runningSpeedCadenceCharacteristicProvider);
  }

  public static RunningSpeedAndCadenceService provideRunningSpeedAndCadenceService(
      RunningSpeedCadenceCharacteristic runningSpeedCadenceCharacteristic) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideRunningSpeedAndCadenceService(runningSpeedCadenceCharacteristic));
  }
}
