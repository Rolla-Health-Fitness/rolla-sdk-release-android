package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.characteristics.SerialNumberCharacteristic;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideSerialNumberCharacteristicFactory implements Factory<SerialNumberCharacteristic> {
  private final Provider<CoroutineContext> coroutineContextProvider;

  private FlutterSdkModule_ProvideSerialNumberCharacteristicFactory(
      Provider<CoroutineContext> coroutineContextProvider) {
    this.coroutineContextProvider = coroutineContextProvider;
  }

  @Override
  public SerialNumberCharacteristic get() {
    return provideSerialNumberCharacteristic(coroutineContextProvider.get());
  }

  public static FlutterSdkModule_ProvideSerialNumberCharacteristicFactory create(
      Provider<CoroutineContext> coroutineContextProvider) {
    return new FlutterSdkModule_ProvideSerialNumberCharacteristicFactory(coroutineContextProvider);
  }

  public static SerialNumberCharacteristic provideSerialNumberCharacteristic(
      CoroutineContext coroutineContext) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideSerialNumberCharacteristic(coroutineContext));
  }
}
