package app.rolla.bluetoothSdk.connect.timeout

import app.rolla.bluetoothSdk.di.BleScopeContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

@Singleton
class EarlyConnectTimeoutManager @Inject constructor(
    @BleScopeContext bleScopeContext: CoroutineContext
) : TimeoutManager(bleScopeContext) {

    companion object {
        const val TAG = "EarlyConnectTimeoutManager"
        private const val EARLY_CONNECTION_TIMEOUT_MS = 10_000L // 10 seconds
    }

    override fun getTag(): String = TAG

    override fun getTimeoutMs(): Long = EARLY_CONNECTION_TIMEOUT_MS
}