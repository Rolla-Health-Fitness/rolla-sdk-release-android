package app.rolla.bluetoothSdk.services;

import app.rolla.bluetoothSdk.characteristics.HeartRateCharacteristic;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class HeartRateService_Factory implements Factory<HeartRateService> {
  private final Provider<HeartRateCharacteristic> heartRateCharacteristicProvider;

  private HeartRateService_Factory(
      Provider<HeartRateCharacteristic> heartRateCharacteristicProvider) {
    this.heartRateCharacteristicProvider = heartRateCharacteristicProvider;
  }

  @Override
  public HeartRateService get() {
    return newInstance(heartRateCharacteristicProvider.get());
  }

  public static HeartRateService_Factory create(
      Provider<HeartRateCharacteristic> heartRateCharacteristicProvider) {
    return new HeartRateService_Factory(heartRateCharacteristicProvider);
  }

  public static HeartRateService newInstance(HeartRateCharacteristic heartRateCharacteristic) {
    return new HeartRateService(heartRateCharacteristic);
  }
}
