package app.rolla.bluetoothSdk.di;

import app.rolla.bluetoothSdk.scan.manager.ScanStateManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ScanModule_ProvideScanStateManagerFactory implements Factory<ScanStateManager> {
  @Override
  public ScanStateManager get() {
    return provideScanStateManager();
  }

  public static ScanModule_ProvideScanStateManagerFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static ScanStateManager provideScanStateManager() {
    return Preconditions.checkNotNullFromProvides(ScanModule.INSTANCE.provideScanStateManager());
  }

  private static final class InstanceHolder {
    static final ScanModule_ProvideScanStateManagerFactory INSTANCE = new ScanModule_ProvideScanStateManagerFactory();
  }
}
