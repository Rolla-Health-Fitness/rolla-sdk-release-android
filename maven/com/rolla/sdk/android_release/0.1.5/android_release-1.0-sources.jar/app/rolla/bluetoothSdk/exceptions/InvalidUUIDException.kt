package app.rolla.bluetoothSdk.exceptions

class InvalidUUIDException(message: String) : Exception(
    message,
    Throwable(),
    false,
    true
)