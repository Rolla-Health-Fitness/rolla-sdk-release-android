package app.rolla.bluetoothSdk.result.error

class WriteFailed(status: Int?) : Error (
    code = ErrorCodes.WRITE_FAILED,
    message = "Write failed - status: $status"
)