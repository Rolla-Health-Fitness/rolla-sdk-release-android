package app.rolla.bluetoothSdk.di.flutter;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import app.rolla.bluetoothSdk.BleManager;
import app.rolla.bluetoothSdk.BleRegistry;
import app.rolla.bluetoothSdk.connect.BleConnector;
import app.rolla.bluetoothSdk.device.DeviceManager;
import app.rolla.bluetoothSdk.scan.manager.ScanManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideBleManagerFactory implements Factory<BleManager> {
  private final Provider<Context> contextProvider;

  private final Provider<BluetoothAdapter> bluetoothAdapterProvider;

  private final Provider<ScanManager> scanManagerProvider;

  private final Provider<BleConnector> bleConnectorProvider;

  private final Provider<DeviceManager> deviceManagerProvider;

  private final Provider<BleRegistry> bleRegistryProvider;

  private final Provider<CoroutineContext> coroutineContextProvider;

  private FlutterSdkModule_ProvideBleManagerFactory(Provider<Context> contextProvider,
      Provider<BluetoothAdapter> bluetoothAdapterProvider,
      Provider<ScanManager> scanManagerProvider, Provider<BleConnector> bleConnectorProvider,
      Provider<DeviceManager> deviceManagerProvider, Provider<BleRegistry> bleRegistryProvider,
      Provider<CoroutineContext> coroutineContextProvider) {
    this.contextProvider = contextProvider;
    this.bluetoothAdapterProvider = bluetoothAdapterProvider;
    this.scanManagerProvider = scanManagerProvider;
    this.bleConnectorProvider = bleConnectorProvider;
    this.deviceManagerProvider = deviceManagerProvider;
    this.bleRegistryProvider = bleRegistryProvider;
    this.coroutineContextProvider = coroutineContextProvider;
  }

  @Override
  public BleManager get() {
    return provideBleManager(contextProvider.get(), bluetoothAdapterProvider.get(), scanManagerProvider.get(), bleConnectorProvider.get(), deviceManagerProvider.get(), bleRegistryProvider.get(), coroutineContextProvider.get());
  }

  public static FlutterSdkModule_ProvideBleManagerFactory create(Provider<Context> contextProvider,
      Provider<BluetoothAdapter> bluetoothAdapterProvider,
      Provider<ScanManager> scanManagerProvider, Provider<BleConnector> bleConnectorProvider,
      Provider<DeviceManager> deviceManagerProvider, Provider<BleRegistry> bleRegistryProvider,
      Provider<CoroutineContext> coroutineContextProvider) {
    return new FlutterSdkModule_ProvideBleManagerFactory(contextProvider, bluetoothAdapterProvider, scanManagerProvider, bleConnectorProvider, deviceManagerProvider, bleRegistryProvider, coroutineContextProvider);
  }

  public static BleManager provideBleManager(Context context,
      @Nullable BluetoothAdapter bluetoothAdapter, ScanManager scanManager,
      BleConnector bleConnector, DeviceManager deviceManager, BleRegistry bleRegistry,
      CoroutineContext coroutineContext) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideBleManager(context, bluetoothAdapter, scanManager, bleConnector, deviceManager, bleRegistry, coroutineContext));
  }
}
