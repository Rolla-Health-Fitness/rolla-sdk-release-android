package app.rolla.bluetoothSdk.characteristics.data

import app.rolla.bluetoothSdk.commands.data.FirmwareState
import app.rolla.bluetoothSdk.result.error.Error

data class FirmwareStateData (
    var uuid: String,
    var dfuUuid: String,
    var state: FirmwareState,
    var error: Error? = null
) {
    override fun toString(): String {
        return "FirmwareStateData(uuid=$uuid, dfuUuid=$dfuUuid, state=$state, error=$error)"
    }
}