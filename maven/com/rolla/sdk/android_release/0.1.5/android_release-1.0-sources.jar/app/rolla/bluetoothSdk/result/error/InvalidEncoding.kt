package app.rolla.bluetoothSdk.result.error

class InvalidEncoding(throwable: Throwable? = null) : Error (
    code = ErrorCodes.INVALID_ENCODING,
    message = "Invalid firmware revision data encoding",
    exception = throwable
)