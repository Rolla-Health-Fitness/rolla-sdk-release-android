package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.connect.reconnect.AutoReconnectStrategy;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideAutoReconnectStrategyFactory implements Factory<AutoReconnectStrategy> {
  private final Provider<CoroutineContext> contextProvider;

  private FlutterSdkModule_ProvideAutoReconnectStrategyFactory(
      Provider<CoroutineContext> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public AutoReconnectStrategy get() {
    return provideAutoReconnectStrategy(contextProvider.get());
  }

  public static FlutterSdkModule_ProvideAutoReconnectStrategyFactory create(
      Provider<CoroutineContext> contextProvider) {
    return new FlutterSdkModule_ProvideAutoReconnectStrategyFactory(contextProvider);
  }

  public static AutoReconnectStrategy provideAutoReconnectStrategy(CoroutineContext context) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideAutoReconnectStrategy(context));
  }
}
