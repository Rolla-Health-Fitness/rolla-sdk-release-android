package app.rolla.bluetoothSdk.scan.manager

import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.scan.error.ScanError
import app.rolla.bluetoothSdk.scan.state.ScanState
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ScanStateManager @Inject constructor() {
    
    private val _scanResults = MutableSharedFlow<BleDevice>(replay = 1)
    val scanResults: SharedFlow<BleDevice> = _scanResults

    private val _scanErrors = MutableSharedFlow<ScanError>(replay = 1)
    val scanErrors: SharedFlow<ScanError> = _scanErrors

    private val _scanState = MutableStateFlow<ScanState>(ScanState.Idle)
    val scanState: StateFlow<ScanState> = _scanState.asStateFlow()

    fun isScanning(): Boolean = _scanState.value == ScanState.Scanning

    fun updateState(state: ScanState) {
        _scanState.value = state
    }

    suspend fun emitResult(device: BleDevice) {
        _scanResults.emit(device)
    }

    suspend fun emitError(error: ScanError) {
        _scanErrors.emit(error)
    }

    fun clear() {
        updateState(ScanState.Idle)
    }
}