package app.rolla.bluetoothSdk.scan.manager

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.di.BleScopeContext
import app.rolla.bluetoothSdk.result.MethodResult
import app.rolla.bluetoothSdk.result.error.AlreadyScanning
import app.rolla.bluetoothSdk.result.error.BluetoothLeScannerNotAvailable
import app.rolla.bluetoothSdk.result.error.BluetoothScanPermissionMissing
import app.rolla.bluetoothSdk.result.error.MaxScanAttemptsReached
import app.rolla.bluetoothSdk.result.error.ScanningAlreadyStopped
import app.rolla.bluetoothSdk.scan.error.ScanError
import app.rolla.bluetoothSdk.scan.state.ScanState
import app.rolla.bluetoothSdk.utils.executeWithBluetoothConnect
import app.rolla.bluetoothSdk.utils.executeWithBluetoothScan
import app.rolla.bluetoothSdk.utils.log
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

@Singleton
class ScanOperationManager @Inject constructor(
    @param:ApplicationContext private val context: Context,
    private val bluetoothAdapter: BluetoothAdapter?,
    private val stateManager: ScanStateManager,
    private val throttleManager: ScanThrottleManager,
    private val configManager: ScanConfigurationManager,
    @param:BleScopeContext private val coroutineContext: CoroutineContext
) {
    companion object {
        private const val TAG = "ScanOperationManager"
    }

    private val scanScope = CoroutineScope(coroutineContext)
    private var scanJob: Job? = null

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult?) {
            result?.let { processResult(it) }
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>?) {
            results?.forEach { processResult(it) }
        }

        override fun onScanFailed(errorCode: Int) {
            handleScanFailed(errorCode)
        }

        @SuppressLint("MissingPermission")
        private fun processResult(result: ScanResult) {
            if (result.scanRecord?.serviceUuids?.isNotEmpty() == true) {
                scanScope.launch {
                    stateManager.emitResult(BleDevice(result))
                }
            } else {
                context.executeWithBluetoothConnect(
                    operation = {
                        log(TAG, "Device ${result.device.name} with address ${result.device.address} doesn't have exposed service UUIDs")
                    },
                    onPermissionDenied = {
                        log(TAG, "Missing BLUETOOTH_CONNECT permission for processing scan result")
                    }
                )
            }
        }
    }

    private val bluetoothScanner: BluetoothLeScanner?
        get() = bluetoothAdapter?.bluetoothLeScanner

    @SuppressLint("MissingPermission")
    fun startScanOperation(uuids: List<String> = emptyList()): MethodResult {
        log(TAG, "Starting scan with ${uuids.size} UUIDs")
        val scanner = bluetoothScanner
        if (scanner == null) {
            return MethodResult(false, BluetoothLeScannerNotAvailable())
        }

        if (stateManager.isScanning()) {
            return MethodResult(false, AlreadyScanning())
        }

        if (!throttleManager.canStartScan()) {
            return MethodResult(false, MaxScanAttemptsReached())
        }

        val settings = configManager.createScanSettings()
        return context.executeWithBluetoothScan(
            operation = {
                val scanFilters = configManager.createScanFilters(uuids)
                scanner.startScan(scanFilters, settings, scanCallback)
                startScanTimeoutTimer()
                stateManager.updateState(ScanState.Scanning)
                throttleManager.recordScanAttempt()
                MethodResult(true)
            },
            onPermissionDenied = { e ->
                log(TAG, "BLUETOOTH_SCAN permission denied: ${e.message}")
                MethodResult(false, BluetoothScanPermissionMissing(e))
            }
        )
    }

    @SuppressLint("MissingPermission")
    fun stopScanOperation(): MethodResult {
        val scanner = bluetoothScanner
        if (scanner == null) {
            return MethodResult(false, BluetoothLeScannerNotAvailable())
        }
        if (stateManager.isScanning()) {
            context.executeWithBluetoothScan(
                operation = {
                    scanner.stopScan(scanCallback)
                    scanJob?.cancel()
                    scanJob = null
                    stateManager.updateState(ScanState.Stopped)
                    return MethodResult(true)
                },
                onPermissionDenied = { e ->
                    log(TAG, "BLUETOOTH_SCAN permission denied: ${e.message}")
                    return MethodResult(false, BluetoothScanPermissionMissing(e))
                }
            )
        } else {
            return MethodResult(false, ScanningAlreadyStopped())
        }
    }

    private fun startScanTimeoutTimer() {
        scanJob?.cancel()
        scanJob = scanScope.launch {
            try {
                delay(configManager.getScanDuration())
                stopScanOperation()
            } catch (e: Exception) {
                log(TAG, "Timer stopped: ${e.message}")
            }
        }
    }

    private fun handleScanFailed(errorCode: Int) {
        scanScope.launch {
            val errorMessage = ScanError.getErrorDescription(errorCode)
            stateManager.emitError(ScanError(errorCode, errorMessage))
            stateManager.updateState(ScanState.Failed(errorCode, errorMessage))
            scanJob?.cancel()
            scanJob = null
        }
    }

    fun clear() {
        stopScanOperation()
        scanJob?.cancel()
        scanJob = null
        stateManager.clear()
        configManager.clear()
        throttleManager.clear()
    }

}