package app.rolla.bluetoothSdk.di;

import app.rolla.bluetoothSdk.connect.reconnect.AutoReconnectStrategy;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("app.rolla.bluetoothSdk.di.BleScopeContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BluetoothModule_ProvideAutoReconnectStrategyFactory implements Factory<AutoReconnectStrategy> {
  private final Provider<CoroutineContext> contextProvider;

  private BluetoothModule_ProvideAutoReconnectStrategyFactory(
      Provider<CoroutineContext> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public AutoReconnectStrategy get() {
    return provideAutoReconnectStrategy(contextProvider.get());
  }

  public static BluetoothModule_ProvideAutoReconnectStrategyFactory create(
      Provider<CoroutineContext> contextProvider) {
    return new BluetoothModule_ProvideAutoReconnectStrategyFactory(contextProvider);
  }

  public static AutoReconnectStrategy provideAutoReconnectStrategy(CoroutineContext context) {
    return Preconditions.checkNotNullFromProvides(BluetoothModule.INSTANCE.provideAutoReconnectStrategy(context));
  }
}
