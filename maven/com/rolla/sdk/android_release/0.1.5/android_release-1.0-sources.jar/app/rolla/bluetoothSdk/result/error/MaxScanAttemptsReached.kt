package app.rolla.bluetoothSdk.result.error

class MaxScanAttemptsReached : Error (
    code = ErrorCodes.MAX_SCAN_ATTEMPTS_REACHED,
    message = "Max scan attempts reached"
) {
}