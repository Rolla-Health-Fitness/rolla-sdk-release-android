package app.rolla.bluetoothSdk.device.types

import app.rolla.bluetoothSdk.device.DeviceType
import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DeviceTypeManager @Inject constructor(
    private val storageManager: DeviceStorageManager
) {
    companion object {
        private const val TAG = "DeviceTypeManager"
    }

    private var allowedDeviceTypes = setOf<DeviceType>()


    /**
     * Sets the allowed device types for filtering.
     */
    fun setAllowedDeviceTypes(types: Set<DeviceType>) {
        allowedDeviceTypes = types
    }

    fun getAllowedDeviceTypes(): Set<DeviceType> = allowedDeviceTypes

    /**
     * Check device type conflicts for connection
     */
    fun getConflictTypes(deviceTypes: Set<DeviceType>, deviceAddress: String): Set<DeviceType> {
        return deviceTypes.filter { type ->
            storageManager.getAllDevices().any { device ->
                device.hasTypeConflicts(deviceAddress, type)
            }
        }.toSet()
    }


    /**
     * Get device type subscriptions
     */
    fun getReservedTypes(): Map<DeviceType, String> {
        val subscriptions = mutableMapOf<DeviceType, String>()
        storageManager.getAllDevices().forEach { device ->
            if (device.isConnected() || device.isConnecting()) {
                device.scannedDeviceTypes.forEach { deviceType ->
                    subscriptions[deviceType] = device.getMacAddress()
                }
            }
        }
        return subscriptions
    }

    /**
     * Gets device types that are available for assignment to the specified device.
     * A device type is considered "free" if:
     * 1. It's not already assigned to this device
     * 2. It's not reserved by another device
     *
     * @param macAddress The MAC address of the device requesting the types
     * @param currentDeviceTypes Device types currently assigned to this device
     * @param requestedDeviceTypes Device types being requested for assignment
     * @return Set of device types that can be safely assigned to this device
     */
    fun getAvailableDeviceTypes(
        macAddress: String,
        currentDeviceTypes: Set<DeviceType>,
        requestedDeviceTypes: Set<DeviceType>
    ): Set<DeviceType> {
        val reservedTypes = getReservedTypes()

        return requestedDeviceTypes.filter { type ->
            val isNotAlreadyAssigned = !currentDeviceTypes.contains(type)
            val isNotReservedByOther = reservedTypes[type] == null || reservedTypes[type] == macAddress

            isNotAlreadyAssigned && isNotReservedByOther
        }.toSet()
    }

}