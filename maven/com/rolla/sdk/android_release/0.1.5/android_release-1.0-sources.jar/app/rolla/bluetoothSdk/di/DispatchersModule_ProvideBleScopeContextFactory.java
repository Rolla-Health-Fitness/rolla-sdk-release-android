package app.rolla.bluetoothSdk.di;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;
import kotlinx.coroutines.CoroutineDispatcher;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata({
    "app.rolla.bluetoothSdk.di.BleScopeContext",
    "app.rolla.bluetoothSdk.di.IoDispatcher"
})
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DispatchersModule_ProvideBleScopeContextFactory implements Factory<CoroutineContext> {
  private final Provider<CoroutineDispatcher> ioDispatcherProvider;

  private DispatchersModule_ProvideBleScopeContextFactory(
      Provider<CoroutineDispatcher> ioDispatcherProvider) {
    this.ioDispatcherProvider = ioDispatcherProvider;
  }

  @Override
  public CoroutineContext get() {
    return provideBleScopeContext(ioDispatcherProvider.get());
  }

  public static DispatchersModule_ProvideBleScopeContextFactory create(
      Provider<CoroutineDispatcher> ioDispatcherProvider) {
    return new DispatchersModule_ProvideBleScopeContextFactory(ioDispatcherProvider);
  }

  public static CoroutineContext provideBleScopeContext(CoroutineDispatcher ioDispatcher) {
    return Preconditions.checkNotNullFromProvides(DispatchersModule.INSTANCE.provideBleScopeContext(ioDispatcher));
  }
}
