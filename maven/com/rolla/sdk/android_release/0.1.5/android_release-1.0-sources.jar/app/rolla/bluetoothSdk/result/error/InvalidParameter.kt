package app.rolla.bluetoothSdk.result.error

class InvalidParameter(throwable: Throwable? = null) : Error (
    code = ErrorCodes.INVALID_PARAMETER,
    message = "Invalid parameter",
    exception = throwable
)