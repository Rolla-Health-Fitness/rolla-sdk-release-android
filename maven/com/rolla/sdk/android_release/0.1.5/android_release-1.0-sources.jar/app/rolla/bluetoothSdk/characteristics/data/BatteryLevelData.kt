package app.rolla.bluetoothSdk.characteristics.data

import app.rolla.bluetoothSdk.result.error.Error

data class BatteryLevelData (
    val uuid: String,
    val batteryLevel: Int,
    val error: Error? = null
) {
    override fun toString(): String {
        return "BatteryLevel(uuid=$uuid, batteryLevel=$batteryLevel, error=$error)"
    }
}