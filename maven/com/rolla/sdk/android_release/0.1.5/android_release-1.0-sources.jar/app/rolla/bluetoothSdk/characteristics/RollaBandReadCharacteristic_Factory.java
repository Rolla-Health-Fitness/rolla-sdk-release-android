package app.rolla.bluetoothSdk.characteristics;

import app.rolla.bluetoothSdk.characteristics.impl.RollaBandImpl;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("app.rolla.bluetoothSdk.di.BleScopeContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class RollaBandReadCharacteristic_Factory implements Factory<RollaBandReadCharacteristic> {
  private final Provider<CoroutineContext> bleScopeContextProvider;

  private final Provider<RollaBandImpl> rollaBandImplProvider;

  private RollaBandReadCharacteristic_Factory(Provider<CoroutineContext> bleScopeContextProvider,
      Provider<RollaBandImpl> rollaBandImplProvider) {
    this.bleScopeContextProvider = bleScopeContextProvider;
    this.rollaBandImplProvider = rollaBandImplProvider;
  }

  @Override
  public RollaBandReadCharacteristic get() {
    return newInstance(bleScopeContextProvider.get(), rollaBandImplProvider.get());
  }

  public static RollaBandReadCharacteristic_Factory create(
      Provider<CoroutineContext> bleScopeContextProvider,
      Provider<RollaBandImpl> rollaBandImplProvider) {
    return new RollaBandReadCharacteristic_Factory(bleScopeContextProvider, rollaBandImplProvider);
  }

  public static RollaBandReadCharacteristic newInstance(CoroutineContext bleScopeContext,
      RollaBandImpl rollaBandImpl) {
    return new RollaBandReadCharacteristic(bleScopeContext, rollaBandImpl);
  }
}
