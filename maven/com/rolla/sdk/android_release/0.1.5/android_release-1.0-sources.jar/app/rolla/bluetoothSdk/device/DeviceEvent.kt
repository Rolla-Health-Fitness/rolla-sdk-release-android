package app.rolla.bluetoothSdk.device

sealed class DeviceEvent {
    data class RssiReadRequested(val device: BleDevice) : DeviceEvent()
    data class DeviceUnresponsive(val device: BleDevice) : DeviceEvent()
}