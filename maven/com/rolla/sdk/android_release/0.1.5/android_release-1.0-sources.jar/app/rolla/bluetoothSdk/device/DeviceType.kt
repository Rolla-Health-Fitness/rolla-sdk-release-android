package app.rolla.bluetoothSdk.device


/**
 * Implementations define the service UUIDs that identify a specific device type.
 */
enum class DeviceType(
    var typeState: DeviceTypeState = DeviceTypeState.UNSUBSCRIBED // Name of this device type for display purposes.
) {

    RUNNING_SPEED_AND_CADENCE(),
    HEART_RATE(),
    ROLLA_BAND()
}