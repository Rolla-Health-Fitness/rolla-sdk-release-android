package app.rolla.bluetoothSdk.result.error

class MaxConnectionsReached : Error (
    code = ErrorCodes.MAX_CONNECTIONS_REACHED,
    message = "Maximum concurrent connections reached"
)