package app.rolla.bluetoothSdk.scan.manager

import java.util.Collections
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ScanThrottleManager @Inject constructor() {
    companion object {
        const val MAX_SCAN_ATTEMPTS = 5
        const val MAX_SCAN_ATTEMPTS_TIME_MS = 30_000L
    }

    private val scanAttemptTimestamps = Collections.synchronizedList(mutableListOf<Long>())

    fun canStartScan(): Boolean {
        cleanupOutdatedAttempts()
        return scanAttemptTimestamps.size < MAX_SCAN_ATTEMPTS
    }

    fun recordScanAttempt() {
        scanAttemptTimestamps.add(System.currentTimeMillis())
    }

    private fun cleanupOutdatedAttempts() {
        val currentTime = System.currentTimeMillis()
        scanAttemptTimestamps.removeAll { currentTime - it > MAX_SCAN_ATTEMPTS_TIME_MS }
    }

    fun clear() {
        scanAttemptTimestamps.clear()
    }
}