package app.rolla.bluetoothSdk.di;

import android.content.Context;
import app.rolla.bluetoothSdk.characteristics.impl.RollaBandImpl;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata({
    "dagger.hilt.android.qualifiers.ApplicationContext",
    "app.rolla.bluetoothSdk.di.BleScopeContext"
})
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CharacteristicModule_ProvideRollaBandImplFactory implements Factory<RollaBandImpl> {
  private final Provider<Context> contextProvider;

  private final Provider<CoroutineContext> bleScopeContextProvider;

  private CharacteristicModule_ProvideRollaBandImplFactory(Provider<Context> contextProvider,
      Provider<CoroutineContext> bleScopeContextProvider) {
    this.contextProvider = contextProvider;
    this.bleScopeContextProvider = bleScopeContextProvider;
  }

  @Override
  public RollaBandImpl get() {
    return provideRollaBandImpl(contextProvider.get(), bleScopeContextProvider.get());
  }

  public static CharacteristicModule_ProvideRollaBandImplFactory create(
      Provider<Context> contextProvider, Provider<CoroutineContext> bleScopeContextProvider) {
    return new CharacteristicModule_ProvideRollaBandImplFactory(contextProvider, bleScopeContextProvider);
  }

  public static RollaBandImpl provideRollaBandImpl(Context context,
      CoroutineContext bleScopeContext) {
    return Preconditions.checkNotNullFromProvides(CharacteristicModule.INSTANCE.provideRollaBandImpl(context, bleScopeContext));
  }
}
