package app.rolla.bluetoothSdk.connect;

import android.content.Context;
import app.rolla.bluetoothSdk.device.DeviceManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata({
    "dagger.hilt.android.qualifiers.ApplicationContext",
    "app.rolla.bluetoothSdk.di.BleScopeContext"
})
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BleConnector_Factory implements Factory<BleConnector> {
  private final Provider<Context> contextProvider;

  private final Provider<DeviceManager> deviceManagerProvider;

  private final Provider<OperationQueue> operationQueueProvider;

  private final Provider<CoroutineContext> bleScopeContextProvider;

  private final Provider<ConnectionManager> connectionManagerProvider;

  private BleConnector_Factory(Provider<Context> contextProvider,
      Provider<DeviceManager> deviceManagerProvider,
      Provider<OperationQueue> operationQueueProvider,
      Provider<CoroutineContext> bleScopeContextProvider,
      Provider<ConnectionManager> connectionManagerProvider) {
    this.contextProvider = contextProvider;
    this.deviceManagerProvider = deviceManagerProvider;
    this.operationQueueProvider = operationQueueProvider;
    this.bleScopeContextProvider = bleScopeContextProvider;
    this.connectionManagerProvider = connectionManagerProvider;
  }

  @Override
  public BleConnector get() {
    return newInstance(contextProvider.get(), deviceManagerProvider.get(), operationQueueProvider.get(), bleScopeContextProvider.get(), connectionManagerProvider.get());
  }

  public static BleConnector_Factory create(Provider<Context> contextProvider,
      Provider<DeviceManager> deviceManagerProvider,
      Provider<OperationQueue> operationQueueProvider,
      Provider<CoroutineContext> bleScopeContextProvider,
      Provider<ConnectionManager> connectionManagerProvider) {
    return new BleConnector_Factory(contextProvider, deviceManagerProvider, operationQueueProvider, bleScopeContextProvider, connectionManagerProvider);
  }

  public static BleConnector newInstance(Context context, DeviceManager deviceManager,
      OperationQueue operationQueue, CoroutineContext bleScopeContext,
      ConnectionManager connectionManager) {
    return new BleConnector(context, deviceManager, operationQueue, bleScopeContext, connectionManager);
  }
}
