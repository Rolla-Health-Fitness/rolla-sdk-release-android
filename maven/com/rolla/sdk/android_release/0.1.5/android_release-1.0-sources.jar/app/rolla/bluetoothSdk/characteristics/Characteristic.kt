package app.rolla.bluetoothSdk.characteristics

import app.rolla.bluetoothSdk.commands.Command
import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.result.error.Error
import kotlinx.coroutines.CoroutineScope

/**
 * Interface representing a Bluetooth GATT characteristic with its UUID, implementation, and metadata.
 */
interface Characteristic {
    /** Bluetooth UUID of the characteristic */
    val uuid: String

    // Each implementation must provide its own scope
    val scope: CoroutineScope

    fun getPostSubscriptionCommands(): List<Command<*>> {
        return emptyList()
    }

    /**
     * Process data received from read operations.
     * @param byteArray Raw data received from the characteristic
     * @throws IllegalArgumentException if data is invalid or malformed
     */
    fun onRead(byteArray: ByteArray, device: BleDevice) {

    }

    /**
     * Process data received from notification operations.
     * @param byteArray Raw data received from the characteristic
     * @throws IllegalArgumentException if data is invalid or malformed
     */
    fun onNotify(byteArray: ByteArray, device: BleDevice) {

    }

    /**
     * Prepare and execute write operation to the characteristic.
     * Only called if canWrite is true.
     */
    fun onWrite(byteArray: ByteArray?, device: BleDevice) {

    }

    fun onError(deviceAddress: String, error: Error, value: ByteArray? = null) {

    }

    fun onDeviceConnected() {

    }
}