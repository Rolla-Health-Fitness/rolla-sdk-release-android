package app.rolla.bluetoothSdk.commands.data

enum class FirmwareState {
    IDLE,
    STARTED,
    INTERNAL_STARTED,
    ON_STARTED
}