package app.rolla.bluetoothSdk.characteristics

import app.rolla.bluetoothSdk.characteristics.RollaBandWriteCharacteristic.Companion.TAG
import app.rolla.bluetoothSdk.characteristics.impl.RollaBandImpl
import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.di.BleScopeContext
import app.rolla.bluetoothSdk.utils.getFullUUID
import app.rolla.bluetoothSdk.utils.log
import kotlinx.coroutines.CoroutineScope
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

@Singleton
class RollaBandReadCharacteristic @Inject constructor(
    @BleScopeContext bleScopeContext: CoroutineContext,
    private val rollaBandImpl: RollaBandImpl
) : Characteristic {
    override val uuid: String = "FFF7".getFullUUID()
    override val scope = CoroutineScope(bleScopeContext)

    override fun onRead(byteArray: ByteArray, device: BleDevice) {
        log(TAG, "onRead")
        rollaBandImpl.processData(byteArray, device)
    }

    override fun onNotify(byteArray: ByteArray, device: BleDevice) {
        log(TAG, "onNotify")
        rollaBandImpl.processData(byteArray, device)
    }
}