package app.rolla.bluetoothSdk.commands.data

data class Motion (
    val timestamp: Long, // Timestamp in milliseconds (UTC)
    val heartRate: Int, // Heart rate in BPM
    val spm: Int // Steps per minute
)

