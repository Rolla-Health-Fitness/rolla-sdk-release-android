package app.rolla.bluetoothSdk.services;

import app.rolla.bluetoothSdk.characteristics.RunningSpeedCadenceCharacteristic;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class RunningSpeedAndCadenceService_Factory implements Factory<RunningSpeedAndCadenceService> {
  private final Provider<RunningSpeedCadenceCharacteristic> runningSpeedCadenceCharacteristicProvider;

  private RunningSpeedAndCadenceService_Factory(
      Provider<RunningSpeedCadenceCharacteristic> runningSpeedCadenceCharacteristicProvider) {
    this.runningSpeedCadenceCharacteristicProvider = runningSpeedCadenceCharacteristicProvider;
  }

  @Override
  public RunningSpeedAndCadenceService get() {
    return newInstance(runningSpeedCadenceCharacteristicProvider.get());
  }

  public static RunningSpeedAndCadenceService_Factory create(
      Provider<RunningSpeedCadenceCharacteristic> runningSpeedCadenceCharacteristicProvider) {
    return new RunningSpeedAndCadenceService_Factory(runningSpeedCadenceCharacteristicProvider);
  }

  public static RunningSpeedAndCadenceService newInstance(
      RunningSpeedCadenceCharacteristic runningSpeedCadenceCharacteristic) {
    return new RunningSpeedAndCadenceService(runningSpeedCadenceCharacteristic);
  }
}
