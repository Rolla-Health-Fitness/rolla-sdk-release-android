package app.rolla.bluetoothSdk.characteristics.data

import app.rolla.bluetoothSdk.commands.data.Hrv

data class HrvData (
    var uuid: String = "",
    val isEndOfData: Boolean = false,
    val hasMoreData: Boolean = false,
    val hrvList: ArrayList<Hrv>,
    val lastBlockTimestamp: Long
)