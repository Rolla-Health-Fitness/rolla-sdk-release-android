package app.rolla.bluetoothSdk.scan.manager

import app.rolla.bluetoothSdk.result.MethodResult
import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.di.BleScopeContext
import app.rolla.bluetoothSdk.utils.log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext
import android.content.Context
import app.rolla.bluetoothSdk.utils.executeWithBluetoothScan
import dagger.hilt.android.qualifiers.ApplicationContext
import android.annotation.SuppressLint
import app.rolla.bluetoothSdk.scan.error.ScanError
import app.rolla.bluetoothSdk.scan.state.ScanState

/**
 * Manager class for Bluetooth LE device scanning operations.
 */
@Singleton
class ScanManager @Inject constructor(
    @param:ApplicationContext private val context: Context,
    @param:BleScopeContext private val coroutineContext: CoroutineContext,
    stateManager: ScanStateManager,
    private val configManager: ScanConfigurationManager,
    private val operationManager: ScanOperationManager
) {
    companion object {
        private const val TAG = "ScanManager"
    }

    val scanResults: SharedFlow<BleDevice> = stateManager.scanResults
    val scanErrors: SharedFlow<ScanError> = stateManager.scanErrors
    val scanState: StateFlow<ScanState> = stateManager.scanState

    // Internal state
    private val scanScope = CoroutineScope(coroutineContext)
    private val scanMutex = Mutex()

    /**
     * Starts scanning for BLE devices that advertise the specified service UUIDs.
     */
    suspend fun startScan(uuids: List<String>): MethodResult = scanMutex.withLock {
        return@withLock operationManager.startScanOperation(uuids)
    }

    fun setScanDuration(durationMs: Long): MethodResult = configManager.setScanDuration(durationMs)

    /**
     * Stops an ongoing scan operation.
     */
    suspend fun stopScan(): MethodResult = scanMutex.withLock {
        operationManager.stopScanOperation()
    }

    /**
     * Cleans up all resources used by this manager.
     */
    @SuppressLint("MissingPermission")
    fun destroy() {
        context.executeWithBluetoothScan(
            operation = {
                scanScope.launch {
                    stopScan()
                }
            },
            onPermissionDenied = { e ->
                log(TAG, "BLUETOOTH_SCAN permission denied during cleanup: ${e.message}")
            }
        )
        operationManager.clear()
    }

}