package app.rolla.bluetoothSdk.result.error

class SetUserDataError : Error (
    code = ErrorCodes.SET_USER_DATA_ERROR,
    message = "Set user data error"
)