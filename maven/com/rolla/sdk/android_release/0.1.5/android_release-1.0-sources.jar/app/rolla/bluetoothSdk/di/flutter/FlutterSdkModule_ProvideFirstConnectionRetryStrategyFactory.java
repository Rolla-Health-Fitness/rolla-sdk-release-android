package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.connect.reconnect.FirstConnectionRetryStrategy;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideFirstConnectionRetryStrategyFactory implements Factory<FirstConnectionRetryStrategy> {
  private final Provider<CoroutineContext> contextProvider;

  private FlutterSdkModule_ProvideFirstConnectionRetryStrategyFactory(
      Provider<CoroutineContext> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public FirstConnectionRetryStrategy get() {
    return provideFirstConnectionRetryStrategy(contextProvider.get());
  }

  public static FlutterSdkModule_ProvideFirstConnectionRetryStrategyFactory create(
      Provider<CoroutineContext> contextProvider) {
    return new FlutterSdkModule_ProvideFirstConnectionRetryStrategyFactory(contextProvider);
  }

  public static FirstConnectionRetryStrategy provideFirstConnectionRetryStrategy(
      CoroutineContext context) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideFirstConnectionRetryStrategy(context));
  }
}
