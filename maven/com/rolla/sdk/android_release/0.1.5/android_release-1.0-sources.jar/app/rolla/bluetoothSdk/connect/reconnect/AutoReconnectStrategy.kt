package app.rolla.bluetoothSdk.connect.reconnect

import android.bluetooth.BluetoothGatt
import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.di.BleScopeContext
import app.rolla.bluetoothSdk.utils.log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

@Singleton
class AutoReconnectStrategy @Inject constructor(
    @param:BleScopeContext private val context: CoroutineContext
) : ReconnectionStrategy {

    private val scope = CoroutineScope(context)

    companion object {
        private const val TAG = "AutoReconnectStrategy"
        private const val MAX_RECONNECT_TIME_MS = 6 * 60 * 60 * 1000L
        private const val PHASE_1_END_MS = 10 * 60 * 1000L
        private const val PHASE_1_DELAY_MS = 1_000L
        private const val PHASE_2_DELAY_MS = 5_000L
        private const val STATUS_GATT_ERROR = 133
        private const val STATUS_CONNECTION_TIMEOUT = 8
        private const val STATUS_GATT_CONN_TERMINATE_PEER_USER = 14
        private const val STATUS_GATT_CONN_TERMINATE_LOCAL_HOST = 15
        private const val STATUS_REMOTE_DISCONNECTED = 19
        private const val STATUS_LMP_RESPONSE_TIMEOUT = 22
        private const val STATUS_GATT_CONN_LMP_TIMEOUT = 34
        private const val STATUS_CONNECTION_FAILED_TO_BE_ESTABLISHED = 62
        private const val STATUS_GATT_ERROR_85 = 85
        private const val STATUS_GATT_CONN_L2C_FAILURE = 129
    }

    private val reconnectJobs = ConcurrentHashMap<String, Job>()
    private val reconnectStartTimes = ConcurrentHashMap<String, Long>()

    override fun shouldReconnect(device: BleDevice, status: Int): Boolean {
        val hasBeenConnected = device.hasBeenConnectedBefore
        val autoConnect = device.autoConnect
        val statusOk = shouldAutoReconnectStatus(status)
        val result = hasBeenConnected && autoConnect && statusOk
        return result
    }
    override fun startReconnection(device: BleDevice, status: Int, onReconnect: (BleDevice) -> Unit, onFinalFailure: (BleDevice) -> Unit) {
        val address = device.getMacAddress()

        // Cancel any existing reconnect job
        cancelReconnection(address)

        // Record start time
        reconnectStartTimes[address] = System.currentTimeMillis()

        log(TAG, "Starting auto-reconnect strategy for: $address (status: $status)")

        val reconnectJob = scope.launch {
            var attempt = 0

            while (isActive) {
                attempt++

                // Check if we've exceeded max reconnect time
                val elapsedTime = System.currentTimeMillis() - (reconnectStartTimes[address] ?: 0L)
                if (elapsedTime >= MAX_RECONNECT_TIME_MS) {
                    log(TAG, "Max reconnect time (6 hours) exceeded for $address, stopping auto-reconnect")
                    cleanup(address)
                    onFinalFailure(device)
                    break
                }

                val currentDelay = getDelayForElapsedTime(elapsedTime)

                log(TAG, "Auto-reconnect attempt $attempt for $address delay: ${currentDelay}ms")

                try {
                    delay(currentDelay)

                    // Execute reconnection attempt
                    onReconnect(device)

                    delay(10_000)

                } catch (e: Exception) {
                    log(TAG, "Auto-reconnect attempt $attempt failed for $address: ${e.message}")
                }
            }

            // Cleanup
            cleanup(address)
        }

        reconnectJobs[address] = reconnectJob
    }

    private fun getDelayForElapsedTime(elapsedMs: Long): Long {
        return when {
            elapsedMs < PHASE_1_END_MS -> PHASE_1_DELAY_MS
            else -> PHASE_2_DELAY_MS
        }
    }

    override fun cancelReconnection(deviceAddress: String) {
        cleanup(deviceAddress)
        log(TAG, "Cancelled auto-reconnect strategy for $deviceAddress")
    }

    override fun cleanup() {
        reconnectJobs.values.forEach { it.cancel() }
        reconnectJobs.clear()
        reconnectStartTimes.clear()
        log(TAG, "Cleaned up all auto-reconnect strategies")
    }

    private fun cleanup(deviceAddress: String) {
        reconnectJobs[deviceAddress]?.cancel()
        reconnectJobs.remove(deviceAddress)
        reconnectStartTimes.remove(deviceAddress)
    }

    private fun shouldAutoReconnectStatus(status: Int): Boolean {
        return when (status) {
            BluetoothGatt.GATT_SUCCESS -> false // Normal disconnection
            STATUS_GATT_ERROR -> true // 133 - GATT error
            STATUS_CONNECTION_TIMEOUT -> true // 8 - Device might come back into range
            STATUS_GATT_CONN_TERMINATE_PEER_USER -> true // 14 - Remote terminated, respect intent
            STATUS_GATT_CONN_TERMINATE_LOCAL_HOST -> true // 15 - Local terminated, don't retry
            STATUS_REMOTE_DISCONNECTED -> true // 19 - User disconnected, respect user intent
            STATUS_LMP_RESPONSE_TIMEOUT -> true // 22 - LMP timeout
            STATUS_GATT_CONN_LMP_TIMEOUT -> true // 34 - LMP timeout variant
            STATUS_CONNECTION_FAILED_TO_BE_ESTABLISHED -> true // 62 - Connection failed to establish
            STATUS_GATT_ERROR_85 -> true // 85 - Generic GATT error
            STATUS_GATT_CONN_L2C_FAILURE -> true // 129 - L2CAP failure, often transient
            else -> true // Default to reconnect for other errors
        }
    }

    fun onConnectionSuccess(deviceAddress: String) {
        cancelReconnection(deviceAddress)
        log(TAG, "Connection successful, cancelled auto-reconnect for: $deviceAddress")
    }
}