package app.rolla.bluetoothSdk.result.error

class ActivityAlreadyInProgressOrStarting : Error (
    code = ErrorCodes.ACTIVITY_ALREADY_IN_PROGRESS_OR_STARTING,
    message = "Activity already in progress or starting"
)