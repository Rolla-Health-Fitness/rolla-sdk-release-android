package app.rolla.bluetoothSdk.characteristics;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("app.rolla.bluetoothSdk.di.BleScopeContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class SerialNumberCharacteristic_Factory implements Factory<SerialNumberCharacteristic> {
  private final Provider<CoroutineContext> bleScopeContextProvider;

  private SerialNumberCharacteristic_Factory(Provider<CoroutineContext> bleScopeContextProvider) {
    this.bleScopeContextProvider = bleScopeContextProvider;
  }

  @Override
  public SerialNumberCharacteristic get() {
    return newInstance(bleScopeContextProvider.get());
  }

  public static SerialNumberCharacteristic_Factory create(
      Provider<CoroutineContext> bleScopeContextProvider) {
    return new SerialNumberCharacteristic_Factory(bleScopeContextProvider);
  }

  public static SerialNumberCharacteristic newInstance(CoroutineContext bleScopeContext) {
    return new SerialNumberCharacteristic(bleScopeContext);
  }
}
