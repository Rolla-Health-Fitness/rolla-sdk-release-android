package app.rolla.bluetoothSdk.connect

import android.annotation.SuppressLint
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCharacteristic
import android.content.Context
import android.os.Build
import app.rolla.bluetoothSdk.utils.log
import app.rolla.bluetoothSdk.utils.executeWithBluetoothConnect
import app.rolla.bluetoothSdk.utils.getFullUUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import javax.inject.Singleton
import kotlinx.coroutines.*

@Singleton
class OperationQueue(private val context: Context) {
    companion object {
        private const val TAG = "OperationQueue"
        private const val OPERATION_TIMEOUT_MS = 10_000L
    }

    private val operationQueues = ConcurrentHashMap<String, LinkedBlockingQueue<BleOperation>>()
    private val activeOperations = ConcurrentHashMap<String, BleOperation>() // Changed from Boolean to BleOperation
    private val operationTimeouts = ConcurrentHashMap<String, Job>()

    fun queueOperation(operation: BleOperation) {
        log(TAG, "queueOperation() called for ${operation.deviceAddress} - ${operation.name}")
        val queue = operationQueues.computeIfAbsent(operation.deviceAddress) {
            LinkedBlockingQueue() 
        }
        queue.offer(operation)
        processNextOperation(operation.deviceAddress)
    }

    @SuppressLint("MissingPermission")
    private fun processNextOperation(deviceAddress: String) {
        context.executeWithBluetoothConnect(
            operation = {
                // Synchronize the entire check-and-start sequence
                synchronized(activeOperations) {
                    // Don't start new operation if one is already active
                    if (activeOperations.containsKey(deviceAddress)) {
                        activeOperations[deviceAddress]?.let { activeOperation ->
                            log(TAG, "Operation ${activeOperation.name} already active for $deviceAddress, returning")
                        }
                        return@executeWithBluetoothConnect
                    }

                    val queue = operationQueues[deviceAddress] ?: return@executeWithBluetoothConnect
                    val operation = queue.poll() ?: return@executeWithBluetoothConnect

                    log(TAG, "Start operation ${operation.name} for $deviceAddress")
                    activeOperations[deviceAddress] = operation

                    // Start timeout for this operation
                    startOperationTimeout(deviceAddress, operation)

                    // Execute the operation
                    executeOperationInternal(deviceAddress, operation)
                }
            },
            onPermissionDenied = {
                log(TAG, "Missing BLUETOOTH_CONNECT permission for operation queue")
                cleanup()
            }
        )
    }

    private fun startOperationTimeout(deviceAddress: String, operation: BleOperation) {
        // Cancel any existing timeout
        operationTimeouts[deviceAddress]?.cancel()
        
        // Start new timeout (10 seconds)
        operationTimeouts[deviceAddress] = CoroutineScope(Dispatchers.IO).launch {
            delay(OPERATION_TIMEOUT_MS)
            log(TAG, "Operation ${operation.name} timed out for $deviceAddress")
            operationComplete(deviceAddress, false, -1)
        }
    }

    @SuppressLint("MissingPermission")
    fun executeOperationInternal(deviceAddress: String, operation: BleOperation) {
        when (operation) {
            is BleOperation.ReadCharacteristic -> {
                log(TAG, "Executing ReadCharacteristic for ${operation.characteristic.uuid.getFullUUID()}")
                val success = operation.gatt.readCharacteristic(operation.characteristic)
                if (!success) {
                    log(TAG, "${operation::class.simpleName} failed immediately for $deviceAddress} - ${operation.characteristic.uuid.getFullUUID()}")
                    operationComplete(deviceAddress, false, BluetoothGatt.GATT_FAILURE)
                } else {
                    log(TAG, "Operation ${operation.name} executed successfully for $deviceAddress - ${operation.characteristic.uuid.getFullUUID()}")
                }
            }
            is BleOperation.WriteCharacteristic -> {
                log(TAG, "Executing WriteCharacteristic for ${operation.characteristic.uuid.getFullUUID()}")
                val success = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    @SuppressLint("MissingPermission")
                    operation.gatt.writeCharacteristic(
                        operation.characteristic,
                        operation.data,
                        BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                    ) == android.bluetooth.BluetoothStatusCodes.SUCCESS
                } else {
                    @Suppress("DEPRECATION")
                    operation.characteristic.value = operation.data
                    @Suppress("DEPRECATION")
                    @SuppressLint("MissingPermission")
                    operation.gatt.writeCharacteristic(operation.characteristic)
                }
                if (!success) {
                    log(TAG, "${operation::class.simpleName} failed immediately for $deviceAddress} - ${operation.characteristic.uuid.getFullUUID()}")
                    operationComplete(deviceAddress, false, null)
                } else {
                    log(TAG, "Operation ${operation.name} executed successfully for $deviceAddress - ${operation.characteristic.uuid.getFullUUID()}")
                }
            }
            is BleOperation.WriteDescriptor -> {
                log(TAG, "Executing WriteDescriptor for ${operation.descriptor.uuid}, value size: ${operation.value.size}")
                val success = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    @SuppressLint("MissingPermission")
                    operation.gatt.writeDescriptor(
                        operation.descriptor,
                        operation.value
                    ) == android.bluetooth.BluetoothStatusCodes.SUCCESS
                } else {
                    @Suppress("DEPRECATION")
                    operation.descriptor.value = operation.value
                    @Suppress("DEPRECATION")
                    @SuppressLint("MissingPermission")
                    operation.gatt.writeDescriptor(operation.descriptor)
                }
                if (!success) {
                    log(TAG, "${operation::class.simpleName} failed immediately for $deviceAddress} - ${operation.descriptor.uuid.getFullUUID()}")
                    operationComplete(deviceAddress, false, null)
                } else {
                    log(TAG, "Operation ${operation.name} executed successfully for $deviceAddress - ${operation.descriptor.uuid.getFullUUID()}")
                }
            }
            is BleOperation.ReadRssi -> {
                val success = operation.gatt.readRemoteRssi()
                if (!success) {
                    log(TAG, "${operation::class.simpleName} failed immediately for $deviceAddress}")
                    operationComplete(deviceAddress, false, null)
                } else {
                    log(TAG, "Operation ${operation.name} executed successfully for $deviceAddress")
                }
            }
        }
    }

    fun operationComplete(deviceAddress: String, success: Boolean, status: Int?) {
        // Synchronize the completion and next operation start
        synchronized(activeOperations) {
            log(TAG, "operationComplete() called for $deviceAddress - success: $success, status: $status")
            // Cancel timeout
            operationTimeouts.remove(deviceAddress)?.cancel()
            // Get and remove the active operation
            val activeOperation = activeOperations.remove(deviceAddress)
            if (activeOperation != null) {
                log(TAG, "Completing operation: ${activeOperation.name}")
                activeOperation.onComplete(success, status)
            } else {
                log(TAG, "No active operation found for $deviceAddress")
            }
        }
        
        // Process next operation outside the synchronized block to avoid deadlock
        processNextOperation(deviceAddress)
    }

    fun clearQueue(deviceAddress: String) {
        val activeOperation = activeOperations.remove(deviceAddress)
        activeOperation?.onComplete(false, null)

        operationQueues.remove(deviceAddress)?.let { queue ->
           queue.forEach { operation ->
                operation.onComplete(false, null)
            }
        }
    }

    fun cleanup() {
        activeOperations.values.forEach { operation ->
            operation.onComplete(false, null)
        }
        activeOperations.clear()

        operationQueues.values.forEach { queue ->
            queue.forEach { operation ->
                operation.onComplete(false, null)
            }
        }
        operationQueues.clear()
    }
}
