package app.rolla.bluetoothSdk.commands.data

import app.rolla.bluetoothSdk.utils.BcdTime

data class PassiveHeartRateRecord(
    val dataNumber: Int,
    val bcdTime: BcdTime,
    val heartRate: Int,
    val timeInMilliseconds: Long,
    val offset: Int
)