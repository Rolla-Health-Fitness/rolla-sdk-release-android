package app.rolla.bluetoothSdk.di;

import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager;
import app.rolla.bluetoothSdk.device.types.DeviceTypeManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DeviceModule_ProvideDeviceTypeManagerFactory implements Factory<DeviceTypeManager> {
  private final Provider<DeviceStorageManager> deviceStorageManagerProvider;

  private DeviceModule_ProvideDeviceTypeManagerFactory(
      Provider<DeviceStorageManager> deviceStorageManagerProvider) {
    this.deviceStorageManagerProvider = deviceStorageManagerProvider;
  }

  @Override
  public DeviceTypeManager get() {
    return provideDeviceTypeManager(deviceStorageManagerProvider.get());
  }

  public static DeviceModule_ProvideDeviceTypeManagerFactory create(
      Provider<DeviceStorageManager> deviceStorageManagerProvider) {
    return new DeviceModule_ProvideDeviceTypeManagerFactory(deviceStorageManagerProvider);
  }

  public static DeviceTypeManager provideDeviceTypeManager(
      DeviceStorageManager deviceStorageManager) {
    return Preconditions.checkNotNullFromProvides(DeviceModule.INSTANCE.provideDeviceTypeManager(deviceStorageManager));
  }
}
