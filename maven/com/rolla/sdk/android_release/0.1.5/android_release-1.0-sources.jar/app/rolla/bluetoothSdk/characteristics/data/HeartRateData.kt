package app.rolla.bluetoothSdk.characteristics.data

import app.rolla.bluetoothSdk.commands.data.HeartRate

data class HeartRateData (
    var uuid: String = "",
    val isEndOfData: Boolean = false,
    val hasMoreData: Boolean = false,
    val heartRates: ArrayList<HeartRate> = arrayListOf(),
)