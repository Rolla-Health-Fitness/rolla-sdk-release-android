package app.rolla.bluetoothSdk.device.storage;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DeviceStorageManager_Factory implements Factory<DeviceStorageManager> {
  @Override
  public DeviceStorageManager get() {
    return newInstance();
  }

  public static DeviceStorageManager_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static DeviceStorageManager newInstance() {
    return new DeviceStorageManager();
  }

  private static final class InstanceHolder {
    static final DeviceStorageManager_Factory INSTANCE = new DeviceStorageManager_Factory();
  }
}
