package app.rolla.bluetoothSdk.di;

import app.rolla.bluetoothSdk.characteristics.HeartRateCharacteristic;
import app.rolla.bluetoothSdk.services.HeartRateService;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ServiceModule_ProvideHeartRateServiceFactory implements Factory<HeartRateService> {
  private final Provider<HeartRateCharacteristic> heartRateCharacteristicProvider;

  private ServiceModule_ProvideHeartRateServiceFactory(
      Provider<HeartRateCharacteristic> heartRateCharacteristicProvider) {
    this.heartRateCharacteristicProvider = heartRateCharacteristicProvider;
  }

  @Override
  public HeartRateService get() {
    return provideHeartRateService(heartRateCharacteristicProvider.get());
  }

  public static ServiceModule_ProvideHeartRateServiceFactory create(
      Provider<HeartRateCharacteristic> heartRateCharacteristicProvider) {
    return new ServiceModule_ProvideHeartRateServiceFactory(heartRateCharacteristicProvider);
  }

  public static HeartRateService provideHeartRateService(
      HeartRateCharacteristic heartRateCharacteristic) {
    return Preconditions.checkNotNullFromProvides(ServiceModule.INSTANCE.provideHeartRateService(heartRateCharacteristic));
  }
}
