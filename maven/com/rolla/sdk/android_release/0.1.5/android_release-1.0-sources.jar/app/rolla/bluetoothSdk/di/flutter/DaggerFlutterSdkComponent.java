package app.rolla.bluetoothSdk.di.flutter;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import app.rolla.bluetoothSdk.BleManager;
import app.rolla.bluetoothSdk.BleRegistry;
import app.rolla.bluetoothSdk.characteristics.FirmwareRevisionCharacteristic;
import app.rolla.bluetoothSdk.characteristics.HeartRateCharacteristic;
import app.rolla.bluetoothSdk.characteristics.RollaBandReadCharacteristic;
import app.rolla.bluetoothSdk.characteristics.RollaBandWriteCharacteristic;
import app.rolla.bluetoothSdk.characteristics.RunningSpeedCadenceCharacteristic;
import app.rolla.bluetoothSdk.characteristics.SerialNumberCharacteristic;
import app.rolla.bluetoothSdk.characteristics.impl.RollaBandImpl;
import app.rolla.bluetoothSdk.connect.BleConnector;
import app.rolla.bluetoothSdk.connect.ConnectionManager;
import app.rolla.bluetoothSdk.connect.OperationQueue;
import app.rolla.bluetoothSdk.connect.SubscriptionManager;
import app.rolla.bluetoothSdk.connect.reconnect.AutoReconnectStrategy;
import app.rolla.bluetoothSdk.connect.reconnect.FirstConnectionRetryStrategy;
import app.rolla.bluetoothSdk.connect.reconnect.ReconnectionManager;
import app.rolla.bluetoothSdk.connect.timeout.ConnectTimeoutManager;
import app.rolla.bluetoothSdk.connect.timeout.DisconnectTimeoutManager;
import app.rolla.bluetoothSdk.connect.timeout.EarlyConnectTimeoutManager;
import app.rolla.bluetoothSdk.device.DeviceManager;
import app.rolla.bluetoothSdk.device.monitoring.DeviceMonitoringManager;
import app.rolla.bluetoothSdk.device.state.DeviceStateManager;
import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager;
import app.rolla.bluetoothSdk.device.types.DeviceTypeManager;
import app.rolla.bluetoothSdk.scan.manager.ScanConfigurationManager;
import app.rolla.bluetoothSdk.scan.manager.ScanManager;
import app.rolla.bluetoothSdk.scan.manager.ScanOperationManager;
import app.rolla.bluetoothSdk.scan.manager.ScanStateManager;
import app.rolla.bluetoothSdk.scan.manager.ScanThrottleManager;
import app.rolla.bluetoothSdk.services.DeviceFirmwareUpdateService;
import app.rolla.bluetoothSdk.services.DeviceInformationService;
import app.rolla.bluetoothSdk.services.HeartRateService;
import app.rolla.bluetoothSdk.services.RollaBandService;
import app.rolla.bluetoothSdk.services.RunningSpeedAndCadenceService;
import app.rolla.bluetoothSdk.steps.RealTimeStepCalculator;
import dagger.internal.DaggerGenerated;
import dagger.internal.DoubleCheck;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DaggerFlutterSdkComponent {
  private DaggerFlutterSdkComponent() {
  }

  public static FlutterSdkComponent.Builder builder() {
    return new Builder();
  }

  private static final class Builder implements FlutterSdkComponent.Builder {
    private Context applicationContext;

    @Override
    public Builder applicationContext(Context context) {
      this.applicationContext = Preconditions.checkNotNull(context);
      return this;
    }

    @Override
    public FlutterSdkComponent build() {
      Preconditions.checkBuilderRequirement(applicationContext, Context.class);
      return new FlutterSdkComponentImpl(applicationContext);
    }
  }

  private static final class FlutterSdkComponentImpl implements FlutterSdkComponent {
    private final Context applicationContext;

    private final FlutterSdkComponentImpl flutterSdkComponentImpl = this;

    Provider<BluetoothManager> provideBluetoothManagerProvider;

    Provider<BluetoothAdapter> provideBluetoothAdapterProvider;

    Provider<CoroutineContext> provideBleScopeContextProvider;

    Provider<ScanStateManager> provideScanStateManagerProvider;

    Provider<ScanConfigurationManager> provideScanConfigurationManagerProvider;

    Provider<ScanThrottleManager> provideScanThrottleManagerProvider;

    Provider<ScanOperationManager> provideScanOperationManagerProvider;

    Provider<ScanManager> provideScanManagerProvider;

    Provider<DeviceStorageManager> provideDeviceStorageManagerProvider;

    Provider<DeviceTypeManager> provideDeviceTypeManagerProvider;

    Provider<DeviceStateManager> provideDeviceStateManagerProvider;

    Provider<DeviceMonitoringManager> provideDeviceMonitoringManagerProvider;

    Provider<DeviceManager> provideDeviceManagerProvider;

    Provider<OperationQueue> provideOperationQueueProvider;

    Provider<HeartRateCharacteristic> provideHeartRateCharacteristicProvider;

    Provider<HeartRateService> provideHeartRateServiceProvider;

    Provider<RealTimeStepCalculator> provideRealTimeStepCalculatorProvider;

    Provider<RunningSpeedCadenceCharacteristic> provideRunningSpeedCadenceCharacteristicProvider;

    Provider<RunningSpeedAndCadenceService> provideRunningSpeedAndCadenceServiceProvider;

    Provider<RollaBandImpl> provideRollaBandImplProvider;

    Provider<RollaBandReadCharacteristic> provideRollaBandReadCharacteristicProvider;

    Provider<RollaBandWriteCharacteristic> provideRollaBandWriteCharacteristicProvider;

    Provider<RollaBandService> provideRollaBandServiceProvider;

    Provider<SerialNumberCharacteristic> provideSerialNumberCharacteristicProvider;

    Provider<FirmwareRevisionCharacteristic> provideFirmwareRevisionCharacteristicProvider;

    Provider<DeviceInformationService> provideDeviceInformationServiceProvider;

    Provider<DeviceFirmwareUpdateService> provideDeviceFirmwareUpdateServiceProvider;

    Provider<BleRegistry> provideBleRegistryProvider;

    Provider<SubscriptionManager> provideSubscriptionManagerProvider;

    Provider<EarlyConnectTimeoutManager> provideEarlyConnectTimeoutManagerProvider;

    Provider<ConnectTimeoutManager> provideConnectTimeoutManagerProvider;

    Provider<DisconnectTimeoutManager> provideDisconnectTimeoutManagerProvider;

    Provider<FirstConnectionRetryStrategy> provideFirstConnectionRetryStrategyProvider;

    Provider<AutoReconnectStrategy> provideAutoReconnectStrategyProvider;

    Provider<ReconnectionManager> provideReconnectionManagerProvider;

    Provider<ConnectionManager> provideConnectionManagerProvider;

    Provider<BleConnector> provideBleConnectorProvider;

    Provider<BleManager> provideBleManagerProvider;

    FlutterSdkComponentImpl(Context applicationContextParam) {
      this.applicationContext = applicationContextParam;
      initialize(applicationContextParam);
      initialize2(applicationContextParam);

    }

    @SuppressWarnings("unchecked")
    private void initialize(final Context applicationContextParam) {
      this.provideBluetoothManagerProvider = DoubleCheck.provider(new SwitchingProvider<BluetoothManager>(flutterSdkComponentImpl, 2));
      this.provideBluetoothAdapterProvider = DoubleCheck.provider(new SwitchingProvider<BluetoothAdapter>(flutterSdkComponentImpl, 1));
      this.provideBleScopeContextProvider = DoubleCheck.provider(new SwitchingProvider<CoroutineContext>(flutterSdkComponentImpl, 4));
      this.provideScanStateManagerProvider = DoubleCheck.provider(new SwitchingProvider<ScanStateManager>(flutterSdkComponentImpl, 5));
      this.provideScanConfigurationManagerProvider = DoubleCheck.provider(new SwitchingProvider<ScanConfigurationManager>(flutterSdkComponentImpl, 6));
      this.provideScanThrottleManagerProvider = DoubleCheck.provider(new SwitchingProvider<ScanThrottleManager>(flutterSdkComponentImpl, 8));
      this.provideScanOperationManagerProvider = DoubleCheck.provider(new SwitchingProvider<ScanOperationManager>(flutterSdkComponentImpl, 7));
      this.provideScanManagerProvider = DoubleCheck.provider(new SwitchingProvider<ScanManager>(flutterSdkComponentImpl, 3));
      this.provideDeviceStorageManagerProvider = DoubleCheck.provider(new SwitchingProvider<DeviceStorageManager>(flutterSdkComponentImpl, 12));
      this.provideDeviceTypeManagerProvider = DoubleCheck.provider(new SwitchingProvider<DeviceTypeManager>(flutterSdkComponentImpl, 11));
      this.provideDeviceStateManagerProvider = DoubleCheck.provider(new SwitchingProvider<DeviceStateManager>(flutterSdkComponentImpl, 14));
      this.provideDeviceMonitoringManagerProvider = DoubleCheck.provider(new SwitchingProvider<DeviceMonitoringManager>(flutterSdkComponentImpl, 13));
      this.provideDeviceManagerProvider = DoubleCheck.provider(new SwitchingProvider<DeviceManager>(flutterSdkComponentImpl, 10));
      this.provideOperationQueueProvider = DoubleCheck.provider(new SwitchingProvider<OperationQueue>(flutterSdkComponentImpl, 15));
      this.provideHeartRateCharacteristicProvider = DoubleCheck.provider(new SwitchingProvider<HeartRateCharacteristic>(flutterSdkComponentImpl, 20));
      this.provideHeartRateServiceProvider = DoubleCheck.provider(new SwitchingProvider<HeartRateService>(flutterSdkComponentImpl, 19));
      this.provideRealTimeStepCalculatorProvider = DoubleCheck.provider(new SwitchingProvider<RealTimeStepCalculator>(flutterSdkComponentImpl, 23));
      this.provideRunningSpeedCadenceCharacteristicProvider = DoubleCheck.provider(new SwitchingProvider<RunningSpeedCadenceCharacteristic>(flutterSdkComponentImpl, 22));
      this.provideRunningSpeedAndCadenceServiceProvider = DoubleCheck.provider(new SwitchingProvider<RunningSpeedAndCadenceService>(flutterSdkComponentImpl, 21));
      this.provideRollaBandImplProvider = DoubleCheck.provider(new SwitchingProvider<RollaBandImpl>(flutterSdkComponentImpl, 26));
      this.provideRollaBandReadCharacteristicProvider = DoubleCheck.provider(new SwitchingProvider<RollaBandReadCharacteristic>(flutterSdkComponentImpl, 25));
      this.provideRollaBandWriteCharacteristicProvider = DoubleCheck.provider(new SwitchingProvider<RollaBandWriteCharacteristic>(flutterSdkComponentImpl, 27));
      this.provideRollaBandServiceProvider = DoubleCheck.provider(new SwitchingProvider<RollaBandService>(flutterSdkComponentImpl, 24));
      this.provideSerialNumberCharacteristicProvider = DoubleCheck.provider(new SwitchingProvider<SerialNumberCharacteristic>(flutterSdkComponentImpl, 29));
      this.provideFirmwareRevisionCharacteristicProvider = DoubleCheck.provider(new SwitchingProvider<FirmwareRevisionCharacteristic>(flutterSdkComponentImpl, 30));
    }

    @SuppressWarnings("unchecked")
    private void initialize2(final Context applicationContextParam) {
      this.provideDeviceInformationServiceProvider = DoubleCheck.provider(new SwitchingProvider<DeviceInformationService>(flutterSdkComponentImpl, 28));
      this.provideDeviceFirmwareUpdateServiceProvider = DoubleCheck.provider(new SwitchingProvider<DeviceFirmwareUpdateService>(flutterSdkComponentImpl, 31));
      this.provideBleRegistryProvider = DoubleCheck.provider(new SwitchingProvider<BleRegistry>(flutterSdkComponentImpl, 18));
      this.provideSubscriptionManagerProvider = DoubleCheck.provider(new SwitchingProvider<SubscriptionManager>(flutterSdkComponentImpl, 17));
      this.provideEarlyConnectTimeoutManagerProvider = DoubleCheck.provider(new SwitchingProvider<EarlyConnectTimeoutManager>(flutterSdkComponentImpl, 32));
      this.provideConnectTimeoutManagerProvider = DoubleCheck.provider(new SwitchingProvider<ConnectTimeoutManager>(flutterSdkComponentImpl, 33));
      this.provideDisconnectTimeoutManagerProvider = DoubleCheck.provider(new SwitchingProvider<DisconnectTimeoutManager>(flutterSdkComponentImpl, 34));
      this.provideFirstConnectionRetryStrategyProvider = DoubleCheck.provider(new SwitchingProvider<FirstConnectionRetryStrategy>(flutterSdkComponentImpl, 36));
      this.provideAutoReconnectStrategyProvider = DoubleCheck.provider(new SwitchingProvider<AutoReconnectStrategy>(flutterSdkComponentImpl, 37));
      this.provideReconnectionManagerProvider = DoubleCheck.provider(new SwitchingProvider<ReconnectionManager>(flutterSdkComponentImpl, 35));
      this.provideConnectionManagerProvider = DoubleCheck.provider(new SwitchingProvider<ConnectionManager>(flutterSdkComponentImpl, 16));
      this.provideBleConnectorProvider = DoubleCheck.provider(new SwitchingProvider<BleConnector>(flutterSdkComponentImpl, 9));
      this.provideBleManagerProvider = DoubleCheck.provider(new SwitchingProvider<BleManager>(flutterSdkComponentImpl, 0));
    }

    @Override
    public BleManager bleManager() {
      return provideBleManagerProvider.get();
    }

    private static final class SwitchingProvider<T> implements Provider<T> {
      private final FlutterSdkComponentImpl flutterSdkComponentImpl;

      private final int id;

      SwitchingProvider(FlutterSdkComponentImpl flutterSdkComponentImpl, int id) {
        this.flutterSdkComponentImpl = flutterSdkComponentImpl;
        this.id = id;
      }

      @Override
      @SuppressWarnings("unchecked")
      public T get() {
        switch (id) {
          case 0: // app.rolla.bluetoothSdk.BleManager
          return (T) FlutterSdkModule_ProvideBleManagerFactory.provideBleManager(flutterSdkComponentImpl.applicationContext, flutterSdkComponentImpl.provideBluetoothAdapterProvider.get(), flutterSdkComponentImpl.provideScanManagerProvider.get(), flutterSdkComponentImpl.provideBleConnectorProvider.get(), flutterSdkComponentImpl.provideDeviceManagerProvider.get(), flutterSdkComponentImpl.provideBleRegistryProvider.get(), flutterSdkComponentImpl.provideBleScopeContextProvider.get());

          case 1: // android.bluetooth.BluetoothAdapter
          return (T) FlutterSdkModule.INSTANCE.provideBluetoothAdapter(flutterSdkComponentImpl.provideBluetoothManagerProvider.get());

          case 2: // android.bluetooth.BluetoothManager
          return (T) FlutterSdkModule.INSTANCE.provideBluetoothManager(flutterSdkComponentImpl.applicationContext);

          case 3: // app.rolla.bluetoothSdk.scan.manager.ScanManager
          return (T) FlutterSdkModule_ProvideScanManagerFactory.provideScanManager(flutterSdkComponentImpl.applicationContext, flutterSdkComponentImpl.provideBleScopeContextProvider.get(), flutterSdkComponentImpl.provideScanStateManagerProvider.get(), flutterSdkComponentImpl.provideScanConfigurationManagerProvider.get(), flutterSdkComponentImpl.provideScanOperationManagerProvider.get());

          case 4: // kotlin.coroutines.CoroutineContext
          return (T) FlutterSdkModule_ProvideBleScopeContextFactory.provideBleScopeContext();

          case 5: // app.rolla.bluetoothSdk.scan.manager.ScanStateManager
          return (T) FlutterSdkModule_ProvideScanStateManagerFactory.provideScanStateManager();

          case 6: // app.rolla.bluetoothSdk.scan.manager.ScanConfigurationManager
          return (T) FlutterSdkModule_ProvideScanConfigurationManagerFactory.provideScanConfigurationManager();

          case 7: // app.rolla.bluetoothSdk.scan.manager.ScanOperationManager
          return (T) FlutterSdkModule_ProvideScanOperationManagerFactory.provideScanOperationManager(flutterSdkComponentImpl.applicationContext, flutterSdkComponentImpl.provideBluetoothAdapterProvider.get(), flutterSdkComponentImpl.provideScanStateManagerProvider.get(), flutterSdkComponentImpl.provideScanThrottleManagerProvider.get(), flutterSdkComponentImpl.provideScanConfigurationManagerProvider.get(), flutterSdkComponentImpl.provideBleScopeContextProvider.get());

          case 8: // app.rolla.bluetoothSdk.scan.manager.ScanThrottleManager
          return (T) FlutterSdkModule_ProvideScanThrottleManagerFactory.provideScanThrottleManager();

          case 9: // app.rolla.bluetoothSdk.connect.BleConnector
          return (T) FlutterSdkModule_ProvideBleConnectorFactory.provideBleConnector(flutterSdkComponentImpl.applicationContext, flutterSdkComponentImpl.provideDeviceManagerProvider.get(), flutterSdkComponentImpl.provideOperationQueueProvider.get(), flutterSdkComponentImpl.provideBleScopeContextProvider.get(), flutterSdkComponentImpl.provideConnectionManagerProvider.get());

          case 10: // app.rolla.bluetoothSdk.device.DeviceManager
          return (T) FlutterSdkModule_ProvideDeviceManagerFactory.provideDeviceManager(flutterSdkComponentImpl.provideBleScopeContextProvider.get(), flutterSdkComponentImpl.provideDeviceTypeManagerProvider.get(), flutterSdkComponentImpl.provideDeviceMonitoringManagerProvider.get(), flutterSdkComponentImpl.provideDeviceStateManagerProvider.get(), flutterSdkComponentImpl.provideDeviceStorageManagerProvider.get());

          case 11: // app.rolla.bluetoothSdk.device.types.DeviceTypeManager
          return (T) FlutterSdkModule_ProvideDeviceTypeManagerFactory.provideDeviceTypeManager(flutterSdkComponentImpl.provideDeviceStorageManagerProvider.get());

          case 12: // app.rolla.bluetoothSdk.device.storage.DeviceStorageManager
          return (T) FlutterSdkModule_ProvideDeviceStorageManagerFactory.provideDeviceStorageManager();

          case 13: // app.rolla.bluetoothSdk.device.monitoring.DeviceMonitoringManager
          return (T) FlutterSdkModule_ProvideDeviceMonitoringManagerFactory.provideDeviceMonitoringManager(flutterSdkComponentImpl.provideDeviceStorageManagerProvider.get(), flutterSdkComponentImpl.provideDeviceStateManagerProvider.get(), flutterSdkComponentImpl.provideBleScopeContextProvider.get());

          case 14: // app.rolla.bluetoothSdk.device.state.DeviceStateManager
          return (T) FlutterSdkModule_ProvideDeviceStateManagerFactory.provideDeviceStateManager(flutterSdkComponentImpl.provideDeviceStorageManagerProvider.get(), flutterSdkComponentImpl.provideBleScopeContextProvider.get());

          case 15: // app.rolla.bluetoothSdk.connect.OperationQueue
          return (T) FlutterSdkModule_ProvideOperationQueueFactory.provideOperationQueue(flutterSdkComponentImpl.applicationContext);

          case 16: // app.rolla.bluetoothSdk.connect.ConnectionManager
          return (T) FlutterSdkModule_ProvideConnectionManagerFactory.provideConnectionManager(flutterSdkComponentImpl.applicationContext, flutterSdkComponentImpl.provideBleScopeContextProvider.get(), flutterSdkComponentImpl.provideBluetoothAdapterProvider.get(), flutterSdkComponentImpl.provideDeviceManagerProvider.get(), flutterSdkComponentImpl.provideOperationQueueProvider.get(), flutterSdkComponentImpl.provideSubscriptionManagerProvider.get(), flutterSdkComponentImpl.provideBleRegistryProvider.get(), flutterSdkComponentImpl.provideEarlyConnectTimeoutManagerProvider.get(), flutterSdkComponentImpl.provideConnectTimeoutManagerProvider.get(), flutterSdkComponentImpl.provideDisconnectTimeoutManagerProvider.get(), flutterSdkComponentImpl.provideReconnectionManagerProvider.get());

          case 17: // app.rolla.bluetoothSdk.connect.SubscriptionManager
          return (T) FlutterSdkModule_ProvideSubscriptionManagerFactory.provideSubscriptionManager(flutterSdkComponentImpl.provideBleScopeContextProvider.get(), flutterSdkComponentImpl.applicationContext, flutterSdkComponentImpl.provideOperationQueueProvider.get(), flutterSdkComponentImpl.provideBleRegistryProvider.get());

          case 18: // app.rolla.bluetoothSdk.BleRegistry
          return (T) FlutterSdkModule_ProvideBleRegistryFactory.provideBleRegistry(flutterSdkComponentImpl.provideHeartRateServiceProvider.get(), flutterSdkComponentImpl.provideRunningSpeedAndCadenceServiceProvider.get(), flutterSdkComponentImpl.provideRollaBandServiceProvider.get(), flutterSdkComponentImpl.provideDeviceInformationServiceProvider.get(), flutterSdkComponentImpl.provideDeviceFirmwareUpdateServiceProvider.get());

          case 19: // app.rolla.bluetoothSdk.services.HeartRateService
          return (T) FlutterSdkModule_ProvideHeartRateServiceFactory.provideHeartRateService(flutterSdkComponentImpl.provideHeartRateCharacteristicProvider.get());

          case 20: // app.rolla.bluetoothSdk.characteristics.HeartRateCharacteristic
          return (T) FlutterSdkModule_ProvideHeartRateCharacteristicFactory.provideHeartRateCharacteristic(flutterSdkComponentImpl.provideBleScopeContextProvider.get());

          case 21: // app.rolla.bluetoothSdk.services.RunningSpeedAndCadenceService
          return (T) FlutterSdkModule_ProvideRunningSpeedAndCadenceServiceFactory.provideRunningSpeedAndCadenceService(flutterSdkComponentImpl.provideRunningSpeedCadenceCharacteristicProvider.get());

          case 22: // app.rolla.bluetoothSdk.characteristics.RunningSpeedCadenceCharacteristic
          return (T) FlutterSdkModule_ProvideRunningSpeedCadenceCharacteristicFactory.provideRunningSpeedCadenceCharacteristic(flutterSdkComponentImpl.provideBleScopeContextProvider.get(), flutterSdkComponentImpl.provideRealTimeStepCalculatorProvider.get());

          case 23: // app.rolla.bluetoothSdk.steps.RealTimeStepCalculator
          return (T) FlutterSdkModule_ProvideRealTimeStepCalculatorFactory.provideRealTimeStepCalculator();

          case 24: // app.rolla.bluetoothSdk.services.RollaBandService
          return (T) FlutterSdkModule_ProvideRollaBandServiceFactory.provideRollaBandService(flutterSdkComponentImpl.provideRollaBandReadCharacteristicProvider.get(), flutterSdkComponentImpl.provideRollaBandWriteCharacteristicProvider.get());

          case 25: // app.rolla.bluetoothSdk.characteristics.RollaBandReadCharacteristic
          return (T) FlutterSdkModule_ProvideRollaBandReadCharacteristicFactory.provideRollaBandReadCharacteristic(flutterSdkComponentImpl.provideBleScopeContextProvider.get(), flutterSdkComponentImpl.provideRollaBandImplProvider.get());

          case 26: // app.rolla.bluetoothSdk.characteristics.impl.RollaBandImpl
          return (T) FlutterSdkModule_ProvideRollaBandImplFactory.provideRollaBandImpl(flutterSdkComponentImpl.applicationContext, flutterSdkComponentImpl.provideBleScopeContextProvider.get());

          case 27: // app.rolla.bluetoothSdk.characteristics.RollaBandWriteCharacteristic
          return (T) FlutterSdkModule_ProvideRollaBandWriteCharacteristicFactory.provideRollaBandWriteCharacteristic(flutterSdkComponentImpl.provideBleScopeContextProvider.get(), flutterSdkComponentImpl.provideRollaBandImplProvider.get());

          case 28: // app.rolla.bluetoothSdk.services.DeviceInformationService
          return (T) FlutterSdkModule_ProvideDeviceInformationServiceFactory.provideDeviceInformationService(flutterSdkComponentImpl.provideSerialNumberCharacteristicProvider.get(), flutterSdkComponentImpl.provideFirmwareRevisionCharacteristicProvider.get());

          case 29: // app.rolla.bluetoothSdk.characteristics.SerialNumberCharacteristic
          return (T) FlutterSdkModule_ProvideSerialNumberCharacteristicFactory.provideSerialNumberCharacteristic(flutterSdkComponentImpl.provideBleScopeContextProvider.get());

          case 30: // app.rolla.bluetoothSdk.characteristics.FirmwareRevisionCharacteristic
          return (T) FlutterSdkModule_ProvideFirmwareRevisionCharacteristicFactory.provideFirmwareRevisionCharacteristic(flutterSdkComponentImpl.provideBleScopeContextProvider.get());

          case 31: // app.rolla.bluetoothSdk.services.DeviceFirmwareUpdateService
          return (T) FlutterSdkModule_ProvideDeviceFirmwareUpdateServiceFactory.provideDeviceFirmwareUpdateService();

          case 32: // app.rolla.bluetoothSdk.connect.timeout.EarlyConnectTimeoutManager
          return (T) FlutterSdkModule_ProvideEarlyConnectTimeoutManagerFactory.provideEarlyConnectTimeoutManager(flutterSdkComponentImpl.provideBleScopeContextProvider.get());

          case 33: // app.rolla.bluetoothSdk.connect.timeout.ConnectTimeoutManager
          return (T) FlutterSdkModule_ProvideConnectTimeoutManagerFactory.provideConnectTimeoutManager(flutterSdkComponentImpl.provideBleScopeContextProvider.get());

          case 34: // app.rolla.bluetoothSdk.connect.timeout.DisconnectTimeoutManager
          return (T) FlutterSdkModule_ProvideDisconnectTimeoutManagerFactory.provideDisconnectTimeoutManager(flutterSdkComponentImpl.provideBleScopeContextProvider.get());

          case 35: // app.rolla.bluetoothSdk.connect.reconnect.ReconnectionManager
          return (T) FlutterSdkModule_ProvideReconnectionManagerFactory.provideReconnectionManager(flutterSdkComponentImpl.provideBluetoothAdapterProvider.get(), flutterSdkComponentImpl.provideFirstConnectionRetryStrategyProvider.get(), flutterSdkComponentImpl.provideAutoReconnectStrategyProvider.get());

          case 36: // app.rolla.bluetoothSdk.connect.reconnect.FirstConnectionRetryStrategy
          return (T) FlutterSdkModule_ProvideFirstConnectionRetryStrategyFactory.provideFirstConnectionRetryStrategy(flutterSdkComponentImpl.provideBleScopeContextProvider.get());

          case 37: // app.rolla.bluetoothSdk.connect.reconnect.AutoReconnectStrategy
          return (T) FlutterSdkModule_ProvideAutoReconnectStrategyFactory.provideAutoReconnectStrategy(flutterSdkComponentImpl.provideBleScopeContextProvider.get());

          default: throw new AssertionError(id);
        }
      }
    }
  }
}
