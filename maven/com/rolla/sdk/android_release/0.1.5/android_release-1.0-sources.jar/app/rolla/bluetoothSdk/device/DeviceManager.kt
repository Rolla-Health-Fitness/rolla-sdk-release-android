package app.rolla.bluetoothSdk.device

import android.bluetooth.BluetoothGatt
import app.rolla.bluetoothSdk.device.monitoring.DeviceMonitoringManager
import app.rolla.bluetoothSdk.device.state.DeviceStateManager
import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager
import app.rolla.bluetoothSdk.device.types.DeviceTypeManager
import app.rolla.bluetoothSdk.result.MethodResult
import app.rolla.bluetoothSdk.result.error.DeviceAlreadyConnecting
import app.rolla.bluetoothSdk.result.error.DeviceTypeAlreadySubscribed
import app.rolla.bluetoothSdk.result.error.GattNull
import app.rolla.bluetoothSdk.utils.log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

@Singleton
class DeviceManager @Inject constructor(
    coroutineContext: CoroutineContext,
    private val typeManager: DeviceTypeManager,
    private val monitoringManager: DeviceMonitoringManager,
    private val stateManager: DeviceStateManager,
    private val storageManager: DeviceStorageManager
) {
    companion object {
        private const val TAG = "DeviceManager"

        private const val MAX_CONCURRENT_CONNECTIONS = 6
    }

    // Internal state
    private val deviceScope = CoroutineScope(coroutineContext)

    // Public state
    val devicesFlow: StateFlow<List<BleDevice>> = stateManager.devicesFlow
    val connectionStateChanges: SharedFlow<Pair<String, DeviceConnectionState>> = stateManager.connectionStateChanges
    val deviceEventFlow: SharedFlow<DeviceEvent> = monitoringManager.deviceEventFlow

    fun setAllowedDeviceTypes(types: Set<DeviceType>) = typeManager.setAllowedDeviceTypes(types)
    fun getAllowedDeviceTypes(): Set<DeviceType> = typeManager.getAllowedDeviceTypes()
    fun getAvailableDeviceTypes(
        deviceAddress: String,
        currentDeviceTypes: Set<DeviceType>,
        requestedTypes: Set<DeviceType>
    ): Set<DeviceType> = typeManager.getAvailableDeviceTypes(deviceAddress, currentDeviceTypes, requestedTypes)

    /**
     * Process scanned device (from scan results)
     */
    fun processScannedDevice(bleDevice: BleDevice, detectedTypes: Set<DeviceType>) {
        if (typeManager.getAllowedDeviceTypes().isNotEmpty() &&
            detectedTypes.none { it in typeManager.getAllowedDeviceTypes() }) {
            log(TAG, "Device doesn't match allowed types: ${bleDevice.getMacAddress()}")
            return
        }
        val address = bleDevice.getMacAddress()
        if (storageManager.getDevice(address) == null) {
            storageManager.addDevice(address, bleDevice)
        }
        updateDevice(address) { device ->
            device.withScannedDeviceTypes(detectedTypes.toSet())
                .withRssi(bleDevice.rssi)
                .withServiceUuids(bleDevice.discoveredServiceUuids)
        }
    }

    /**
     * Add device for connection operations
     */
    @Synchronized
    fun addDevice(bleDevice: BleDevice, deviceTypes: Set<DeviceType>) {
        val address = bleDevice.getMacAddress()
        if (storageManager.getDevice(address) == null) {
            storageManager.addDevice(address, bleDevice)
        }

        updateDevice(address) { device ->
            device.withConnectionState(DeviceConnectionState.CONNECTING)
                .withGatt(bleDevice.gatt)
                .withNewRequestedTypes(deviceTypes)
                .withFinalSubscribedTypes()
        }
        log(TAG, "Added device: $address")
    }

    /**
     * Remove device completely
     */
    @Synchronized
    fun removeDevice(deviceAddress: String): BleDevice? {
        updateDevice(deviceAddress) { device ->
            device.withConnectionState(DeviceConnectionState.DISCONNECTED)
                .withGatt(null)
                .withServicesDiscovered(false)
                .withUpdatedDeviceTypeStates(DeviceTypeState.UNSUBSCRIBED)
                .withNewRequestedTypes(emptySet())
                .withScannedDeviceTypes(emptySet())
                .clearFinalSubscribedTypes()
                .withAutoConnect(false)
                .withConnectionHistory(false)
        }
        val removed = storageManager.removeDevice(deviceAddress)
        if (removed != null) {
            stateManager.refreshDevicesList()
            log(TAG, "Removed device: $deviceAddress")
        }
        return removed
    }

    @Synchronized
    fun getDevice(address: String): BleDevice? = storageManager.getDevice(address)

    /**
     * Update device with custom logic
     */
    @Synchronized
    fun updateDevice(address: String, updater: (BleDevice) -> BleDevice): BleDevice? = stateManager.updateDevice(address, updater)

    @Synchronized
    fun updateDeviceWithGatt(address: String, gatt: BluetoothGatt?): BleDevice? = updateDevice(address) { device ->
        device.withGatt(gatt)
    }

    @Synchronized
    fun updateServiceDiscovery(address: String, servicesDiscovered: Boolean, gatt: BluetoothGatt?) = updateDevice(address) { device ->
        device.withGatt(gatt)
            .withServicesDiscovered(servicesDiscovered)
            .withUpdatedDeviceTypeStates(DeviceTypeState.SUBSCRIBING)
    }

    fun canCreateNewConnection(deviceAddress: String): Boolean {
        val device = storageManager.getDevice(deviceAddress)
        val isNewConnection = device == null || device.isDisconnected()
        return !isNewConnection || getActiveConnectionCount() < MAX_CONCURRENT_CONNECTIONS
    }

    fun getAllDevicesSorted(): List<BleDevice> = devicesFlow.value

    fun getActiveConnectionCount(): Int = storageManager.getActiveConnectionCount()

    fun getConnectedDevices(): List<BleDevice> = storageManager.getConnectedDevices()

    fun getGattForDevice(bleDevice: BleDevice): BluetoothGatt? =
        storageManager.getDevice(bleDevice.getMacAddress())?.takeIf { it.isConnected() }?.gatt

    /**
     * Check device type conflicts for connection
     */
    fun getConflictTypes(deviceTypes: Set<DeviceType>, deviceAddress: String): Set<DeviceType> =
        typeManager.getConflictTypes(deviceTypes, deviceAddress)

    fun getDevicesByType(deviceType: DeviceType): List<BleDevice> = storageManager.getDevicesByType(deviceType)

    fun clearDevices() = stateManager.clear()

    fun isConnected(macAddress: String): Boolean = storageManager.getDevice(macAddress)?.isConnected() == true

    fun getConnectionState(macAddress: String): DeviceConnectionState? = storageManager.getDevice(macAddress)?.connectionState

    fun getConnectedDeviceForType(deviceType: DeviceType): BleDevice? =
        storageManager.getAllDevices().find { it.isConnected() && it.hasDeviceType(deviceType) }

    fun destroy() {
        monitoringManager.destroy()
        clearDevices()
    }

    fun updateRequestedTypesWhileConnecting(address: String, currentDeviceTypes: Set<DeviceType>, requestedTypes: Set<DeviceType>): MethodResult {
        log(TAG, "Device already connecting: $address")
        val availableTypes = getAvailableDeviceTypes(address, currentDeviceTypes, requestedTypes)
        if (availableTypes.isEmpty()) {
            log(TAG, "No new device types to add for $address")
            return MethodResult(false, DeviceAlreadyConnecting())
        }
        updateDevice(address) { device ->
            device.withRequestedTypes(availableTypes)
                .withFinalSubscribedTypes()
        }
        return MethodResult(true)
    }

    fun updateRequestedTypesForConnected(address: String, subscribedTypes: Set<DeviceType>, requestedDeviceTypes: Set<DeviceType>): MethodResult {
        log(TAG, "Device already connected: $address")
        val availableTypes = getAvailableDeviceTypes(address, subscribedTypes, requestedDeviceTypes)
        if (availableTypes.isEmpty()) {
            log(TAG, "No new device types to add for $address")
            return MethodResult(false, DeviceTypeAlreadySubscribed())
        }
        log(TAG, "Adding new device types to connected device: $address, types: ${availableTypes.joinToString { it.name }}")
        val device = updateDevice(address) { device ->
            device.withNewRequestedTypes(availableTypes)
                .withUpdatedDeviceTypeStates(DeviceTypeState.SUBSCRIBING)
                .withFinalSubscribedTypes()
        }

        if (device?.gatt == null) {
            log(TAG, "No GATT connection for $address")
            return MethodResult(false, GattNull())
        }
        return MethodResult(true)
    }
}
