package app.rolla.bluetoothSdk.connect

sealed class CharacteristicEvent {
    data class AllSubscriptionsComplete(val deviceAddress: String) : CharacteristicEvent()
    data class AllPostSubscriptionCommandsComplete(val deviceAddress: String) : CharacteristicEvent()
    data class AllUnsubscriptionsComplete(val deviceAddress: String) : CharacteristicEvent()
}