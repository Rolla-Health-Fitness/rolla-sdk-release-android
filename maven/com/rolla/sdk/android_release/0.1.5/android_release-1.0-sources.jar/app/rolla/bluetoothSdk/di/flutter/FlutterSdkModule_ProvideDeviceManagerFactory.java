package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.device.DeviceManager;
import app.rolla.bluetoothSdk.device.monitoring.DeviceMonitoringManager;
import app.rolla.bluetoothSdk.device.state.DeviceStateManager;
import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager;
import app.rolla.bluetoothSdk.device.types.DeviceTypeManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideDeviceManagerFactory implements Factory<DeviceManager> {
  private final Provider<CoroutineContext> coroutineContextProvider;

  private final Provider<DeviceTypeManager> deviceTypeManagerProvider;

  private final Provider<DeviceMonitoringManager> deviceMonitoringManagerProvider;

  private final Provider<DeviceStateManager> deviceStateManagerProvider;

  private final Provider<DeviceStorageManager> deviceStorageManagerProvider;

  private FlutterSdkModule_ProvideDeviceManagerFactory(
      Provider<CoroutineContext> coroutineContextProvider,
      Provider<DeviceTypeManager> deviceTypeManagerProvider,
      Provider<DeviceMonitoringManager> deviceMonitoringManagerProvider,
      Provider<DeviceStateManager> deviceStateManagerProvider,
      Provider<DeviceStorageManager> deviceStorageManagerProvider) {
    this.coroutineContextProvider = coroutineContextProvider;
    this.deviceTypeManagerProvider = deviceTypeManagerProvider;
    this.deviceMonitoringManagerProvider = deviceMonitoringManagerProvider;
    this.deviceStateManagerProvider = deviceStateManagerProvider;
    this.deviceStorageManagerProvider = deviceStorageManagerProvider;
  }

  @Override
  public DeviceManager get() {
    return provideDeviceManager(coroutineContextProvider.get(), deviceTypeManagerProvider.get(), deviceMonitoringManagerProvider.get(), deviceStateManagerProvider.get(), deviceStorageManagerProvider.get());
  }

  public static FlutterSdkModule_ProvideDeviceManagerFactory create(
      Provider<CoroutineContext> coroutineContextProvider,
      Provider<DeviceTypeManager> deviceTypeManagerProvider,
      Provider<DeviceMonitoringManager> deviceMonitoringManagerProvider,
      Provider<DeviceStateManager> deviceStateManagerProvider,
      Provider<DeviceStorageManager> deviceStorageManagerProvider) {
    return new FlutterSdkModule_ProvideDeviceManagerFactory(coroutineContextProvider, deviceTypeManagerProvider, deviceMonitoringManagerProvider, deviceStateManagerProvider, deviceStorageManagerProvider);
  }

  public static DeviceManager provideDeviceManager(CoroutineContext coroutineContext,
      DeviceTypeManager deviceTypeManager, DeviceMonitoringManager deviceMonitoringManager,
      DeviceStateManager deviceStateManager, DeviceStorageManager deviceStorageManager) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideDeviceManager(coroutineContext, deviceTypeManager, deviceMonitoringManager, deviceStateManager, deviceStorageManager));
  }
}
