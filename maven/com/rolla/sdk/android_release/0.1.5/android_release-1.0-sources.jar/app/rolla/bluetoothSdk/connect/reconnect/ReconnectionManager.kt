package app.rolla.bluetoothSdk.connect.reconnect

import android.bluetooth.BluetoothAdapter
import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.utils.log
import javax.inject.Inject
import javax.inject.Singleton
import java.util.concurrent.ConcurrentHashMap

@Singleton
class ReconnectionManager @Inject constructor(
    private val bluetoothAdapter: BluetoothAdapter?,
    private val firstConnectionRetryStrategy: FirstConnectionRetryStrategy,
    private val autoReconnectStrategy: AutoReconnectStrategy
) {

    companion object {
        private const val TAG = "ReconnectionManager"
    }

    private val reconnectionInProgress = ConcurrentHashMap<String, Boolean>()

    fun handleDisconnection(device: BleDevice, status: Int, onReconnect: (BleDevice) -> Unit, onFinalFailure: (BleDevice) -> Unit) {
        val deviceAddress = device.getMacAddress()

        // Don't attempt reconnection if Bluetooth is off
        if (bluetoothAdapter?.isEnabled != true) {
            log(TAG, "Bluetooth disabled, skipping reconnection for $deviceAddress")
            cleanup()
            onFinalFailure(device)
            return
        }

        // Check if this disconnection is from an ongoing reconnection attempt
        if (reconnectionInProgress[deviceAddress] == true) {
            log(TAG, "Disconnection during reconnection attempt for $deviceAddress, ignoring to prevent restart")
            return
        }

        log(TAG, "Handling disconnection for $deviceAddress, status: $status, hasBeenConnected: ${device.hasBeenConnectedBefore}")

        cancelReconnection(deviceAddress)

        val firstShouldReconnect = firstConnectionRetryStrategy.shouldReconnect(device, status)
        val autoShouldReconnect = autoReconnectStrategy.shouldReconnect(device, status)

        when {
            firstShouldReconnect -> {
                log(TAG, "Using first connection retry strategy for $deviceAddress")
                reconnectionInProgress[deviceAddress] = true
                firstConnectionRetryStrategy.startReconnection(device, status,
                    onReconnect = { reconnectDevice ->
                        onReconnect(reconnectDevice)
                    },
                    onFinalFailure = { bleDevice ->
                        log(TAG, "Final reconnection failure for $deviceAddress, cleaning up device")
                        reconnectionInProgress.remove(deviceAddress)
                        onFinalFailure(bleDevice)
                    }
                )
            }
            autoShouldReconnect -> {
                log(TAG, "Using auto-reconnect strategy for $deviceAddress")
                reconnectionInProgress[deviceAddress] = true
                autoReconnectStrategy.startReconnection(device, status,
                    onReconnect = { reconnectDevice ->
                        onReconnect(reconnectDevice)
                    },
                    onFinalFailure = { bleDevice ->
                        log(TAG, "Final reconnection failure for $deviceAddress, cleaning up device")
                        reconnectionInProgress.remove(deviceAddress)
                        onFinalFailure(bleDevice)
                    }
                )
            }
            else -> {
                log(TAG, "No reconnection strategy applicable for $deviceAddress")
             }
        }
    }

    fun onConnectionSuccess(deviceAddress: String) {
        // Clear reconnection flag on successful connection
        reconnectionInProgress.remove(deviceAddress)

        firstConnectionRetryStrategy.onConnectionSuccess(deviceAddress)
        autoReconnectStrategy.onConnectionSuccess(deviceAddress)
    }

    fun cancelReconnection(deviceAddress: String) {
        // Clear reconnection flag when cancelling
        reconnectionInProgress.remove(deviceAddress)

        firstConnectionRetryStrategy.cancelReconnection(deviceAddress)
        autoReconnectStrategy.cancelReconnection(deviceAddress)
    }

    fun disableAutoReconnect(deviceAddress: String) {
        // Clear reconnection flag when disabling
        reconnectionInProgress.remove(deviceAddress)

        autoReconnectStrategy.cancelReconnection(deviceAddress)
        log(TAG, "Disabled auto-reconnect for $deviceAddress")
    }

    fun cleanup() {
        reconnectionInProgress.clear()
        firstConnectionRetryStrategy.cleanup()
        autoReconnectStrategy.cleanup()
    }
}