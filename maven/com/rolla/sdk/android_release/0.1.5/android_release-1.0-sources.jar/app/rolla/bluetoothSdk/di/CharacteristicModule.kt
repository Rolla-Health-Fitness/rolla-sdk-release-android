package app.rolla.bluetoothSdk.di

import android.content.Context
import app.rolla.bluetoothSdk.characteristics.FirmwareRevisionCharacteristic
import app.rolla.bluetoothSdk.characteristics.HeartRateCharacteristic
import app.rolla.bluetoothSdk.characteristics.RollaBandReadCharacteristic
import app.rolla.bluetoothSdk.characteristics.RollaBandWriteCharacteristic
import app.rolla.bluetoothSdk.characteristics.RunningSpeedCadenceCharacteristic
import app.rolla.bluetoothSdk.characteristics.SerialNumberCharacteristic
import app.rolla.bluetoothSdk.characteristics.impl.RollaBandImpl
import app.rolla.bluetoothSdk.steps.RealTimeStepCalculator
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

@Module
@InstallIn(SingletonComponent::class)
object CharacteristicModule {

    @Provides
    @Singleton
    fun provideRollaBandImpl(
        @ApplicationContext context: Context,
        @BleScopeContext bleScopeContext: CoroutineContext
    ): RollaBandImpl = RollaBandImpl(context, bleScopeContext)

    @Provides
    @Singleton
    fun provideFirmwareRevisionCharacteristic(
        @BleScopeContext bleScopeContext: CoroutineContext,
    ): FirmwareRevisionCharacteristic = FirmwareRevisionCharacteristic(bleScopeContext)

    @Provides
    @Singleton
    fun provideSerialNumberCharacteristic(
        @BleScopeContext bleScopeContext: CoroutineContext,
    ): SerialNumberCharacteristic = SerialNumberCharacteristic(bleScopeContext)

    @Provides
    @Singleton
    fun provideHeartRateCharacteristic(
        @BleScopeContext bleScopeContext: CoroutineContext,
    ): HeartRateCharacteristic = HeartRateCharacteristic(bleScopeContext)

    @Provides
    @Singleton
    fun provideRunningSpeedCadenceCharacteristic(
        @BleScopeContext bleScopeContext: CoroutineContext,
        realTimeStepCalculator: RealTimeStepCalculator
    ): RunningSpeedCadenceCharacteristic = RunningSpeedCadenceCharacteristic(bleScopeContext, realTimeStepCalculator)

    @Provides
    @Singleton
    fun provideRollaBandWriteCharacteristic(
        @BleScopeContext bleScopeContext: CoroutineContext,
        rollaBandImpl: RollaBandImpl
    ): RollaBandWriteCharacteristic = RollaBandWriteCharacteristic(bleScopeContext, rollaBandImpl)

    @Provides
    @Singleton
    fun provideRollaBandReadCharacteristic(
        @BleScopeContext bleScopeContext: CoroutineContext,
        rollaBandImpl: RollaBandImpl
    ): RollaBandReadCharacteristic = RollaBandReadCharacteristic(bleScopeContext, rollaBandImpl)

}