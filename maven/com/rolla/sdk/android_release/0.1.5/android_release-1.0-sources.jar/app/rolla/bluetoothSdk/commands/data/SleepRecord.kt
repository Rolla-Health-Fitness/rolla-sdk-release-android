package app.rolla.bluetoothSdk.commands.data

import app.rolla.bluetoothSdk.utils.BcdTime

data class SleepRecord(
    val dataNumber: Int,
    val bcdTime: BcdTime,
    val sleepLength: Int,
    val timeInMilliseconds: Long,
    val offset: Int
)