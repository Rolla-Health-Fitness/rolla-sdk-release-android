package app.rolla.bluetoothSdk.di.flutter;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideBleScopeContextFactory implements Factory<CoroutineContext> {
  @Override
  public CoroutineContext get() {
    return provideBleScopeContext();
  }

  public static FlutterSdkModule_ProvideBleScopeContextFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static CoroutineContext provideBleScopeContext() {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideBleScopeContext());
  }

  private static final class InstanceHolder {
    static final FlutterSdkModule_ProvideBleScopeContextFactory INSTANCE = new FlutterSdkModule_ProvideBleScopeContextFactory();
  }
}
