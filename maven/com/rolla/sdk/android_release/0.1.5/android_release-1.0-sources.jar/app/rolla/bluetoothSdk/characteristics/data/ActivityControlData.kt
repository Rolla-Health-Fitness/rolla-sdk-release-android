package app.rolla.bluetoothSdk.characteristics.data

import app.rolla.bluetoothSdk.commands.data.ActivityStatus
import app.rolla.bluetoothSdk.result.error.Error

data class ActivityControlData(
    val uuid: String,
    val success: Boolean,
    val activityStatus: ActivityStatus,
    val error: Error? = null
) {
    override fun toString(): String {
        return "ActivityControlData(uuid=$uuid, success=$success, error=$error)"
    }
}