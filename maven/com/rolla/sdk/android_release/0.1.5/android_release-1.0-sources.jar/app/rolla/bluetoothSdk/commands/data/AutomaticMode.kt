package app.rolla.bluetoothSdk.commands.data

enum class AutomaticMode {
    HEART_RATE,
    HRV
}