package app.rolla.bluetoothSdk.di;

import app.rolla.bluetoothSdk.connect.reconnect.FirstConnectionRetryStrategy;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("app.rolla.bluetoothSdk.di.BleScopeContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BluetoothModule_ProvideFirstConnectionRetryStrategyFactory implements Factory<FirstConnectionRetryStrategy> {
  private final Provider<CoroutineContext> contextProvider;

  private BluetoothModule_ProvideFirstConnectionRetryStrategyFactory(
      Provider<CoroutineContext> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public FirstConnectionRetryStrategy get() {
    return provideFirstConnectionRetryStrategy(contextProvider.get());
  }

  public static BluetoothModule_ProvideFirstConnectionRetryStrategyFactory create(
      Provider<CoroutineContext> contextProvider) {
    return new BluetoothModule_ProvideFirstConnectionRetryStrategyFactory(contextProvider);
  }

  public static FirstConnectionRetryStrategy provideFirstConnectionRetryStrategy(
      CoroutineContext context) {
    return Preconditions.checkNotNullFromProvides(BluetoothModule.INSTANCE.provideFirstConnectionRetryStrategy(context));
  }
}
