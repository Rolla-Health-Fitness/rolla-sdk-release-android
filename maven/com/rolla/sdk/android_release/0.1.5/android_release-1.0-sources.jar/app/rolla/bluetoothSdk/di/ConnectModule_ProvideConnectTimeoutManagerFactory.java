package app.rolla.bluetoothSdk.di;

import app.rolla.bluetoothSdk.connect.timeout.ConnectTimeoutManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("app.rolla.bluetoothSdk.di.BleScopeContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ConnectModule_ProvideConnectTimeoutManagerFactory implements Factory<ConnectTimeoutManager> {
  private final Provider<CoroutineContext> bleScopeContextProvider;

  private ConnectModule_ProvideConnectTimeoutManagerFactory(
      Provider<CoroutineContext> bleScopeContextProvider) {
    this.bleScopeContextProvider = bleScopeContextProvider;
  }

  @Override
  public ConnectTimeoutManager get() {
    return provideConnectTimeoutManager(bleScopeContextProvider.get());
  }

  public static ConnectModule_ProvideConnectTimeoutManagerFactory create(
      Provider<CoroutineContext> bleScopeContextProvider) {
    return new ConnectModule_ProvideConnectTimeoutManagerFactory(bleScopeContextProvider);
  }

  public static ConnectTimeoutManager provideConnectTimeoutManager(
      CoroutineContext bleScopeContext) {
    return Preconditions.checkNotNullFromProvides(ConnectModule.INSTANCE.provideConnectTimeoutManager(bleScopeContext));
  }
}
