package app.rolla.bluetoothSdk.device;

import app.rolla.bluetoothSdk.device.monitoring.DeviceMonitoringManager;
import app.rolla.bluetoothSdk.device.state.DeviceStateManager;
import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager;
import app.rolla.bluetoothSdk.device.types.DeviceTypeManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DeviceManager_Factory implements Factory<DeviceManager> {
  private final Provider<CoroutineContext> coroutineContextProvider;

  private final Provider<DeviceTypeManager> typeManagerProvider;

  private final Provider<DeviceMonitoringManager> monitoringManagerProvider;

  private final Provider<DeviceStateManager> stateManagerProvider;

  private final Provider<DeviceStorageManager> storageManagerProvider;

  private DeviceManager_Factory(Provider<CoroutineContext> coroutineContextProvider,
      Provider<DeviceTypeManager> typeManagerProvider,
      Provider<DeviceMonitoringManager> monitoringManagerProvider,
      Provider<DeviceStateManager> stateManagerProvider,
      Provider<DeviceStorageManager> storageManagerProvider) {
    this.coroutineContextProvider = coroutineContextProvider;
    this.typeManagerProvider = typeManagerProvider;
    this.monitoringManagerProvider = monitoringManagerProvider;
    this.stateManagerProvider = stateManagerProvider;
    this.storageManagerProvider = storageManagerProvider;
  }

  @Override
  public DeviceManager get() {
    return newInstance(coroutineContextProvider.get(), typeManagerProvider.get(), monitoringManagerProvider.get(), stateManagerProvider.get(), storageManagerProvider.get());
  }

  public static DeviceManager_Factory create(Provider<CoroutineContext> coroutineContextProvider,
      Provider<DeviceTypeManager> typeManagerProvider,
      Provider<DeviceMonitoringManager> monitoringManagerProvider,
      Provider<DeviceStateManager> stateManagerProvider,
      Provider<DeviceStorageManager> storageManagerProvider) {
    return new DeviceManager_Factory(coroutineContextProvider, typeManagerProvider, monitoringManagerProvider, stateManagerProvider, storageManagerProvider);
  }

  public static DeviceManager newInstance(CoroutineContext coroutineContext,
      DeviceTypeManager typeManager, DeviceMonitoringManager monitoringManager,
      DeviceStateManager stateManager, DeviceStorageManager storageManager) {
    return new DeviceManager(coroutineContext, typeManager, monitoringManager, stateManager, storageManager);
  }
}
