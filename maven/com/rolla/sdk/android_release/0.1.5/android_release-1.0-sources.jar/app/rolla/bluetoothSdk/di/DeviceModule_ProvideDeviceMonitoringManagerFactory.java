package app.rolla.bluetoothSdk.di;

import app.rolla.bluetoothSdk.device.monitoring.DeviceMonitoringManager;
import app.rolla.bluetoothSdk.device.state.DeviceStateManager;
import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("app.rolla.bluetoothSdk.di.BleScopeContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DeviceModule_ProvideDeviceMonitoringManagerFactory implements Factory<DeviceMonitoringManager> {
  private final Provider<DeviceStorageManager> deviceStorageManagerProvider;

  private final Provider<DeviceStateManager> deviceStateManagerProvider;

  private final Provider<CoroutineContext> coroutineContextProvider;

  private DeviceModule_ProvideDeviceMonitoringManagerFactory(
      Provider<DeviceStorageManager> deviceStorageManagerProvider,
      Provider<DeviceStateManager> deviceStateManagerProvider,
      Provider<CoroutineContext> coroutineContextProvider) {
    this.deviceStorageManagerProvider = deviceStorageManagerProvider;
    this.deviceStateManagerProvider = deviceStateManagerProvider;
    this.coroutineContextProvider = coroutineContextProvider;
  }

  @Override
  public DeviceMonitoringManager get() {
    return provideDeviceMonitoringManager(deviceStorageManagerProvider.get(), deviceStateManagerProvider.get(), coroutineContextProvider.get());
  }

  public static DeviceModule_ProvideDeviceMonitoringManagerFactory create(
      Provider<DeviceStorageManager> deviceStorageManagerProvider,
      Provider<DeviceStateManager> deviceStateManagerProvider,
      Provider<CoroutineContext> coroutineContextProvider) {
    return new DeviceModule_ProvideDeviceMonitoringManagerFactory(deviceStorageManagerProvider, deviceStateManagerProvider, coroutineContextProvider);
  }

  public static DeviceMonitoringManager provideDeviceMonitoringManager(
      DeviceStorageManager deviceStorageManager, DeviceStateManager deviceStateManager,
      CoroutineContext coroutineContext) {
    return Preconditions.checkNotNullFromProvides(DeviceModule.INSTANCE.provideDeviceMonitoringManager(deviceStorageManager, deviceStateManager, coroutineContext));
  }
}
