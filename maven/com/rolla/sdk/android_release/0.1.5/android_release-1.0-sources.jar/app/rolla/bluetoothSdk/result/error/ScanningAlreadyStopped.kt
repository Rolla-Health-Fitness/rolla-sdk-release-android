package app.rolla.bluetoothSdk.result.error

class ScanningAlreadyStopped : Error (
    code = ErrorCodes.SCANNING_ALREADY_STOPPED,
    message = "Scanning already stopped"
)