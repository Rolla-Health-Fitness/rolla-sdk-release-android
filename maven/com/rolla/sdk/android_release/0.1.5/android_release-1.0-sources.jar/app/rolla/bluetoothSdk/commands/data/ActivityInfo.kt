package app.rolla.bluetoothSdk.commands.data

data class ActivityInfo (
    var activityMode: ActivityMode? = null,
    var wristDetectionStatus: WristDetectionStatus? = null
)