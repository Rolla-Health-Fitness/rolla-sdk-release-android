package app.rolla.bluetoothSdk.characteristics;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("app.rolla.bluetoothSdk.di.BleScopeContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class HeartRateCharacteristic_Factory implements Factory<HeartRateCharacteristic> {
  private final Provider<CoroutineContext> bleScopeContextProvider;

  private HeartRateCharacteristic_Factory(Provider<CoroutineContext> bleScopeContextProvider) {
    this.bleScopeContextProvider = bleScopeContextProvider;
  }

  @Override
  public HeartRateCharacteristic get() {
    return newInstance(bleScopeContextProvider.get());
  }

  public static HeartRateCharacteristic_Factory create(
      Provider<CoroutineContext> bleScopeContextProvider) {
    return new HeartRateCharacteristic_Factory(bleScopeContextProvider);
  }

  public static HeartRateCharacteristic newInstance(CoroutineContext bleScopeContext) {
    return new HeartRateCharacteristic(bleScopeContext);
  }
}
