package app.rolla.bluetoothSdk.di;

import android.content.Context;
import app.rolla.bluetoothSdk.connect.BleConnector;
import app.rolla.bluetoothSdk.connect.ConnectionManager;
import app.rolla.bluetoothSdk.connect.OperationQueue;
import app.rolla.bluetoothSdk.device.DeviceManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata({
    "dagger.hilt.android.qualifiers.ApplicationContext",
    "app.rolla.bluetoothSdk.di.BleScopeContext"
})
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BleSdkModule_ProvideBleConnectManagerFactory implements Factory<BleConnector> {
  private final Provider<Context> contextProvider;

  private final Provider<DeviceManager> deviceManagerProvider;

  private final Provider<OperationQueue> operationQueueProvider;

  private final Provider<CoroutineContext> bleScopeContextProvider;

  private final Provider<ConnectionManager> connectionManagerProvider;

  private BleSdkModule_ProvideBleConnectManagerFactory(Provider<Context> contextProvider,
      Provider<DeviceManager> deviceManagerProvider,
      Provider<OperationQueue> operationQueueProvider,
      Provider<CoroutineContext> bleScopeContextProvider,
      Provider<ConnectionManager> connectionManagerProvider) {
    this.contextProvider = contextProvider;
    this.deviceManagerProvider = deviceManagerProvider;
    this.operationQueueProvider = operationQueueProvider;
    this.bleScopeContextProvider = bleScopeContextProvider;
    this.connectionManagerProvider = connectionManagerProvider;
  }

  @Override
  public BleConnector get() {
    return provideBleConnectManager(contextProvider.get(), deviceManagerProvider.get(), operationQueueProvider.get(), bleScopeContextProvider.get(), connectionManagerProvider.get());
  }

  public static BleSdkModule_ProvideBleConnectManagerFactory create(
      Provider<Context> contextProvider, Provider<DeviceManager> deviceManagerProvider,
      Provider<OperationQueue> operationQueueProvider,
      Provider<CoroutineContext> bleScopeContextProvider,
      Provider<ConnectionManager> connectionManagerProvider) {
    return new BleSdkModule_ProvideBleConnectManagerFactory(contextProvider, deviceManagerProvider, operationQueueProvider, bleScopeContextProvider, connectionManagerProvider);
  }

  public static BleConnector provideBleConnectManager(Context context, DeviceManager deviceManager,
      OperationQueue operationQueue, CoroutineContext bleScopeContext,
      ConnectionManager connectionManager) {
    return Preconditions.checkNotNullFromProvides(BleSdkModule.INSTANCE.provideBleConnectManager(context, deviceManager, operationQueue, bleScopeContext, connectionManager));
  }
}
