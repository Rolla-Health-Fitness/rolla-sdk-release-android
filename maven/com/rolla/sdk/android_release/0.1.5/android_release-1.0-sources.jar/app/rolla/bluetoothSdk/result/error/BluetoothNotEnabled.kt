package app.rolla.bluetoothSdk.result.error

/**
 * Error class for when Bluetooth is not enabled
 *
 * Usually it's turned off by the user.
 */
class BluetoothNotEnabled : Error (
    code = ErrorCodes.BLUETOOTH_NOT_ENABLED,
    message = "Bluetooth is not enabled"
)
