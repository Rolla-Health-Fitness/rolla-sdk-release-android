package app.rolla.bluetoothSdk.result.error

class GetBatteryLevelError : Error (
    code = ErrorCodes.GET_BATTERY_LEVEL_ERROR,
    message = "Get battery level error"
)