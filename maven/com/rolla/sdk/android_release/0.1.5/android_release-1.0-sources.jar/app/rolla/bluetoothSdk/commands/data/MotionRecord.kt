package app.rolla.bluetoothSdk.commands.data

import app.rolla.bluetoothSdk.utils.BcdTime

data class MotionRecord(
    val dataNumber: Int,
    val bcdTime: BcdTime,
    val heartRate: Int,
    val spm: Int,
    val timeInMilliseconds: Long,
    val offset: Int
)

