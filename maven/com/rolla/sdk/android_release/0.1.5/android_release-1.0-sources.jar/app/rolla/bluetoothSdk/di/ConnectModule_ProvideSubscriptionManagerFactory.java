package app.rolla.bluetoothSdk.di;

import android.content.Context;
import app.rolla.bluetoothSdk.BleRegistry;
import app.rolla.bluetoothSdk.connect.OperationQueue;
import app.rolla.bluetoothSdk.connect.SubscriptionManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata({
    "app.rolla.bluetoothSdk.di.BleScopeContext",
    "dagger.hilt.android.qualifiers.ApplicationContext"
})
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ConnectModule_ProvideSubscriptionManagerFactory implements Factory<SubscriptionManager> {
  private final Provider<CoroutineContext> bleScopeContextProvider;

  private final Provider<Context> contextProvider;

  private final Provider<OperationQueue> operationQueueProvider;

  private final Provider<BleRegistry> bleRegistryProvider;

  private ConnectModule_ProvideSubscriptionManagerFactory(
      Provider<CoroutineContext> bleScopeContextProvider, Provider<Context> contextProvider,
      Provider<OperationQueue> operationQueueProvider, Provider<BleRegistry> bleRegistryProvider) {
    this.bleScopeContextProvider = bleScopeContextProvider;
    this.contextProvider = contextProvider;
    this.operationQueueProvider = operationQueueProvider;
    this.bleRegistryProvider = bleRegistryProvider;
  }

  @Override
  public SubscriptionManager get() {
    return provideSubscriptionManager(bleScopeContextProvider.get(), contextProvider.get(), operationQueueProvider.get(), bleRegistryProvider.get());
  }

  public static ConnectModule_ProvideSubscriptionManagerFactory create(
      Provider<CoroutineContext> bleScopeContextProvider, Provider<Context> contextProvider,
      Provider<OperationQueue> operationQueueProvider, Provider<BleRegistry> bleRegistryProvider) {
    return new ConnectModule_ProvideSubscriptionManagerFactory(bleScopeContextProvider, contextProvider, operationQueueProvider, bleRegistryProvider);
  }

  public static SubscriptionManager provideSubscriptionManager(CoroutineContext bleScopeContext,
      Context context, OperationQueue operationQueue, BleRegistry bleRegistry) {
    return Preconditions.checkNotNullFromProvides(ConnectModule.INSTANCE.provideSubscriptionManager(bleScopeContext, context, operationQueue, bleRegistry));
  }
}
