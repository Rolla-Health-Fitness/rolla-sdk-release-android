package app.rolla.bluetoothSdk.commands

import app.rolla.bluetoothSdk.utils.log

class FactoryReset : Command<ByteArray> {

    companion object {
        const val TAG = "FactoryReset"
    }

    override fun getId(): Byte  = 0x12.toByte()

    override fun errorId(): Byte = 0x92.toByte()

    override fun bytesToWrite(): ByteArray = createCommandBytes { }

    override fun read(data: ByteArray): ByteArray {
        log(TAG, "Successful - Factory reset response: ${data.contentToString()}")
        return data
    }
}