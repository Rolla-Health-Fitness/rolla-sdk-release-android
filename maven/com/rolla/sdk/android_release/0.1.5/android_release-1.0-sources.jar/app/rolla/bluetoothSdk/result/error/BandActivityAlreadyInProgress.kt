package app.rolla.bluetoothSdk.result.error

class BandActivityAlreadyInProgress : Error (
    code = ErrorCodes.BAND_ACTIVITY_ALREADY_IN_PROGRESS,
    message = "Band activity already in progress"
)