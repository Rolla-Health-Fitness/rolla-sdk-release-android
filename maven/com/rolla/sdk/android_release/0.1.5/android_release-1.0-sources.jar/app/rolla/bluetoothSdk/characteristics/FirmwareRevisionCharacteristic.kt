package app.rolla.bluetoothSdk.characteristics

import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.di.BleScopeContext
import app.rolla.bluetoothSdk.result.error.Error
import app.rolla.bluetoothSdk.result.error.InvalidEncoding
import app.rolla.bluetoothSdk.characteristics.data.FirmwareRevisionData
import app.rolla.bluetoothSdk.utils.getFullUUID
import app.rolla.bluetoothSdk.utils.log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

@Singleton
class FirmwareRevisionCharacteristic @Inject constructor(
    @BleScopeContext bleScopeContext: CoroutineContext
) : Characteristic {

    companion object {
        private const val TAG = "FirmwareRevisionCharacteristic"
    }

    override val uuid: String = "2A26".getFullUUID()
    override val scope = CoroutineScope(bleScopeContext)

    private val _dataFlow = MutableSharedFlow<FirmwareRevisionData>(replay = 1)
    val dataFlow: SharedFlow<FirmwareRevisionData> = _dataFlow.asSharedFlow()

    override fun onRead(byteArray: ByteArray, device: BleDevice) {
        processFirmwareRevisionData(byteArray, device)
    }

    private fun processFirmwareRevisionData(byteArray: ByteArray, device: BleDevice) {
        if (byteArray.isEmpty()) {
            onError(device.getMacAddress(), InvalidEncoding(Throwable("Firmware revision data is empty")))
            return
        }

        try {
            val firmwareRevision = String(byteArray, Charsets.UTF_8).trim()
            log(TAG, "Firmware Revision: $firmwareRevision")
            onSuccess(FirmwareRevisionData(device.getMacAddress(), firmwareRevision))
        } catch (e: Exception) {
            onError(device.getMacAddress(), InvalidEncoding(e))
        }
    }

    fun onSuccess(data: FirmwareRevisionData) {
        scope.launch {
            _dataFlow.emit(data)
        }
    }

    override fun onError(deviceAddress: String, error: Error, value: ByteArray?) {
        scope.launch {
            _dataFlow.emit(FirmwareRevisionData(deviceAddress, "", error))
        }
    }
}