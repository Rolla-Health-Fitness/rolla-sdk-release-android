package app.rolla.bluetoothSdk.device.monitoring;

import app.rolla.bluetoothSdk.device.state.DeviceStateManager;
import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DeviceMonitoringManager_Factory implements Factory<DeviceMonitoringManager> {
  private final Provider<DeviceStorageManager> storageManagerProvider;

  private final Provider<DeviceStateManager> stateManagerProvider;

  private final Provider<CoroutineContext> coroutineContextProvider;

  private DeviceMonitoringManager_Factory(Provider<DeviceStorageManager> storageManagerProvider,
      Provider<DeviceStateManager> stateManagerProvider,
      Provider<CoroutineContext> coroutineContextProvider) {
    this.storageManagerProvider = storageManagerProvider;
    this.stateManagerProvider = stateManagerProvider;
    this.coroutineContextProvider = coroutineContextProvider;
  }

  @Override
  public DeviceMonitoringManager get() {
    return newInstance(storageManagerProvider.get(), stateManagerProvider.get(), coroutineContextProvider.get());
  }

  public static DeviceMonitoringManager_Factory create(
      Provider<DeviceStorageManager> storageManagerProvider,
      Provider<DeviceStateManager> stateManagerProvider,
      Provider<CoroutineContext> coroutineContextProvider) {
    return new DeviceMonitoringManager_Factory(storageManagerProvider, stateManagerProvider, coroutineContextProvider);
  }

  public static DeviceMonitoringManager newInstance(DeviceStorageManager storageManager,
      DeviceStateManager stateManager, CoroutineContext coroutineContext) {
    return new DeviceMonitoringManager(storageManager, stateManager, coroutineContext);
  }
}
