package app.rolla.bluetoothSdk.di;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import app.rolla.bluetoothSdk.BleRegistry;
import app.rolla.bluetoothSdk.connect.ConnectionManager;
import app.rolla.bluetoothSdk.connect.OperationQueue;
import app.rolla.bluetoothSdk.connect.SubscriptionManager;
import app.rolla.bluetoothSdk.connect.reconnect.ReconnectionManager;
import app.rolla.bluetoothSdk.connect.timeout.ConnectTimeoutManager;
import app.rolla.bluetoothSdk.connect.timeout.DisconnectTimeoutManager;
import app.rolla.bluetoothSdk.connect.timeout.EarlyConnectTimeoutManager;
import app.rolla.bluetoothSdk.device.DeviceManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata({
    "dagger.hilt.android.qualifiers.ApplicationContext",
    "app.rolla.bluetoothSdk.di.BleScopeContext"
})
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ConnectModule_ProvideGattCallbackHandlerFactory implements Factory<ConnectionManager> {
  private final Provider<Context> contextProvider;

  private final Provider<CoroutineContext> bleScopeContextProvider;

  private final Provider<BluetoothAdapter> bluetoothAdapterProvider;

  private final Provider<DeviceManager> deviceManagerProvider;

  private final Provider<OperationQueue> operationQueueProvider;

  private final Provider<SubscriptionManager> subscriptionManagerProvider;

  private final Provider<BleRegistry> bleRegistryProvider;

  private final Provider<EarlyConnectTimeoutManager> earlyConnectTimeoutManagerProvider;

  private final Provider<ConnectTimeoutManager> connectTimeoutManagerProvider;

  private final Provider<DisconnectTimeoutManager> disconnectTimeoutManagerProvider;

  private final Provider<ReconnectionManager> reconnectionManagerProvider;

  private ConnectModule_ProvideGattCallbackHandlerFactory(Provider<Context> contextProvider,
      Provider<CoroutineContext> bleScopeContextProvider,
      Provider<BluetoothAdapter> bluetoothAdapterProvider,
      Provider<DeviceManager> deviceManagerProvider,
      Provider<OperationQueue> operationQueueProvider,
      Provider<SubscriptionManager> subscriptionManagerProvider,
      Provider<BleRegistry> bleRegistryProvider,
      Provider<EarlyConnectTimeoutManager> earlyConnectTimeoutManagerProvider,
      Provider<ConnectTimeoutManager> connectTimeoutManagerProvider,
      Provider<DisconnectTimeoutManager> disconnectTimeoutManagerProvider,
      Provider<ReconnectionManager> reconnectionManagerProvider) {
    this.contextProvider = contextProvider;
    this.bleScopeContextProvider = bleScopeContextProvider;
    this.bluetoothAdapterProvider = bluetoothAdapterProvider;
    this.deviceManagerProvider = deviceManagerProvider;
    this.operationQueueProvider = operationQueueProvider;
    this.subscriptionManagerProvider = subscriptionManagerProvider;
    this.bleRegistryProvider = bleRegistryProvider;
    this.earlyConnectTimeoutManagerProvider = earlyConnectTimeoutManagerProvider;
    this.connectTimeoutManagerProvider = connectTimeoutManagerProvider;
    this.disconnectTimeoutManagerProvider = disconnectTimeoutManagerProvider;
    this.reconnectionManagerProvider = reconnectionManagerProvider;
  }

  @Override
  public ConnectionManager get() {
    return provideGattCallbackHandler(contextProvider.get(), bleScopeContextProvider.get(), bluetoothAdapterProvider.get(), deviceManagerProvider.get(), operationQueueProvider.get(), subscriptionManagerProvider.get(), bleRegistryProvider.get(), earlyConnectTimeoutManagerProvider.get(), connectTimeoutManagerProvider.get(), disconnectTimeoutManagerProvider.get(), reconnectionManagerProvider.get());
  }

  public static ConnectModule_ProvideGattCallbackHandlerFactory create(
      Provider<Context> contextProvider, Provider<CoroutineContext> bleScopeContextProvider,
      Provider<BluetoothAdapter> bluetoothAdapterProvider,
      Provider<DeviceManager> deviceManagerProvider,
      Provider<OperationQueue> operationQueueProvider,
      Provider<SubscriptionManager> subscriptionManagerProvider,
      Provider<BleRegistry> bleRegistryProvider,
      Provider<EarlyConnectTimeoutManager> earlyConnectTimeoutManagerProvider,
      Provider<ConnectTimeoutManager> connectTimeoutManagerProvider,
      Provider<DisconnectTimeoutManager> disconnectTimeoutManagerProvider,
      Provider<ReconnectionManager> reconnectionManagerProvider) {
    return new ConnectModule_ProvideGattCallbackHandlerFactory(contextProvider, bleScopeContextProvider, bluetoothAdapterProvider, deviceManagerProvider, operationQueueProvider, subscriptionManagerProvider, bleRegistryProvider, earlyConnectTimeoutManagerProvider, connectTimeoutManagerProvider, disconnectTimeoutManagerProvider, reconnectionManagerProvider);
  }

  public static ConnectionManager provideGattCallbackHandler(Context context,
      CoroutineContext bleScopeContext, @Nullable BluetoothAdapter bluetoothAdapter,
      DeviceManager deviceManager, OperationQueue operationQueue,
      SubscriptionManager subscriptionManager, BleRegistry bleRegistry,
      EarlyConnectTimeoutManager earlyConnectTimeoutManager,
      ConnectTimeoutManager connectTimeoutManager,
      DisconnectTimeoutManager disconnectTimeoutManager, ReconnectionManager reconnectionManager) {
    return Preconditions.checkNotNullFromProvides(ConnectModule.INSTANCE.provideGattCallbackHandler(context, bleScopeContext, bluetoothAdapter, deviceManager, operationQueue, subscriptionManager, bleRegistry, earlyConnectTimeoutManager, connectTimeoutManager, disconnectTimeoutManager, reconnectionManager));
  }
}
