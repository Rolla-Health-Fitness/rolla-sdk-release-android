package app.rolla.bluetoothSdk.di.flutter;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import app.rolla.bluetoothSdk.BleRegistry;
import app.rolla.bluetoothSdk.connect.ConnectionManager;
import app.rolla.bluetoothSdk.connect.OperationQueue;
import app.rolla.bluetoothSdk.connect.SubscriptionManager;
import app.rolla.bluetoothSdk.connect.reconnect.ReconnectionManager;
import app.rolla.bluetoothSdk.connect.timeout.ConnectTimeoutManager;
import app.rolla.bluetoothSdk.connect.timeout.DisconnectTimeoutManager;
import app.rolla.bluetoothSdk.connect.timeout.EarlyConnectTimeoutManager;
import app.rolla.bluetoothSdk.device.DeviceManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideConnectionManagerFactory implements Factory<ConnectionManager> {
  private final Provider<Context> contextProvider;

  private final Provider<CoroutineContext> coroutineContextProvider;

  private final Provider<BluetoothAdapter> bluetoothAdapterProvider;

  private final Provider<DeviceManager> deviceManagerProvider;

  private final Provider<OperationQueue> operationQueueProvider;

  private final Provider<SubscriptionManager> subscriptionManagerProvider;

  private final Provider<BleRegistry> bleRegistryProvider;

  private final Provider<EarlyConnectTimeoutManager> earlyConnectTimeoutManagerProvider;

  private final Provider<ConnectTimeoutManager> connectTimeoutManagerProvider;

  private final Provider<DisconnectTimeoutManager> disconnectTimeoutManagerProvider;

  private final Provider<ReconnectionManager> reconnectionManagerProvider;

  private FlutterSdkModule_ProvideConnectionManagerFactory(Provider<Context> contextProvider,
      Provider<CoroutineContext> coroutineContextProvider,
      Provider<BluetoothAdapter> bluetoothAdapterProvider,
      Provider<DeviceManager> deviceManagerProvider,
      Provider<OperationQueue> operationQueueProvider,
      Provider<SubscriptionManager> subscriptionManagerProvider,
      Provider<BleRegistry> bleRegistryProvider,
      Provider<EarlyConnectTimeoutManager> earlyConnectTimeoutManagerProvider,
      Provider<ConnectTimeoutManager> connectTimeoutManagerProvider,
      Provider<DisconnectTimeoutManager> disconnectTimeoutManagerProvider,
      Provider<ReconnectionManager> reconnectionManagerProvider) {
    this.contextProvider = contextProvider;
    this.coroutineContextProvider = coroutineContextProvider;
    this.bluetoothAdapterProvider = bluetoothAdapterProvider;
    this.deviceManagerProvider = deviceManagerProvider;
    this.operationQueueProvider = operationQueueProvider;
    this.subscriptionManagerProvider = subscriptionManagerProvider;
    this.bleRegistryProvider = bleRegistryProvider;
    this.earlyConnectTimeoutManagerProvider = earlyConnectTimeoutManagerProvider;
    this.connectTimeoutManagerProvider = connectTimeoutManagerProvider;
    this.disconnectTimeoutManagerProvider = disconnectTimeoutManagerProvider;
    this.reconnectionManagerProvider = reconnectionManagerProvider;
  }

  @Override
  public ConnectionManager get() {
    return provideConnectionManager(contextProvider.get(), coroutineContextProvider.get(), bluetoothAdapterProvider.get(), deviceManagerProvider.get(), operationQueueProvider.get(), subscriptionManagerProvider.get(), bleRegistryProvider.get(), earlyConnectTimeoutManagerProvider.get(), connectTimeoutManagerProvider.get(), disconnectTimeoutManagerProvider.get(), reconnectionManagerProvider.get());
  }

  public static FlutterSdkModule_ProvideConnectionManagerFactory create(
      Provider<Context> contextProvider, Provider<CoroutineContext> coroutineContextProvider,
      Provider<BluetoothAdapter> bluetoothAdapterProvider,
      Provider<DeviceManager> deviceManagerProvider,
      Provider<OperationQueue> operationQueueProvider,
      Provider<SubscriptionManager> subscriptionManagerProvider,
      Provider<BleRegistry> bleRegistryProvider,
      Provider<EarlyConnectTimeoutManager> earlyConnectTimeoutManagerProvider,
      Provider<ConnectTimeoutManager> connectTimeoutManagerProvider,
      Provider<DisconnectTimeoutManager> disconnectTimeoutManagerProvider,
      Provider<ReconnectionManager> reconnectionManagerProvider) {
    return new FlutterSdkModule_ProvideConnectionManagerFactory(contextProvider, coroutineContextProvider, bluetoothAdapterProvider, deviceManagerProvider, operationQueueProvider, subscriptionManagerProvider, bleRegistryProvider, earlyConnectTimeoutManagerProvider, connectTimeoutManagerProvider, disconnectTimeoutManagerProvider, reconnectionManagerProvider);
  }

  public static ConnectionManager provideConnectionManager(Context context,
      CoroutineContext coroutineContext, @Nullable BluetoothAdapter bluetoothAdapter,
      DeviceManager deviceManager, OperationQueue operationQueue,
      SubscriptionManager subscriptionManager, BleRegistry bleRegistry,
      EarlyConnectTimeoutManager earlyConnectTimeoutManager,
      ConnectTimeoutManager connectTimeoutManager,
      DisconnectTimeoutManager disconnectTimeoutManager, ReconnectionManager reconnectionManager) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideConnectionManager(context, coroutineContext, bluetoothAdapter, deviceManager, operationQueue, subscriptionManager, bleRegistry, earlyConnectTimeoutManager, connectTimeoutManager, disconnectTimeoutManager, reconnectionManager));
  }
}
