package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.characteristics.HeartRateCharacteristic;
import app.rolla.bluetoothSdk.services.HeartRateService;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideHeartRateServiceFactory implements Factory<HeartRateService> {
  private final Provider<HeartRateCharacteristic> heartRateCharacteristicProvider;

  private FlutterSdkModule_ProvideHeartRateServiceFactory(
      Provider<HeartRateCharacteristic> heartRateCharacteristicProvider) {
    this.heartRateCharacteristicProvider = heartRateCharacteristicProvider;
  }

  @Override
  public HeartRateService get() {
    return provideHeartRateService(heartRateCharacteristicProvider.get());
  }

  public static FlutterSdkModule_ProvideHeartRateServiceFactory create(
      Provider<HeartRateCharacteristic> heartRateCharacteristicProvider) {
    return new FlutterSdkModule_ProvideHeartRateServiceFactory(heartRateCharacteristicProvider);
  }

  public static HeartRateService provideHeartRateService(
      HeartRateCharacteristic heartRateCharacteristic) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideHeartRateService(heartRateCharacteristic));
  }
}
