package app.rolla.bluetoothSdk.result.error

/**
 * Represents an error that occurred during Bluetooth operations.
 *
 * @property code Custom error code
 * @property message A human-readable description of the error
 * @property exception Optional exception that caused this error, if applicable
 */
abstract class Error (
    val code: String,
    val message: String,
    val exception: Throwable? = null
) {
    override fun toString(): String {
        return "Error(code=$code, message=$message, exception=$exception)"
    }
}