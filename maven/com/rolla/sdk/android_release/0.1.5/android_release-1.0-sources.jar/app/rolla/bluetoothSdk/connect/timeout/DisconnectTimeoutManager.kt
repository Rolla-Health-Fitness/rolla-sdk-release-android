package app.rolla.bluetoothSdk.connect.timeout

import app.rolla.bluetoothSdk.di.BleScopeContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

@Singleton
class DisconnectTimeoutManager @Inject constructor(
    @BleScopeContext bleScopeContext: CoroutineContext
) : TimeoutManager(bleScopeContext) {

    companion object {
        const val TAG = "DisconnectTimeoutManager"
        private const val DISCONNECTION_TIMEOUT_MS = 15_000L // 15 seconds
    }

    override fun getTag(): String = TAG

    override fun getTimeoutMs(): Long = DISCONNECTION_TIMEOUT_MS
}