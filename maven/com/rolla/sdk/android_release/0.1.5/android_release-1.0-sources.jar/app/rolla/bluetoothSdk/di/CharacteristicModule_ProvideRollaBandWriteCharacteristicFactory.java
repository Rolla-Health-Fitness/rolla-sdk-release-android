package app.rolla.bluetoothSdk.di;

import app.rolla.bluetoothSdk.characteristics.RollaBandWriteCharacteristic;
import app.rolla.bluetoothSdk.characteristics.impl.RollaBandImpl;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("app.rolla.bluetoothSdk.di.BleScopeContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CharacteristicModule_ProvideRollaBandWriteCharacteristicFactory implements Factory<RollaBandWriteCharacteristic> {
  private final Provider<CoroutineContext> bleScopeContextProvider;

  private final Provider<RollaBandImpl> rollaBandImplProvider;

  private CharacteristicModule_ProvideRollaBandWriteCharacteristicFactory(
      Provider<CoroutineContext> bleScopeContextProvider,
      Provider<RollaBandImpl> rollaBandImplProvider) {
    this.bleScopeContextProvider = bleScopeContextProvider;
    this.rollaBandImplProvider = rollaBandImplProvider;
  }

  @Override
  public RollaBandWriteCharacteristic get() {
    return provideRollaBandWriteCharacteristic(bleScopeContextProvider.get(), rollaBandImplProvider.get());
  }

  public static CharacteristicModule_ProvideRollaBandWriteCharacteristicFactory create(
      Provider<CoroutineContext> bleScopeContextProvider,
      Provider<RollaBandImpl> rollaBandImplProvider) {
    return new CharacteristicModule_ProvideRollaBandWriteCharacteristicFactory(bleScopeContextProvider, rollaBandImplProvider);
  }

  public static RollaBandWriteCharacteristic provideRollaBandWriteCharacteristic(
      CoroutineContext bleScopeContext, RollaBandImpl rollaBandImpl) {
    return Preconditions.checkNotNullFromProvides(CharacteristicModule.INSTANCE.provideRollaBandWriteCharacteristic(bleScopeContext, rollaBandImpl));
  }
}
