package app.rolla.bluetoothSdk.scan.state

sealed class ScanState {
    object Idle : ScanState()
    object Scanning : ScanState()
    object Stopped: ScanState()
    data class Failed(val errorCode: Int, val message: String?) : ScanState()
}