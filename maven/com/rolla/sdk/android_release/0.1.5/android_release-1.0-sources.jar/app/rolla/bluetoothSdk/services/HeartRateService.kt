package app.rolla.bluetoothSdk.services

import app.rolla.bluetoothSdk.characteristics.Characteristic
import app.rolla.bluetoothSdk.characteristics.HeartRateCharacteristic
import app.rolla.bluetoothSdk.utils.getFullUUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HeartRateService @Inject constructor(
    private val heartRateCharacteristic: HeartRateCharacteristic
) : Service {
    override val uuid: String = "180D".getFullUUID()
    override val characteristics: List<Characteristic> = listOf(heartRateCharacteristic)

    fun getHeartRateCharacteristic(): HeartRateCharacteristic {
        return heartRateCharacteristic
    }
}