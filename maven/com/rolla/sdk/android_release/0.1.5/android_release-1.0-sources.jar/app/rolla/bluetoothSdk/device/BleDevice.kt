package app.rolla.bluetoothSdk.device

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.ParcelUuid
import app.rolla.bluetoothSdk.utils.executeWithBluetoothConnect
import app.rolla.bluetoothSdk.utils.getFullUUID
import app.rolla.bluetoothSdk.utils.log
import kotlin.collections.plus

/**
 * Data class representing a Bluetooth device with its properties and connection state.
 * Encapsulates device information, discovered services, signal strength, device types, and connection state.
 */
data class BleDevice(
    val btDevice: BluetoothDevice,
    val discoveredServiceUuids: List<ParcelUuid>,
    val rssi: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val scannedDeviceTypes: Set<DeviceType> = emptySet(),
    val requestedTypes: Set<DeviceType> = emptySet(),
    val finalRequestedTypes: Set<DeviceType> = emptySet(),
    val connectionState: DeviceConnectionState = DeviceConnectionState.DISCONNECTED,
    val gatt: BluetoothGatt? = null,
    val servicesDiscovered: Boolean = false,
    val autoConnect: Boolean = false,
    val hasBeenConnectedBefore: Boolean = false
) {
    /**
     * Creates a BleDevice from a ScanResult.
     */
    constructor(scanResult: ScanResult) : this(
        scanResult.device,
        scanResult.scanRecord?.serviceUuids?.toList() ?: emptyList(),
        scanResult.rssi
    )

    // Connection state helpers
    fun isConnected(): Boolean = connectionState == DeviceConnectionState.CONNECTED
    fun isConnecting(): Boolean = connectionState == DeviceConnectionState.CONNECTING
    fun isDisconnecting(): Boolean = connectionState == DeviceConnectionState.DISCONNECTING
    fun isDisconnected(): Boolean = connectionState == DeviceConnectionState.DISCONNECTED

    fun isServicesDiscovered(): Boolean = servicesDiscovered

    /**
     * Returns the device's unique identifier (Bluetooth address).
     */
    fun getMacAddress(): String = btDevice.address

    /**
     * Checks if device has a specific device type
     */
    fun hasDeviceType(deviceType: DeviceType): Boolean = scannedDeviceTypes.contains(deviceType)

    fun withConnectionState(newState: DeviceConnectionState): BleDevice = copy(connectionState = newState)

    fun withGatt(newGatt: BluetoothGatt?): BleDevice = copy(gatt = newGatt)

    fun withServicesDiscovered(servicesDiscovered: Boolean): BleDevice = copy(servicesDiscovered = servicesDiscovered)

    fun withRssi(newRssi: Int): BleDevice = copy(rssi = newRssi)

    fun withServiceUuids(newServiceUuids: List<ParcelUuid>): BleDevice = copy(discoveredServiceUuids = newServiceUuids)

    fun withScannedDeviceTypes(newScannedDeviceTypes: Set<DeviceType>): BleDevice {
        log(this.javaClass.simpleName, "Updated scanned device types for ${getMacAddress()}: ${newScannedDeviceTypes.joinToString { it.name }}")
        return copy(scannedDeviceTypes = newScannedDeviceTypes)
    }

    fun withRequestedTypes(
        newRequestedTypes: Set<DeviceType>
    ): BleDevice {
        val updatedRequestedTypes = (requestedTypes + newRequestedTypes).distinct().toSet()
        log(this.javaClass.simpleName, "Updated requested device types for ${getMacAddress()}: ${(updatedRequestedTypes).joinToString { it.name }}")
        return copy(requestedTypes = updatedRequestedTypes)
    }

    fun withNewRequestedTypes(
        newRequestedTypes: Set<DeviceType>
    ): BleDevice {
        return copy(requestedTypes = newRequestedTypes)
    }

    fun withFinalSubscribedTypes(): BleDevice {
        val finalSubscribedTypes = (finalRequestedTypes + requestedTypes).distinct().toSet()
        return copy(finalRequestedTypes = finalSubscribedTypes)
    }

    fun clearFinalSubscribedTypes(): BleDevice {
        return copy(finalRequestedTypes = emptySet())
    }

    /**
     * Updates device type states and returns this BleDevice
     */
    fun withUpdatedDeviceTypeStates(
        newState: DeviceTypeState
    ): BleDevice {
        log(this.javaClass.simpleName, "withUpdatedDeviceTypeStates called for ${getMacAddress()}")
        log(this.javaClass.simpleName, "  New state: $newState")
        log(this.javaClass.simpleName, "  Requested types: ${requestedTypes.joinToString { it.name }}")
        log(this.javaClass.simpleName, "  Scanned device types before: ${scannedDeviceTypes.joinToString { "${it.name}(${it.typeState})" }}")

        scannedDeviceTypes.forEach { deviceType ->
            if (requestedTypes.contains(deviceType)) {
                log(this.javaClass.simpleName, "  Updating ${deviceType.name} from ${deviceType.typeState} to $newState")
                deviceType.typeState = newState
            } else {
                log(this.javaClass.simpleName, "  Skipping ${deviceType.name} (not in requested types)")
            }
        }

        log(this.javaClass.simpleName, "  Scanned device types after: ${scannedDeviceTypes.joinToString { "${it.name}(${it.typeState})" }}")
        return this
    }

    /**
     * Get unsubscribed types (supported but not subscribed)
     */
    fun getUnsubscribedTypes(): Set<DeviceType> = scannedDeviceTypes.filter { it.typeState == DeviceTypeState.UNSUBSCRIBED }.toSet()

    fun getSubscribedTypes(): Set<DeviceType> = scannedDeviceTypes.filter { it.typeState == DeviceTypeState.SUBSCRIBED }.toSet()

    fun getDiscoveredServiceUuidsAsStringList(): List<String> = discoveredServiceUuids.map { it.uuid.toString().uppercase() }

    fun hasOtaService(): Boolean = discoveredServiceUuids.any { it.uuid.toString().uppercase() == "FE59".getFullUUID() }

    fun getCharacteristicByUuid(uuid: String): BluetoothGattCharacteristic? {
        return gatt?.services?.asSequence()
            ?.flatMap { it.characteristics.asSequence() }
            ?.find { it.uuid.getFullUUID() == uuid }
    }

    fun hasTypeConflicts(otherDeviceMacAddress: String, type: DeviceType): Boolean {
        return getMacAddress() != otherDeviceMacAddress &&
                hasDeviceType(type) &&
                (isConnected() || isConnecting())
    }

    /**
     * Get device full name (name + address)
     */
    fun getFullName(context: Context): String = "${getName(context)} (${getMacAddress()})"

    @SuppressLint("MissingPermission")
    fun getName(context: Context): String {
        return context.executeWithBluetoothConnect(
            operation = {
                btDevice.name ?: "Unknown"
            },
            onPermissionDenied = {
                "Permission Denied"
            }
        )
    }

    @SuppressLint("MissingPermission")
    fun getBluetoothDeviceType(context: Context): Int {
        return context.executeWithBluetoothConnect(
            operation = {
                btDevice.type
            },
            onPermissionDenied = {
                -1
            }
        )
    }

    /**
     * String representation of the device.
     */
    override fun toString(): String {
        val name = try {
            btDevice.name ?: "Unknown"
        } catch (e: SecurityException) {
            "Permission denied"
        }
        return "BleDevice(name=$name, address=${btDevice.address}, " +
                "rssi=$rssi, state=$connectionState, " +
                "types=${scannedDeviceTypes.joinToString { it.name }}, " +
                "subscribed=${getSubscribedTypes().joinToString { it.name }})"
    }

    fun withAutoConnect(autoConnect: Boolean): BleDevice = copy(autoConnect = autoConnect)

    fun withConnectionHistory(hasBeenConnected: Boolean): BleDevice = copy(hasBeenConnectedBefore = hasBeenConnected)
}
