package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.characteristics.RollaBandWriteCharacteristic;
import app.rolla.bluetoothSdk.characteristics.impl.RollaBandImpl;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideRollaBandWriteCharacteristicFactory implements Factory<RollaBandWriteCharacteristic> {
  private final Provider<CoroutineContext> coroutineContextProvider;

  private final Provider<RollaBandImpl> rollaBandImplProvider;

  private FlutterSdkModule_ProvideRollaBandWriteCharacteristicFactory(
      Provider<CoroutineContext> coroutineContextProvider,
      Provider<RollaBandImpl> rollaBandImplProvider) {
    this.coroutineContextProvider = coroutineContextProvider;
    this.rollaBandImplProvider = rollaBandImplProvider;
  }

  @Override
  public RollaBandWriteCharacteristic get() {
    return provideRollaBandWriteCharacteristic(coroutineContextProvider.get(), rollaBandImplProvider.get());
  }

  public static FlutterSdkModule_ProvideRollaBandWriteCharacteristicFactory create(
      Provider<CoroutineContext> coroutineContextProvider,
      Provider<RollaBandImpl> rollaBandImplProvider) {
    return new FlutterSdkModule_ProvideRollaBandWriteCharacteristicFactory(coroutineContextProvider, rollaBandImplProvider);
  }

  public static RollaBandWriteCharacteristic provideRollaBandWriteCharacteristic(
      CoroutineContext coroutineContext, RollaBandImpl rollaBandImpl) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideRollaBandWriteCharacteristic(coroutineContext, rollaBandImpl));
  }
}
