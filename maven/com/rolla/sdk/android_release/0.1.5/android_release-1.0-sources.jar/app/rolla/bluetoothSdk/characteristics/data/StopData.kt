package app.rolla.bluetoothSdk.characteristics.data

data class StopData (
    val uuid: String
)