package app.rolla.bluetoothSdk.connect.reconnect

import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.di.BleScopeContext
import app.rolla.bluetoothSdk.utils.log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

@Singleton
class FirstConnectionRetryStrategy @Inject constructor(
    @param:BleScopeContext private val context: CoroutineContext
) : ReconnectionStrategy {

    private val scope = CoroutineScope(context)
    companion object {
        private const val TAG = "FirstConnectionRetryStrategy"

        // Bluetooth GATT status codes
        const val STATUS_GATT_ERROR = 133 // Generic GATT error - often transient
        const val STATUS_CONNECTION_TIMEOUT = 8 // Connection timeout after 30s - device not available
        const val STATUS_GATT_CONN_TERMINATE_PEER_USER = 14 // Remote device terminated connection
        const val STATUS_GATT_CONN_TERMINATE_LOCAL_HOST = 15 // Local host terminated connection
        const val STATUS_REMOTE_DISCONNECTED = 19 // User/remote disconnected - don't retry
        const val STATUS_LMP_RESPONSE_TIMEOUT = 22 // LMP response timeout, can be transient
        const val STATUS_GATT_CONN_LMP_TIMEOUT = 34 // Another LMP timeout variant
        const val STATUS_CONNECTION_FAILED_TO_BE_ESTABLISHED = 62 // Connection failed to establish - often transient
        const val STATUS_GATT_ERROR_85 = 85 // Another generic GATT error code
        const val STATUS_GATT_CONN_L2C_FAILURE = 129 // L2CAP connection failure - often transient

        private const val MAX_RETRIES = 3
        private const val RETRY_DELAY_MS = 500L
    }

    private val retryJobs = ConcurrentHashMap<String, Job>()
    private val retryCounts = ConcurrentHashMap<String, Int>()

    override fun shouldReconnect(device: BleDevice, status: Int): Boolean {
        return !device.hasBeenConnectedBefore && 
               device.isConnecting() && 
               shouldRetryStatus(status) &&
               retryCounts.getOrDefault(device.getMacAddress(), 0) < MAX_RETRIES
    }

    override fun startReconnection(device: BleDevice, status: Int, onReconnect: (BleDevice) -> Unit, onFinalFailure: (BleDevice) -> Unit) {
        val address = device.getMacAddress()
        val currentRetries = retryCounts.getOrDefault(address, 0)
        
        if (currentRetries >= MAX_RETRIES) {
            log(TAG, "Max retries ($MAX_RETRIES) reached for first connection: $address")
            cleanup(address)
            onFinalFailure(device)
            return
        }

        retryCounts[address] = currentRetries + 1
        log(TAG, "Starting first connection retry ${currentRetries + 1}/$MAX_RETRIES for: $address (status: $status)")

        val retryJob = scope.launch {
            delay(RETRY_DELAY_MS)
            
            // Check if device is still in connecting state
            if (device.isConnecting()) {
                log(TAG, "Executing retry attempt for: $address")
                onReconnect(device)
            } else {
                log(TAG, "Device no longer connecting, cancelling retry for: $address")
                cleanup(address)
            }
        }

        retryJobs[address] = retryJob
    }

    override fun cancelReconnection(deviceAddress: String) {
        cleanup(deviceAddress)
    }

    override fun cleanup() {
        retryJobs.values.forEach { it.cancel() }
        retryJobs.clear()
        retryCounts.clear()
        log(TAG, "Cleaned up all first connection retry strategies")
    }

    private fun cleanup(deviceAddress: String) {
        retryJobs[deviceAddress]?.cancel()
        retryJobs.remove(deviceAddress)
        retryCounts.remove(deviceAddress)
    }

    private fun shouldRetryStatus(status: Int): Boolean {
        return when (status) {
            STATUS_GATT_ERROR -> true // 133 - GATT error, often transient
            STATUS_LMP_RESPONSE_TIMEOUT -> true // 22 - LMP response timeout, can be transient
            STATUS_GATT_CONN_LMP_TIMEOUT -> true // 34 - LMP timeout variant, can be transient
            STATUS_CONNECTION_FAILED_TO_BE_ESTABLISHED -> true // 62 - Connection failed to establish, often transient
            STATUS_GATT_ERROR_85 -> true // 85 - Generic GATT error, often transient
            STATUS_GATT_CONN_L2C_FAILURE -> true // 129 - L2CAP failure, often transient
            STATUS_CONNECTION_TIMEOUT -> true // 8 - Connection timeout after 30s, device not available
            STATUS_GATT_CONN_TERMINATE_PEER_USER -> true // 14 - Remote terminated, don't retry
            STATUS_GATT_CONN_TERMINATE_LOCAL_HOST -> true // 15 - Local terminated, don't retry
            STATUS_REMOTE_DISCONNECTED -> true // 19 - User disconnected, don't retry
            else -> false
        }
    }

    fun onConnectionSuccess(deviceAddress: String) {
        cleanup(deviceAddress)
        log(TAG, "First connection successful, clearing retry state for: $deviceAddress")
    }
}