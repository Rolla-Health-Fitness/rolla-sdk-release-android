package app.rolla.bluetoothSdk.commands

import app.rolla.bluetoothSdk.commands.data.ChargingState
import app.rolla.bluetoothSdk.utils.log

class ChargingStatus : Command<ChargingState> {

    companion object {
        const val TAG = "ChargingStatus"
        private const val CHARGING_FLAG = 0x01.toByte()
        private const val NOT_CHARGING_FLAG = 0x00.toByte()
    }

    override fun getId(): Byte = 0x20.toByte()

    override fun bytesToWrite(): ByteArray = createCommandBytes { }

    override fun read(data: ByteArray): ChargingState {
        log(TAG, "Charging outside activity ${data.contentToString()}")
        
        val status = when (data[1]) {
            CHARGING_FLAG -> ChargingState.CHARGING
            NOT_CHARGING_FLAG -> ChargingState.NOT_CHARGING
            else -> ChargingState.NOT_CHARGING // Default to not charging
        }
        
        log(TAG, "Charging status: $status")
        return status
    }
}