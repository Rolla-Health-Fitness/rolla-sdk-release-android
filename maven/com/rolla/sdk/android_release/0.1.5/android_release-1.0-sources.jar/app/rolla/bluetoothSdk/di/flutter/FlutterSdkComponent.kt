package app.rolla.bluetoothSdk.di.flutter

import android.content.Context
import app.rolla.bluetoothSdk.BleManager
import dagger.BindsInstance
import dagger.Component
import javax.inject.Singleton

/**
 * Standalone Dagger component for Flutter integration.
 * Does NOT require @HiltAndroidApp on the host application.
 *
 * This component provides a zero-config initialization path for Flutter apps
 * that don't want to add Hilt annotations to their Application class.
 *
 * Key differences from Hilt:
 * - No compile-time code generation in the host app
 * - No requirement for @HiltAndroidApp annotation
 * - Host app's Application class can remain unchanged
 * - All DI is handled within the SDK module
 *
 * Usage in Flutter plugin:
 * ```kotlin
 * val component = DaggerFlutterSdkComponent.builder()
 *     .applicationContext(context)
 *     .build()
 * val bleManager = component.bleManager()
 * ```
 *
 * Note: Native Android apps should still use Hilt directly for better
 * integration with their existing DI setup. This component is specifically
 * for Flutter apps distributed via pub.dev.
 */
@Singleton
@Component(modules = [FlutterSdkModule::class])
interface FlutterSdkComponent {
    
    /**
     * Provides the main BleManager instance with all dependencies injected.
     * This is a singleton - calling this multiple times returns the same instance.
     */
    fun bleManager(): BleManager
    
    @Component.Builder
    interface Builder {
        /**
         * Binds the application context to the component.
         * Must be called before build().
         *
         * @param context Application context (will be used for all SDK operations)
         */
        @BindsInstance
        fun applicationContext(context: Context): Builder
        
        /**
         * Builds the component and initializes all singletons.
         */
        fun build(): FlutterSdkComponent
    }
}

