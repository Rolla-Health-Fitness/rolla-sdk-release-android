package app.rolla.bluetoothSdk.result.error

class BluetoothScanPermissionMissing(throwable: Throwable? = null) : Error (
    code = ErrorCodes.BLUETOOTH_SCAN_PERMISSION_MISSING,
    message = "Bluetooth scan permission is missing",
    exception = throwable
)