package app.rolla.bluetoothSdk;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import app.rolla.bluetoothSdk.connect.BleConnector;
import app.rolla.bluetoothSdk.device.DeviceManager;
import app.rolla.bluetoothSdk.scan.manager.ScanManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata({
    "dagger.hilt.android.qualifiers.ApplicationContext",
    "app.rolla.bluetoothSdk.di.BleScopeContext"
})
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BleManager_Factory implements Factory<BleManager> {
  private final Provider<Context> contextProvider;

  private final Provider<BluetoothAdapter> bluetoothAdapterProvider;

  private final Provider<ScanManager> scanManagerProvider;

  private final Provider<BleConnector> bleConnectorProvider;

  private final Provider<DeviceManager> deviceManagerProvider;

  private final Provider<BleRegistry> bleRegistryProvider;

  private final Provider<CoroutineContext> bleScopeContextProvider;

  private BleManager_Factory(Provider<Context> contextProvider,
      Provider<BluetoothAdapter> bluetoothAdapterProvider,
      Provider<ScanManager> scanManagerProvider, Provider<BleConnector> bleConnectorProvider,
      Provider<DeviceManager> deviceManagerProvider, Provider<BleRegistry> bleRegistryProvider,
      Provider<CoroutineContext> bleScopeContextProvider) {
    this.contextProvider = contextProvider;
    this.bluetoothAdapterProvider = bluetoothAdapterProvider;
    this.scanManagerProvider = scanManagerProvider;
    this.bleConnectorProvider = bleConnectorProvider;
    this.deviceManagerProvider = deviceManagerProvider;
    this.bleRegistryProvider = bleRegistryProvider;
    this.bleScopeContextProvider = bleScopeContextProvider;
  }

  @Override
  public BleManager get() {
    return newInstance(contextProvider.get(), bluetoothAdapterProvider.get(), scanManagerProvider.get(), bleConnectorProvider.get(), deviceManagerProvider.get(), bleRegistryProvider.get(), bleScopeContextProvider.get());
  }

  public static BleManager_Factory create(Provider<Context> contextProvider,
      Provider<BluetoothAdapter> bluetoothAdapterProvider,
      Provider<ScanManager> scanManagerProvider, Provider<BleConnector> bleConnectorProvider,
      Provider<DeviceManager> deviceManagerProvider, Provider<BleRegistry> bleRegistryProvider,
      Provider<CoroutineContext> bleScopeContextProvider) {
    return new BleManager_Factory(contextProvider, bluetoothAdapterProvider, scanManagerProvider, bleConnectorProvider, deviceManagerProvider, bleRegistryProvider, bleScopeContextProvider);
  }

  public static BleManager newInstance(Context context, @Nullable BluetoothAdapter bluetoothAdapter,
      ScanManager scanManager, BleConnector bleConnector, DeviceManager deviceManager,
      BleRegistry bleRegistry, CoroutineContext bleScopeContext) {
    return new BleManager(context, bluetoothAdapter, scanManager, bleConnector, deviceManager, bleRegistry, bleScopeContext);
  }
}
