package app.rolla.bluetoothSdk

import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCharacteristic
import app.rolla.bluetoothSdk.characteristics.Characteristic
import app.rolla.bluetoothSdk.characteristics.FirmwareRevisionCharacteristic
import app.rolla.bluetoothSdk.characteristics.HeartRateCharacteristic
import app.rolla.bluetoothSdk.characteristics.RollaBandReadCharacteristic
import app.rolla.bluetoothSdk.characteristics.RollaBandWriteCharacteristic
import app.rolla.bluetoothSdk.characteristics.RunningSpeedCadenceCharacteristic
import app.rolla.bluetoothSdk.characteristics.SerialNumberCharacteristic
import app.rolla.bluetoothSdk.characteristics.impl.RollaBandImpl
import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.device.DeviceType
import app.rolla.bluetoothSdk.result.error.Error
import app.rolla.bluetoothSdk.services.DeviceFirmwareUpdateService
import app.rolla.bluetoothSdk.services.DeviceInformationService
import app.rolla.bluetoothSdk.services.HeartRateService
import app.rolla.bluetoothSdk.services.RollaBandService
import app.rolla.bluetoothSdk.services.RunningSpeedAndCadenceService
import app.rolla.bluetoothSdk.services.Service
import app.rolla.bluetoothSdk.utils.log
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BleRegistry @Inject constructor(
    val heartRateService: HeartRateService,
    val runningSpeedCadenceService: RunningSpeedAndCadenceService,
    val rollaBandService: RollaBandService,
    val deviceInformationService: DeviceInformationService,
    val deviceFirmwareUpdateService: DeviceFirmwareUpdateService
) {

    companion object {
        private const val TAG = "BleRegistry"
    }

    private val determineDeviceTypeServices: Map<DeviceType, Set<String>> = mapOf(
        DeviceType.ROLLA_BAND to setOf(rollaBandService.uuid, heartRateService.uuid, runningSpeedCadenceService.uuid),
        DeviceType.RUNNING_SPEED_AND_CADENCE to setOf(runningSpeedCadenceService.uuid),
        DeviceType.HEART_RATE to setOf(heartRateService.uuid)
    )

    private val deviceTypeAllowedServices: Map<DeviceType, Set<Service>> = mapOf(
        DeviceType.RUNNING_SPEED_AND_CADENCE to setOf(runningSpeedCadenceService),
        DeviceType.HEART_RATE to setOf(heartRateService),
        DeviceType.ROLLA_BAND to setOf(rollaBandService, heartRateService, runningSpeedCadenceService)
    )

    private val deviceTypeScanningServices: Map<DeviceType, Set<String>> = mapOf(
        DeviceType.RUNNING_SPEED_AND_CADENCE to setOf(runningSpeedCadenceService.uuid),
        DeviceType.HEART_RATE to setOf(heartRateService.uuid),
        DeviceType.ROLLA_BAND to setOf(rollaBandService.uuid, deviceFirmwareUpdateService.uuid)
    )

    fun getAllowedCharacteristicsForDeviceTypes(gatt: BluetoothGatt?, deviceTypes: Set<DeviceType>): Set<Pair<Characteristic, BluetoothGattCharacteristic>> {
        log(TAG, "Finding allowed characteristic for ${gatt?.device?.address} with types: ${deviceTypes.joinToString { it.name }}")
        val allAllowedCharacteristics = mutableSetOf<Pair<Characteristic, BluetoothGattCharacteristic>>()
        val allowedForSubscribeServices = deviceTypes.flatMap { deviceTypeAllowedServices[it] ?: emptyList() }.toSet()
        allowedForSubscribeServices.forEach { service ->
            val bleService = gatt?.getService(UUID.fromString(service.uuid))
            if (bleService != null) {
                service.characteristics.forEach { characteristic ->
                    val bleCharacteristic = bleService.getCharacteristic(
                        UUID.fromString(
                            characteristic.uuid
                        )
                    )
                    if (bleCharacteristic != null) {
                        log(TAG, "Found characteristic ${characteristic.uuid} for ${gatt.device.address}")
                        allAllowedCharacteristics.add(Pair(characteristic, bleCharacteristic))
                    } else {
                        log(TAG, "Characteristic ${characteristic.uuid} not found for ${gatt.device.address}")
                    }
                }
            } else {
                log(TAG, "Service ${service.uuid} not found for ${gatt?.device?.address}")
            }
        }
        return allAllowedCharacteristics
    }

    fun getScanningServicesForDeviceTypes(deviceTypes: Set<DeviceType>): Set<String> {
        return deviceTypes.flatMap { deviceTypeScanningServices[it] ?: emptySet() }.toSet()
    }

    fun determineDeviceTypes(discoveredServiceUuids: List<String>): Set<DeviceType> {
        val detectedTypes = mutableSetOf<DeviceType>()
        DeviceType.entries.forEach {
            if (discoveredServiceUuids.containsAll(determineDeviceTypeServices[it] ?: emptySet())) {
                detectedTypes.add(it)
            }
        }
        return detectedTypes
    }

    fun getAllServices(): List<Service> {
        return listOf(heartRateService, runningSpeedCadenceService, rollaBandService, deviceInformationService, deviceFirmwareUpdateService)
    }

    fun getRunningSpeedAndCadenceCharacteristic(): RunningSpeedCadenceCharacteristic = runningSpeedCadenceService.getRunningSpeedCadenceCharacteristic()
    fun getHeartRateCharacteristic(): HeartRateCharacteristic = heartRateService.getHeartRateCharacteristic()
    fun getSerialNumberCharacteristic(): SerialNumberCharacteristic = deviceInformationService.getSerialNumberCharacteristic()
    fun getFirmwareRevisionCharacteristic(): FirmwareRevisionCharacteristic = deviceInformationService.getFirmwareRevisionCharacteristic()
    fun getRollaBandWriteCharacteristic(): RollaBandWriteCharacteristic = rollaBandService.getRollaBandWriteCharacteristic()
    fun getRollaBandReadCharacteristic(): RollaBandReadCharacteristic = rollaBandService.getRollaBandReadCharacteristic()
    fun getRollaBandImpl(): RollaBandImpl = rollaBandService.getRollaBandImpl()
    fun findCharacteristicByUuid(uuid: String): Characteristic? = getAllServices().flatMap { it.characteristics }.find { it.uuid == uuid }
    fun getAllCharacteristics(): List<Characteristic> = getAllServices().flatMap { it.characteristics }

    fun notifyCharacteristic(uuid: String, value: ByteArray, device: BleDevice) {
        val characteristic = findCharacteristicByUuid(uuid)
        if (characteristic != null) {
            log(TAG, "Notifying characteristic $uuid with value: ${value.toTypedArray().contentToString()}")
            characteristic.onNotify(value, device)
        } else {
            log(TAG, "Characteristic not found for $uuid")
        }
    }

    fun readCharacteristic(uuid: String, value: ByteArray, device: BleDevice) {
        val characteristic = findCharacteristicByUuid(uuid)
        if (characteristic != null) {
            log(TAG, "Reading characteristic $uuid with value: ${value.toTypedArray().contentToString()}")
            characteristic.onRead(value, device)
        } else {
            log(TAG, "Characteristic not found for $uuid")
        }
    }

    fun writeCharacteristic(uuid: String, value: ByteArray, device: BleDevice) {
        val characteristic = findCharacteristicByUuid(uuid)
        if (characteristic != null) {
            log(TAG, "Writing characteristic $uuid with value: ${value.toTypedArray().contentToString()}")
            characteristic.onWrite(value, device)
        } else {
            log(TAG, "Characteristic not found for $uuid")
        }
    }

    fun onCharacteristicError(characteristicUuid: String, deviceAddress: String, value: ByteArray, error: Error) {
        val characteristic = findCharacteristicByUuid(characteristicUuid)
        if (characteristic != null) {
            characteristic.onError(deviceAddress, error, value)
        } else {
            log(TAG, "Characteristic not found for $characteristic")
        }
    }

    fun onDeviceConnected(gatt: BluetoothGatt?, deviceTypes: Set<DeviceType>) {
        log(TAG, "Device connected, notifying characteristics for types: ${deviceTypes.joinToString { it.name }}")
        return getAllowedCharacteristicsForDeviceTypes(gatt, deviceTypes).forEach { it.first.onDeviceConnected() }
    }

}