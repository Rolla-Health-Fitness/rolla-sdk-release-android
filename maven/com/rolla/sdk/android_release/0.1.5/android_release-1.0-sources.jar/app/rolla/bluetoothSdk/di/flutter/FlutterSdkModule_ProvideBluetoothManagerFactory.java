package app.rolla.bluetoothSdk.di.flutter;

import android.bluetooth.BluetoothManager;
import android.content.Context;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideBluetoothManagerFactory implements Factory<BluetoothManager> {
  private final Provider<Context> contextProvider;

  private FlutterSdkModule_ProvideBluetoothManagerFactory(Provider<Context> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  @Nullable
  public BluetoothManager get() {
    return provideBluetoothManager(contextProvider.get());
  }

  public static FlutterSdkModule_ProvideBluetoothManagerFactory create(
      Provider<Context> contextProvider) {
    return new FlutterSdkModule_ProvideBluetoothManagerFactory(contextProvider);
  }

  @Nullable
  public static BluetoothManager provideBluetoothManager(Context context) {
    return FlutterSdkModule.INSTANCE.provideBluetoothManager(context);
  }
}
