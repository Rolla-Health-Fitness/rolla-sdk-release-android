package app.rolla.bluetoothSdk.di.flutter;

import android.content.Context;
import app.rolla.bluetoothSdk.characteristics.impl.RollaBandImpl;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideRollaBandImplFactory implements Factory<RollaBandImpl> {
  private final Provider<Context> contextProvider;

  private final Provider<CoroutineContext> coroutineContextProvider;

  private FlutterSdkModule_ProvideRollaBandImplFactory(Provider<Context> contextProvider,
      Provider<CoroutineContext> coroutineContextProvider) {
    this.contextProvider = contextProvider;
    this.coroutineContextProvider = coroutineContextProvider;
  }

  @Override
  public RollaBandImpl get() {
    return provideRollaBandImpl(contextProvider.get(), coroutineContextProvider.get());
  }

  public static FlutterSdkModule_ProvideRollaBandImplFactory create(
      Provider<Context> contextProvider, Provider<CoroutineContext> coroutineContextProvider) {
    return new FlutterSdkModule_ProvideRollaBandImplFactory(contextProvider, coroutineContextProvider);
  }

  public static RollaBandImpl provideRollaBandImpl(Context context,
      CoroutineContext coroutineContext) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideRollaBandImpl(context, coroutineContext));
  }
}
