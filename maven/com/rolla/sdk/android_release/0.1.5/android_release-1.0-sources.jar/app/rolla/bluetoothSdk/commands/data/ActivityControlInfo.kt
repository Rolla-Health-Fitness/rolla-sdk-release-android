package app.rolla.bluetoothSdk.commands.data

import app.rolla.bluetoothSdk.result.error.Error

data class ActivityControlInfo (
    var success: Boolean = false,
    var error: Error? = null
)